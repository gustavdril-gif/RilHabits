package com.airil.rillrebirth.ui.components

import androidx.navigation.NavHostController

/** Central route registry for the Compose application. */
object RillRoutes {
    const val HOME = "home"
    const val CHECKLIST = "checklist"
    const val WORKOUT = "workout"
    const val STATS = "stats"

    const val JADWAL = "jadwal"
    const val NOTES = "notes"
    const val JOGGING = "jogging"
    const val JOG_LIVE = "jog_live"
    const val JOG_SUM = "jog_sum/{id}"
    const val TIMER = "timer/{flow}"
    const val WO_DETAIL = "wo/{id}"
    const val BUILDER = "builder/{id}"
    const val RITUAL = "ritual/{kind}"

    fun jogSum(id: Long) = "jog_sum/$id"
    fun timer(flow: Long = -1L) = "timer/$flow"
    fun workout(id: Long) = "wo/$id"
    fun builder(id: Long = 0L) = "builder/$id"
    fun ritual(kind: String) = "ritual/$kind"

    val tabs = setOf(HOME, CHECKLIST, WORKOUT, STATS)

    fun routeFor(index: Int): String = when (index) {
        1 -> CHECKLIST
        2 -> WORKOUT
        3 -> STATS
        else -> HOME
    }

    fun tabIndex(route: String?): Int = when (route) {
        CHECKLIST -> 1
        WORKOUT -> 2
        STATS -> 3
        else -> 0
    }
}

/** Small wrapper so screens do not depend on NavController directly. */
class RillNav(private val c: NavHostController) {
    fun go(route: String) { c.navigate(route) { launchSingleTop = true } }
    fun back() { c.popBackStack() }
    /** Open [route] and drop [popRoute] (e.g. live recording -> summary). */
    fun replace(route: String, popRoute: String) { c.navigate(route) { popUpTo(popRoute) { inclusive = true }; launchSingleTop = true } }
}
