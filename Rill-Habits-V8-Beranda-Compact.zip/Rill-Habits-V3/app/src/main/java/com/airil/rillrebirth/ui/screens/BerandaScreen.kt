package com.airil.rillrebirth.ui.screens

import android.content.Context
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.airil.rillrebirth.Badge
import com.airil.rillrebirth.GoalStore
import com.airil.rillrebirth.NoteStore
import com.airil.rillrebirth.R
import com.airil.rillrebirth.RillTask
import com.airil.rillrebirth.Smart
import com.airil.rillrebirth.ui.components.CircleCheckSized
import com.airil.rillrebirth.ui.components.CompactPill
import com.airil.rillrebirth.ui.components.EmojiBadge
import com.airil.rillrebirth.ui.components.EmptyState
import com.airil.rillrebirth.ui.components.IOSCard
import com.airil.rillrebirth.ui.components.IOSField
import com.airil.rillrebirth.ui.components.IOSSheet
import com.airil.rillrebirth.ui.components.MistyHeader
import com.airil.rillrebirth.ui.components.OutlineButton
import com.airil.rillrebirth.ui.components.PrimaryButton
import com.airil.rillrebirth.ui.components.RillNav
import com.airil.rillrebirth.ui.components.RillRoutes
import com.airil.rillrebirth.ui.components.SegmentRing
import com.airil.rillrebirth.ui.components.ThinBar
import com.airil.rillrebirth.ui.components.iosPress
import com.airil.rillrebirth.ui.data.TodayData
import com.airil.rillrebirth.ui.theme.IOS
import com.airil.rillrebirth.ui.theme.IOSType
import kotlinx.coroutines.delay

private val SectionStyle = IOSType.title.copy(fontSize = 20.sp)
private val RowTitle = IOSType.headline.copy(fontSize = 15.sp)
private val Small = IOSType.caption.copy(fontSize = 11.sp)

@Composable
fun BerandaScreen(refresh: Int, nav: RillNav) {
    val ctx = LocalContext.current
    val c = IOS.colors
    val haptic = LocalHapticFeedback.current
    val prefs = remember { ctx.getSharedPreferences("rill_data", Context.MODE_PRIVATE) }
    var tick by remember { mutableIntStateOf(0) }
    val snap = remember(refresh, tick) { TodayData.snapshot(ctx) }
    var name by remember { mutableStateOf(prefs.getString("profile_name", "") ?: "") }
    var nameSheet by remember { mutableStateOf(false) }
    var moodSheet by remember { mutableStateOf(false) }
    var reviewSheet by remember { mutableStateOf(false) }
    var levelUp by remember { mutableIntStateOf(0) }
    var freshBadges by remember { mutableStateOf<List<Badge>>(emptyList()) }
    var focusOpen by rememberSaveable { mutableStateOf(true) }

    // Minute of the day, refreshed twice a minute: drives the greeting and the live sky in the header.
    var minuteNow by remember { mutableIntStateOf(TodayData.nowMinutes()) }
    LaunchedEffect(Unit) { while (true) { delay(30_000); minuteNow = TodayData.nowMinutes() } }

    val phase = Smart.phaseOf(minuteNow / 60)
    val greeting = when (phase) { 0 -> "Selamat pagi"; 1 -> "Selamat siang"; 2 -> "Selamat sore"; else -> "Selamat malam" }

    val prayerDone = snap.prayer.count { snap.done.contains(it.id) }
    val otherDone = snap.other.count { snap.done.contains(it.id) }
    val total = snap.totalCount.coerceAtLeast(1)
    val segments = listOf(prayerDone.toFloat() / total to c.primary, snap.workoutDone.toFloat() / total to c.orange, otherDone.toFloat() / total to c.blue)
    val pct = if (snap.totalCount == 0) 0 else snap.doneCount * 100 / snap.totalCount
    val level = snap.totalXp / 100 + 1
    val xpIn = snap.totalXp % 100
    val allDone = snap.totalCount > 0 && snap.doneCount >= snap.totalCount

    val now = TodayData.nowMinutes()
    val pending = snap.live.filter { !snap.done.contains(it.id) }.sortedBy { TodayData.minutes(ctx, it) }
    val ordered = pending.filter { TodayData.minutes(ctx, it) >= now } + pending.filter { TodayData.minutes(ctx, it) < now }
    val focus = ordered.take(3)
    val ritual = remember(refresh, tick) { TodayData.ritualOffer(ctx) }
    val notesCount = remember(refresh, tick) { NoteStore.load(ctx).count { !it.done } }
    val goalsCount = remember(refresh, tick) { GoalStore.load(ctx).size }

    LaunchedEffect(refresh, tick) {
        val stored = prefs.getInt("max_level", -1)
        if (stored < 0) prefs.edit().putInt("max_level", level).apply()
        else if (level > stored) { prefs.edit().putInt("max_level", level).apply(); levelUp = level }
        val fresh = GoalStore.checkAwards(ctx, snap.allTasks, Smart.dayStats(ctx, snap.allTasks, 365))
        if (fresh.isNotEmpty()) freshBadges = fresh
    }

    fun complete(t: RillTask) {
        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
        TodayData.setDone(ctx, t.id, true)
        tick++
    }

    val chevRotation by animateFloatAsState(if (focusOpen) 90f else 0f, label = "focusChevron")

    LazyColumn(
        contentPadding = PaddingValues(start = 0.dp, end = 0.dp, top = 0.dp, bottom = 120.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            MistyHeader(minuteNow, greeting, name.ifBlank { "Sahabat" }, "Pelan-pelan, konsisten.", { nameSheet = true }) {
                GlassSummary(
                    pct, snap.doneCount, snap.totalCount, segments,
                    "Ibadah $prayerDone/${snap.prayer.size}", "Workout ${snap.workoutDone}/${snap.workoutTotal}", "Lainnya $otherDone/${snap.other.size}"
                )
            }
        }
        item {
            Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                // Level + XP: flat, no card
                Column(Modifier.padding(horizontal = 2.dp).semantics { contentDescription = "Level $level ${Smart.levelTitle(level)}, $xpIn dari 100 XP" }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            "⭐ Level $level", style = IOSType.headline.copy(fontSize = 13.sp), color = c.textPrimary,
                            modifier = Modifier.shadow(2.dp, RoundedCornerShape(10.dp), ambientColor = Color.Black.copy(alpha = 0.06f), spotColor = Color.Black.copy(alpha = 0.06f))
                                .clip(RoundedCornerShape(10.dp)).background(c.card).padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                        Text("•", style = IOSType.caption, color = c.textSecondary, modifier = Modifier.padding(horizontal = 6.dp))
                        Text(Smart.levelTitle(level), style = IOSType.body.copy(fontSize = 13.sp, fontWeight = FontWeight.Medium), color = c.primaryText, modifier = Modifier.weight(1f))
                        Text("$xpIn/100 XP", style = IOSType.caption, color = c.textSecondary)
                    }
                    Box(Modifier.padding(top = 8.dp)) { ThinBar(xpIn / 100f, c.primary) }
                }

                // Focus Today (collapsible)
                Row(
                    Modifier.fillMaxWidth().heightIn(min = 40.dp).padding(top = 4.dp)
                        .semantics { contentDescription = if (focusOpen) "Focus Today, ketuk untuk melipat" else "Focus Today, ketuk untuk membuka" }
                        .iosPress(Role.Button) { focusOpen = !focusOpen },
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Focus Today", style = SectionStyle, color = c.textPrimary, modifier = Modifier.weight(1f))
                    Icon(
                        painterResource(R.drawable.ic_chevron), contentDescription = null, tint = c.textSecondary,
                        modifier = Modifier.size(26.dp).graphicsLayer { rotationZ = chevRotation }
                    )
                }
                AnimatedVisibility(focusOpen) {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (focus.isEmpty()) {
                            if (snap.totalCount > 0) {
                                IOSCard(padding = 12.dp, corner = 18.dp) {
                                    Text("Semua beres 🎉", style = RowTitle, color = c.textPrimary)
                                    Text("Tidak ada kegiatan tersisa hari ini.", style = IOSType.caption, color = c.textSecondary)
                                }
                            } else EmptyState("🌱", "Belum ada kegiatan", "Tambahkan kebiasaan di menu Jadwal untuk mulai.", "Buka Jadwal") { nav.go(RillRoutes.JADWAL) }
                        }
                        focus.forEachIndexed { i, t -> FocusRow(ctx, t, highlight = i == 0) { complete(t) } }
                    }
                }

                if (ritual.isNotEmpty()) {
                    val rl = remember(ritual, tick) { TodayData.ritualTasks(ctx, ritual) }
                    val pagi = ritual == "pagi"
                    IOSCard(padding = 12.dp, corner = 18.dp) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(if (pagi) "🌅" else "🌙", style = IOSType.title.copy(fontSize = 24.sp))
                            Column(Modifier.weight(1f).padding(horizontal = 10.dp)) {
                                Text(if (pagi) "Ritual Pagi" else "Ritual Malam", style = RowTitle, color = c.textPrimary)
                                Text(
                                    "${rl.size} tugas · ${rl.take(2).joinToString(", ") { it.name }}${if (rl.size > 2) "…" else ""}",
                                    style = IOSType.caption, color = c.textSecondary, maxLines = 1, overflow = TextOverflow.Ellipsis
                                )
                            }
                            Box(
                                Modifier.clip(RoundedCornerShape(50)).background(if (c.dark) c.primary else c.primaryText)
                                    .iosPress(Role.Button) { nav.go(RillRoutes.ritual(ritual)) }
                                    .padding(horizontal = 16.dp, vertical = 10.dp)
                            ) { Text("Mulai", style = RowTitle.copy(fontSize = 14.sp), color = if (c.dark) Color(0xFF10261A) else Color.White) }
                        }
                    }
                }
                if (allDone) {
                    IOSCard(padding = 12.dp, corner = 18.dp) {
                        Text("🎉 Semua kegiatan hari ini selesai", style = RowTitle, color = c.textPrimary)
                        Text("Catat perasaanmu dan tutup hari dengan evaluasi singkat.", style = IOSType.caption, color = c.textSecondary, modifier = Modifier.padding(top = 2.dp, bottom = 8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            PrimaryButton("Catat mood", Modifier.weight(1f), height = 40.dp) { moodSheet = true }
                            OutlineButton("Evaluasi malam", Modifier.weight(1f), height = 40.dp) { reviewSheet = true }
                        }
                    }
                }

                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StreakCard("🔥", "${snap.streak} hari", "Streak", if (snap.streak > 0) "Pertahankan!" else "Mulai hari ini", Modifier.weight(1f), pulse = snap.streak > 0)
                    StreakCard("🏆", "${snap.bestStreak} hari", "Best Streak", "Rekor terbaik", Modifier.weight(1f), pulse = false)
                }
            }
        }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text("Lainnya", style = SectionStyle, color = c.textPrimary, modifier = Modifier.padding(start = 20.dp))
                Row(
                    Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    MoreTile("📝", "Catatan & Target", "$notesCount catatan · $goalsCount target") { nav.go(RillRoutes.NOTES) }
                    MoreTile("🏃", "Jogging", "Jejak, pace, langkah") { nav.go(RillRoutes.JOGGING) }
                    MoreTile("⏱️", "Timer", "Istirahat & bebas") { nav.go(RillRoutes.timer(-1L)) }
                    MoreTile("🗓️", "Jadwal", "Atur kegiatan") { nav.go(RillRoutes.JADWAL) }
                }
            }
        }
    }

    if (nameSheet) {
        var draft by remember { mutableStateOf(name) }
        IOSSheet({ nameSheet = false }) {
            Text("Siapa namamu?", style = IOSType.title, color = c.textPrimary)
            Text("Nama ini tampil di sapaan Beranda.", style = IOSType.body, color = c.textSecondary, modifier = Modifier.padding(top = 4.dp, bottom = 10.dp))
            IOSField(draft, { draft = it.take(20) }, "mis. Ril", singleLine = true)
            Spacer(Modifier.height(16.dp))
            PrimaryButton("Simpan") { name = draft.trim(); prefs.edit().putString("profile_name", name).apply(); nameSheet = false }
        }
    }
    if (moodSheet) MoodSheet { moodSheet = false; tick++ }
    if (reviewSheet) ReviewSheet { reviewSheet = false }
    if (levelUp > 0) AlertDialog(
        onDismissRequest = { levelUp = 0 },
        title = { Text("Level naik! 🎉") },
        text = { Text("Kamu sekarang Level $levelUp · ${Smart.levelTitle(levelUp)}. Konsistensimu terbayar.") },
        confirmButton = { TextButton(onClick = { levelUp = 0 }) { Text("Mantap") } }
    )
    if (freshBadges.isNotEmpty()) AlertDialog(
        onDismissRequest = { freshBadges = emptyList() },
        title = { Text("Target tercapai! 🎉") },
        text = { Text(freshBadges.joinToString("\n") { "🏅 ${it.title}" } + "\n\nLencana tersimpan di menu Catatan & Target.") },
        confirmButton = { TextButton(onClick = { freshBadges = emptyList(); nav.go(RillRoutes.NOTES) }) { Text("Lihat") } },
        dismissButton = { TextButton(onClick = { freshBadges = emptyList() }) { Text("Mantap") } }
    )
}

/** Frosted card that overlaps the sky: small progress ring with the percentage, and three tinted category pills. */
@Composable
private fun GlassSummary(
    pct: Int, done: Int, total: Int, segments: List<Pair<Float, Color>>,
    prayerLabel: String, workoutLabel: String, otherLabel: String
) {
    val c = IOS.colors
    val shape = RoundedCornerShape(26.dp)
    val fill = if (c.dark) Brush.verticalGradient(listOf(c.card.copy(alpha = 0.90f), c.card.copy(alpha = 0.74f)))
    else Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.92f), Color.White.copy(alpha = 0.74f)))
    Column(
        Modifier.fillMaxWidth()
            .shadow(14.dp, shape, ambientColor = Color.Black.copy(alpha = 0.08f), spotColor = Color.Black.copy(alpha = 0.08f))
            .clip(shape).background(fill)
            .border(1.dp, Color.White.copy(alpha = if (c.dark) 0.10f else 0.70f), shape)
            .padding(horizontal = 14.dp, vertical = 14.dp)
            .semantics(mergeDescendants = true) { contentDescription = "Progres hari ini $pct persen, $done dari $total kebiasaan selesai" },
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        SegmentRing(segments, Modifier.size(116.dp), 11.dp) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("$pct%", style = IOSType.title.copy(fontSize = 28.sp), color = c.primaryText)
                Text("Hari ini", style = Small, color = c.textSecondary)
                Text("$done/$total kebiasaan", style = Small, color = c.textSecondary)
            }
        }
        Row(Modifier.padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            CompactPill(prayerLabel, c.primary)
            CompactPill(workoutLabel, c.orange)
            CompactPill(otherLabel, c.blue)
        }
    }
}

@Composable
private fun FocusRow(ctx: Context, t: RillTask, highlight: Boolean, onDone: () -> Unit) {
    val c = IOS.colors
    val shape = RoundedCornerShape(18.dp)
    val time = TodayData.timeLabel(ctx, t)
    val sub = "${if (Smart.isPrayer(t)) "Prioritas" else t.category} • ${t.xp} XP"
    Row(
        Modifier.fillMaxWidth()
            .shadow(6.dp, shape, ambientColor = Color.Black.copy(alpha = 0.06f), spotColor = Color.Black.copy(alpha = 0.06f))
            .clip(shape).background(c.card)
            .then(if (highlight) Modifier.border(1.dp, c.primary.copy(alpha = 0.45f), shape) else Modifier)
            .padding(start = 6.dp, end = 12.dp, top = 4.dp, bottom = 4.dp)
            .semantics { contentDescription = "${t.name}, $time, $sub" },
        verticalAlignment = Alignment.CenterVertically
    ) {
        CircleCheckSized(false, "Selesaikan ${t.name}", 44.dp) { if (it) onDone() }
        Column(Modifier.weight(1f).padding(horizontal = 4.dp)) {
            Text("${t.name} — $time", style = RowTitle, color = c.textPrimary, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(sub, style = IOSType.caption, color = c.textSecondary)
        }
        EmojiBadge(TodayData.emojiFor(t), if (Smart.isPrayer(t)) c.primary else c.blue, 32.dp)
    }
}

@Composable
private fun StreakCard(emoji: String, value: String, label: String, hint: String, modifier: Modifier, pulse: Boolean) {
    val c = IOS.colors
    val t = rememberInfiniteTransition(label = "fire")
    val s by t.animateFloat(1f, if (pulse) 1.15f else 1f, infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "scale")
    IOSCard(modifier.semantics { contentDescription = "$label $value" }, padding = 12.dp, corner = 18.dp) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(emoji, style = IOSType.title.copy(fontSize = 26.sp), modifier = Modifier.graphicsLayer { scaleX = s; scaleY = s })
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    label, style = Small.copy(fontWeight = FontWeight.Medium), color = c.textSecondary,
                    modifier = Modifier.clip(RoundedCornerShape(6.dp)).background(c.track.copy(alpha = 0.7f)).padding(horizontal = 6.dp, vertical = 1.dp)
                )
                Text(value, style = IOSType.title.copy(fontSize = 20.sp), color = c.textPrimary, modifier = Modifier.padding(top = 3.dp))
                Text(hint, style = Small, color = c.textSecondary, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

@Composable
private fun MoreTile(emoji: String, title: String, sub: String, onClick: () -> Unit) {
    val c = IOS.colors
    IOSCard(Modifier.width(150.dp).iosPress(Role.Button, onClick), padding = 12.dp, corner = 18.dp) {
        Text(emoji, style = IOSType.title.copy(fontSize = 22.sp))
        Text(title, style = RowTitle.copy(fontSize = 14.sp), color = c.textPrimary, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 4.dp))
        Text(sub, style = Small, color = c.textSecondary, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}
