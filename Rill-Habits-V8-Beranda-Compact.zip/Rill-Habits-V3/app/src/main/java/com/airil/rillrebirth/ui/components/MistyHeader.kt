package com.airil.rillrebirth.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathOperation
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.airil.rillrebirth.ui.theme.IOS
import com.airil.rillrebirth.ui.theme.IOSType
import kotlinx.coroutines.delay
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.sin

/** One sky "snapshot". Between two snapshots every colour is blended, so the scene changes smoothly all day. */
private class Sky(
    val top: Color, val horizon: Color,
    val far: Color, val mid: Color, val near: Color, val lake: Color
)

private class SkyKey(val minute: Int, val sky: Sky)

private fun key(h: Int, m: Int, top: Long, horizon: Long, far: Long, mid: Long, near: Long, lake: Long) =
    SkyKey(h * 60 + m, Sky(Color(top), Color(horizon), Color(far), Color(mid), Color(near), Color(lake)))

// Equatorial Indonesia: the sun rises ~06:00 and sets ~18:00 all year, so the keyframes follow that.
private val skyKeys = listOf(
    key(0, 0, 0xFF0A1128, 0xFF1B2B4A, 0xFF233650, 0xFF1A2A42, 0xFF121F33, 0xFF17243A),    // tengah malam
    key(4, 30, 0xFF111B3A, 0xFF2F3F66, 0xFF2A3B5C, 0xFF20304B, 0xFF172539, 0xFF1E2D47),   // jelang subuh
    key(5, 30, 0xFF4C5F94, 0xFFF2A98F, 0xFF8C86A6, 0xFF6D6E92, 0xFF4B5675, 0xFF9C8DA6),   // fajar
    key(6, 20, 0xFF7FA7D6, 0xFFFFD7A8, 0xFFB9B7C9, 0xFF8FA3B8, 0xFF6A8794, 0xFFE8CDB8),   // matahari terbit
    key(8, 0, 0xFF78B6EA, 0xFFD6EBF4, 0xFFB7D3DC, 0xFF8FBBC0, 0xFF6A9C98, 0xFFBFDCE3),    // pagi cerah
    key(12, 0, 0xFF4C9BE4, 0xFFC4E3F6, 0xFFA8CFDB, 0xFF7FB3B9, 0xFF5A9A8F, 0xFFA9D2E0),   // siang
    key(15, 0, 0xFF5EA3E0, 0xFFD3E8F3, 0xFFAFCFD8, 0xFF85B2B4, 0xFF5F9689, 0xFFB0D3DF),   // sore awal
    key(16, 45, 0xFF86AEDA, 0xFFF9DFA9, 0xFFC7CCC4, 0xFF9DB0A4, 0xFF6E8C78, 0xFFE5D8B8),  // golden hour
    key(17, 40, 0xFF5A6CA8, 0xFFFF9F68, 0xFFC59A9E, 0xFF9A7C93, 0xFF635A74, 0xFFE8A27C),  // senja
    key(18, 20, 0xFF2D3A6C, 0xFFC46A7C, 0xFF7A5C82, 0xFF5A4B72, 0xFF3C3A5C, 0xFF8F5A76),  // magrib
    key(19, 10, 0xFF151F4A, 0xFF4B4B7C, 0xFF38416A, 0xFF2C3658, 0xFF202A45, 0xFF2F3A5F),  // senja akhir
    key(20, 30, 0xFF0C1530, 0xFF22355A, 0xFF25374F, 0xFF1B2B42, 0xFF121F33, 0xFF18263C),  // malam
    key(24, 0, 0xFF0A1128, 0xFF1B2B4A, 0xFF233650, 0xFF1A2A42, 0xFF121F33, 0xFF17243A)
)

private fun skyAt(minute: Float): Sky {
    val m = minute.coerceIn(0f, 1440f)
    var i = 0
    while (i < skyKeys.size - 2 && m >= skyKeys[i + 1].minute) i++
    val a = skyKeys[i]
    val b = skyKeys[i + 1]
    val f = ((m - a.minute) / (b.minute - a.minute).toFloat()).coerceIn(0f, 1f)
    return Sky(
        lerp(a.sky.top, b.sky.top, f), lerp(a.sky.horizon, b.sky.horizon, f),
        lerp(a.sky.far, b.sky.far, f), lerp(a.sky.mid, b.sky.mid, f),
        lerp(a.sky.near, b.sky.near, f), lerp(a.sky.lake, b.sky.lake, f)
    )
}

/** Bright text on dark skies, dark text on light skies, judged from the colour that really sits behind the title. */
private fun inkFor(s: Sky): Color {
    val lum = lerp(s.top, s.horizon, 0.5f).luminance()
    val toLight = ((0.20f - lum) / 0.10f).coerceIn(0f, 1f)
    return lerp(Color(0xFF16202C), Color.White, toLight)
}

/** 0 = daylight, 1 = deep night (stars and cloud brightness). */
private fun nightOf(s: Sky): Float = ((0.16f - s.top.luminance()) / 0.12f).coerceIn(0f, 1f)

private fun fract(v: Float): Float = v - floor(v)

/**
 * Sky + sun/moon + stars + clouds (full width) and a soft mountain/lake vignette on the right.
 * [minute] is the minute of the day (0..1439): the sun climbs 06:00 to 18:00, the moon 18:00 to 06:00.
 */
@Composable
fun MistyLandscape(minute: Float, modifier: Modifier = Modifier) {
    val bg = IOS.colors.background
    val sky = skyAt(minute)
    val night = nightOf(sky)

    // Slow ~4 fps ticker for clouds and star twinkle: cheap on low-end phones, and the motion is too slow to look choppy.
    var clock by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) { while (true) { delay(250); clock = System.currentTimeMillis() } }

    Box(modifier) {
        // ---- Layer 1: sky, sun / moon, stars, clouds ----
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            drawRect(
                Brush.verticalGradient(0f to sky.top, 0.72f to sky.horizon, 1f to bg, startY = 0f, endY = h),
                size = Size(w, h)
            )

            val horizonY = h * 0.70f
            val arcH = h * 0.52f
            val xL = w * 0.54f
            val xR = w * 0.93f

            // Stars
            if (night > 0.02f) {
                val tw = (clock % 6000L) / 6000f
                for (i in 0 until 30) {
                    val sx = ((i * 7919) % 1000) / 1000f * w
                    val sy = ((i * 104729) % 1000) / 1000f * h * 0.55f
                    val twinkle = 0.45f + 0.55f * abs(sin(2f * PI.toFloat() * (tw + i * 0.137f)))
                    val r = (if (i % 5 == 0) 1.6f else 1.1f).dp.toPx()
                    drawCircle(Color.White.copy(alpha = night * twinkle * 0.8f), r, Offset(sx, sy))
                }
            }

            // Sun: 06:00 -> 18:00
            val tSun = (minute - 360f) / 720f
            if (tSun > -0.06f && tSun < 1.06f) {
                val alt = sin(PI.toFloat() * tSun)
                val sx = xL + (xR - xL) * tSun.coerceIn(0f, 1f)
                val sy = horizonY - alt * arcH
                val vis = ((alt + 0.05f) / 0.12f).coerceIn(0f, 1f)
                val warm = (1f - alt.coerceIn(0f, 1f) * 1.6f).coerceIn(0f, 1f)   // low sun = orange
                val col = lerp(Color(0xFFFFF3C4), Color(0xFFFF9A55), warm)
                val glowR = h * (0.26f + 0.12f * warm)
                drawCircle(
                    Brush.radialGradient(listOf(col.copy(alpha = 0.60f * vis), Color.Transparent), Offset(sx, sy), glowR),
                    glowR, Offset(sx, sy)
                )
                drawCircle(col.copy(alpha = vis), h * 0.052f, Offset(sx, sy))
            }

            // Moon: 18:00 -> 06:00 (crescent)
            val tMoon = ((minute - 1080f + 1440f) % 1440f) / 720f
            if (tMoon >= 0f && tMoon <= 1.02f) {
                val tm = tMoon.coerceIn(0f, 1f)
                val alt = sin(PI.toFloat() * tm)
                val mx = xL + (xR - xL) * tm
                val my = horizonY - alt * arcH
                val vis = (alt / 0.10f).coerceIn(0f, 1f)
                val r = h * 0.05f
                drawCircle(
                    Brush.radialGradient(listOf(Color(0xFFDDE6FF).copy(alpha = 0.30f * vis), Color.Transparent), Offset(mx, my), r * 4.5f),
                    r * 4.5f, Offset(mx, my)
                )
                val disk = Path().apply { addOval(Rect(Offset(mx, my), r)) }
                val bite = Path().apply { addOval(Rect(Offset(mx + r * 0.55f, my - r * 0.25f), r * 0.92f)) }
                drawPath(Path.combine(PathOperation.Difference, disk, bite), Color(0xFFF1F3FA).copy(alpha = vis))
            }

            // Clouds drift slowly leftwards and wrap around
            val cloudCol = lerp(Color.White, sky.horizon, 0.22f)
            val cloudA = 0.62f - 0.46f * night
            val drift = (clock % 150_000L) / 150_000f
            val clouds = listOf(Triple(0.05f, 0.24f, 1.0f), Triple(0.42f, 0.38f, 0.75f), Triple(0.74f, 0.17f, 0.6f))
            clouds.forEach { (base, yy, sc) ->
                val cx = w * 0.30f + fract(base - drift) * w * 0.85f
                val cy = h * yy
                val u = 16.dp.toPx() * sc
                drawOval(cloudCol.copy(alpha = cloudA), Offset(cx - u * 2.2f, cy - u * 0.45f), Size(u * 4.4f, u * 1.1f))
                drawOval(cloudCol.copy(alpha = cloudA * 0.9f), Offset(cx - u * 1.2f, cy - u * 0.95f), Size(u * 2.4f, u * 1.2f))
                drawOval(cloudCol.copy(alpha = cloudA * 0.8f), Offset(cx + u * 0.2f, cy - u * 0.7f), Size(u * 1.9f, u * 1.0f))
            }
        }

        // ---- Layer 2: mountains + lake, faded out on the left and at the bottom ----
        Canvas(
            Modifier.fillMaxSize()
                .graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }
                .drawWithContent {
                    drawContent()
                    drawRect(
                        Brush.horizontalGradient(0f to Color.Transparent, 0.34f to Color.Transparent, 0.62f to Color.Black, 1f to Color.Black),
                        blendMode = BlendMode.DstIn
                    )
                    drawRect(
                        Brush.verticalGradient(0f to Color.Black, 0.78f to Color.Black, 1f to Color.Transparent),
                        blendMode = BlendMode.DstIn
                    )
                }
        ) {
            val w = size.width
            val h = size.height
            val base = h * 0.82f

            fun ridge(color: Color, pts: List<Pair<Float, Float>>) {
                val p = Path().apply {
                    moveTo(w * pts.first().first, base)
                    pts.forEach { lineTo(w * it.first, h * it.second) }
                    lineTo(w * pts.last().first, base)
                    close()
                }
                drawPath(p, color)
            }

            fun mist(alpha: Float, y0: Float, y1: Float) {
                drawRect(
                    Brush.verticalGradient(listOf(Color.Transparent, sky.horizon.copy(alpha = alpha), Color.Transparent), h * y0, h * y1),
                    topLeft = Offset(0f, h * y0), size = Size(w, h * (y1 - y0))
                )
            }

            ridge(sky.far, listOf(0.30f to 0.80f, 0.40f to 0.54f, 0.47f to 0.61f, 0.58f to 0.38f, 0.66f to 0.54f, 0.74f to 0.46f, 0.85f to 0.58f, 0.93f to 0.50f, 1f to 0.56f))
            mist(0.40f, 0.52f, 0.76f)
            ridge(sky.mid, listOf(0.45f to 0.80f, 0.55f to 0.63f, 0.63f to 0.69f, 0.72f to 0.52f, 0.82f to 0.67f, 0.90f to 0.60f, 1f to 0.68f))
            mist(0.30f, 0.62f, 0.80f)
            ridge(sky.near, listOf(0.58f to 0.80f, 0.74f to 0.71f, 0.88f to 0.75f, 1f to 0.67f))

            // Lake with a short sun / moon reflection
            drawRect(
                Brush.verticalGradient(listOf(sky.lake, sky.lake.copy(alpha = 0.55f)), base, h),
                topLeft = Offset(0f, base), size = Size(w, h - base)
            )
            val tSun = (minute - 360f) / 720f
            val tMoon = ((minute - 1080f + 1440f) % 1440f) / 720f
            val isSun = tSun >= 0f && tSun <= 1f
            val tt = if (isSun) tSun else tMoon.coerceIn(0f, 1f)
            val alt = sin(PI.toFloat() * tt)
            val rx = w * 0.54f + w * 0.39f * tt
            val refl = if (isSun) lerp(Color(0xFFFFF3C4), Color(0xFFFF9A55), (1f - alt * 1.6f).coerceIn(0f, 1f)) else Color(0xFFE6ECFF)
            for (n in 0 until 3) {
                val yy = base + (h - base) * (0.22f + n * 0.24f)
                val half = w * (0.07f - n * 0.015f)
                drawLine(
                    refl.copy(alpha = (0.45f - n * 0.12f) * (alt * 2f).coerceIn(0f, 1f)),
                    Offset(rx - half, yy), Offset(rx + half, yy), strokeWidth = 1.6.dp.toPx()
                )
            }
        }
    }
}

/**
 * Compact home header: the live sky behind a big greeting, a small profile circle,
 * and a glass card (passed in as [bottomCard]) that overlaps the bottom of the sky.
 */
@Composable
fun MistyHeader(
    minute: Int, greeting: String, name: String, tagline: String,
    onProfile: () -> Unit, bottomCard: @Composable BoxScope.() -> Unit
) {
    val sky = skyAt(minute.toFloat())
    val ink = inkFor(sky)

    Box(Modifier.fillMaxWidth()) {
        MistyLandscape(minute.toFloat(), Modifier.fillMaxWidth().height(190.dp))
        Column(Modifier.padding(start = 20.dp, top = 18.dp, end = 120.dp)) {
            Text(greeting, style = IOSType.largeTitle.copy(fontSize = 32.sp, lineHeight = 36.sp), color = ink)
            Text(
                "Halo, $name · $tagline", style = IOSType.caption.copy(fontSize = 13.sp), color = ink.copy(alpha = 0.85f),
                modifier = Modifier.padding(top = 6.dp), maxLines = 2
            )
        }
        Box(
            Modifier.align(Alignment.TopEnd).padding(top = 10.dp, end = 12.dp).size(44.dp)
                .semantics { contentDescription = "Profil, ketuk untuk mengubah nama" }
                .iosPress(Role.Button, onProfile),
            contentAlignment = Alignment.Center
        ) {
            Box(
                Modifier.size(34.dp).clip(CircleShape).background(Color(0xFF2E5B4A).copy(alpha = 0.92f)),
                contentAlignment = Alignment.Center
            ) { Text(name.take(1).uppercase(), style = IOSType.headline.copy(fontSize = 15.sp), color = Color.White) }
        }
        Column(Modifier.fillMaxWidth()) {
            Spacer(Modifier.height(126.dp))
            Box(Modifier.fillMaxWidth().padding(horizontal = 16.dp), content = bottomCard)
        }
    }
}
