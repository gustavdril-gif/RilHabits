package com.airil.rillrebirth.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import com.airil.rillrebirth.WorkoutExercise
import com.airil.rillrebirth.WorkoutStore
import com.airil.rillrebirth.ui.components.GuideSheet
import com.airil.rillrebirth.ui.components.IOSCard
import com.airil.rillrebirth.ui.components.OutlineButton
import com.airil.rillrebirth.ui.components.PrimaryButton
import com.airil.rillrebirth.ui.components.RillNav
import com.airil.rillrebirth.ui.components.ScreenScaffold
import com.airil.rillrebirth.ui.components.SegmentRing
import com.airil.rillrebirth.ui.components.TimerEngine
import com.airil.rillrebirth.ui.components.WheelPicker
import com.airil.rillrebirth.ui.theme.IOS
import com.airil.rillrebirth.ui.theme.IOSType
import java.util.Locale

/** Free timer (flow = -1) or the rest timer between exercises (flow = workout id). */
@Composable
fun TimerScreen(nav: RillNav, flow: Long) {
    val ctx = LocalContext.current
    val c = IOS.colors
    val e = TimerEngine
    val view = LocalView.current
    DisposableEffect(e.state) { view.keepScreenOn = e.state == 1; onDispose { view.keepScreenOn = false } }

    var seen by remember { mutableIntStateOf(e.finishedCount) }
    LaunchedEffect(e.finishedCount) {
        if (e.finishedCount != seen) { seen = e.finishedCount; if (flow >= 0) nav.back() }
    }

    var mins by remember { mutableIntStateOf((e.configured / 60).toInt().coerceIn(0, 99)) }
    var secs by remember { mutableIntStateOf((e.configured % 60).toInt()) }
    var guide by remember { mutableStateOf<String?>(null) }

    val next: WorkoutExercise? = remember(flow) {
        if (flow < 0) null else {
            val s = WorkoutStore.load(ctx).find { it.id == flow }
            if (s == null) null else {
                val checked = WorkoutStore.exerciseChecks(ctx, flow)
                val idx = (0 until s.exercises.size).firstOrNull { !checked.contains(it) }
                if (idx == null) null else s.exercises[idx]
            }
        }
    }

    ScreenScaffold(title = if (flow >= 0) "Istirahat" else "Timer", onBack = { nav.back() }) {
        if (next != null) {
            item {
                Text(
                    "Berikutnya: ${next.name} · ${next.sets} set × ${next.reps} — ketuk untuk panduan",
                    style = IOSType.body, color = c.textSecondary,
                    modifier = Modifier.padding(horizontal = 4.dp).fillMaxWidth().clickableNoRipple { guide = next.name }
                )
            }
        }
        item {
            IOSCard {
                Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                    if (e.state == 0) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
                            WheelPicker(100, mins) { mins = it; e.configure((mins * 60 + secs).toLong().coerceAtLeast(1L)) }
                            Text(":", style = IOSType.number, color = c.primaryText, modifier = Modifier.width(24.dp))
                            WheelPicker(60, secs) { secs = it; e.configure((mins * 60 + secs).toLong().coerceAtLeast(1L)) }
                        }
                        Text("menit  ·  detik", style = IOSType.caption, color = c.textSecondary)
                        Text("Gulir angka ke atas atau ke bawah untuk mengatur waktu.", style = IOSType.caption, color = c.textSecondary, modifier = Modifier.padding(top = 4.dp, bottom = 12.dp))
                    } else {
                        val frac = if (e.configured <= 0) 0f else ((e.configured - e.remaining).toFloat() / e.configured).coerceIn(0f, 1f)
                        SegmentRing(listOf(frac to c.orange), Modifier.size(220.dp), 16.dp) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(String.format(Locale.US, "%02d:%02d", e.remaining / 60, e.remaining % 60), style = IOSType.number, color = c.textPrimary)
                                Text(if (e.state == 1) "berjalan" else "dijeda", style = IOSType.caption, color = c.textSecondary)
                            }
                        }
                    }
                    if (e.state == 0) PrimaryButton("Mulai") { e.configure((mins * 60 + secs).toLong().coerceAtLeast(1L)); e.start() }
                    else Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlineButton("Berhenti", Modifier.weight(1f)) { e.stop() }
                        PrimaryButton(if (e.state == 1) "Jeda" else "Lanjut", Modifier.weight(1f)) { if (e.state == 1) e.pause() else e.start() }
                    }
                }
            }
        }
    }
    guide?.let { GuideSheet(it) { guide = null } }
}

private fun Modifier.clickableNoRipple(onClick: () -> Unit): Modifier = this.then(
    Modifier.clickable(
        interactionSource = androidx.compose.foundation.interaction.MutableInteractionSource(),
        indication = null, onClick = onClick
    )
)
