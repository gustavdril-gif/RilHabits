package com.airil.rillrebirth.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.airil.rillrebirth.Smart
import com.airil.rillrebirth.ui.theme.IOS
import com.airil.rillrebirth.ui.theme.IOSType

/** Monday-first order of Calendar.DAY_OF_WEEK values. */
val WeekOrder = listOf(2, 3, 4, 5, 6, 7, 1)

@Composable
fun ScreenScaffold(
    title: String,
    onBack: () -> Unit,
    subtitle: String? = null,
    trailing: (@Composable () -> Unit)? = null,
    content: LazyListScope.() -> Unit
) {
    val c = IOS.colors
    LazyColumn(
        modifier = Modifier.fillMaxSize().background(c.background),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 40.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Column {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.height(44.dp).clip(RoundedCornerShape(22.dp)).semantics { contentDescription = "Kembali" }.iosPress(Role.Button, onBack).padding(horizontal = 8.dp),
                        contentAlignment = Alignment.CenterStart
                    ) { Text("‹ Kembali", style = IOSType.headline, color = c.primaryText) }
                    Spacer(Modifier.weight(1f))
                    trailing?.invoke()
                }
                Text(title, style = IOSType.largeTitle, color = c.textPrimary, modifier = Modifier.padding(start = 4.dp))
                if (subtitle != null) Text(subtitle, style = IOSType.body, color = c.textSecondary, modifier = Modifier.padding(start = 4.dp))
            }
        }
        content()
    }
}

@Composable
fun IOSField(
    value: String, onChange: (String) -> Unit, placeholder: String, modifier: Modifier = Modifier,
    singleLine: Boolean = false, minLines: Int = 1, numeric: Boolean = false
) {
    val c = IOS.colors
    BasicTextField(
        value = value, onValueChange = onChange,
        singleLine = singleLine, minLines = minLines,
        keyboardOptions = KeyboardOptions(keyboardType = if (numeric) KeyboardType.Number else KeyboardType.Text),
        textStyle = IOSType.body.copy(color = c.textPrimary),
        cursorBrush = SolidColor(c.primary),
        modifier = modifier.fillMaxWidth(),
        decorationBox = { inner ->
            Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(c.background).padding(12.dp)) {
                if (value.isEmpty()) Text(placeholder, style = IOSType.body, color = c.textSecondary)
                inner()
            }
        }
    )
}

@Composable
fun ChoiceChip(label: String, selected: Boolean, onClick: () -> Unit) {
    val c = IOS.colors
    val bg = if (selected) (if (c.dark) c.primary else c.primaryText) else c.track.copy(alpha = if (c.dark) 0.7f else 0.9f)
    val fg = if (selected) (if (c.dark) Color(0xFF10261A) else Color.White) else c.textPrimary
    Box(Modifier.clip(RoundedCornerShape(50)).background(bg).iosPress(Role.Button, onClick).padding(horizontal = 14.dp, vertical = 9.dp)) {
        Text(label, style = IOSType.body.copy(fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal), color = fg)
    }
}

/** Horizontally scrolling row of chips. */
@Composable
fun ChipRow(content: @Composable () -> Unit) {
    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) { content() }
}

@Composable
fun DayPicker(selected: Set<Int>, onChange: (Set<Int>) -> Unit) {
    val c = IOS.colors
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        WeekOrder.forEach { d ->
            val on = selected.contains(d)
            Box(
                Modifier.weight(1f).height(40.dp).clip(RoundedCornerShape(12.dp))
                    .background(if (on) (if (c.dark) c.primary else c.primaryText) else c.track.copy(alpha = if (c.dark) 0.7f else 0.9f))
                    .iosPress(Role.Checkbox) { onChange(if (on) selected - d else selected + d) },
                contentAlignment = Alignment.Center
            ) {
                Text(Smart.weekdayLabel(d), style = IOSType.caption.copy(fontWeight = FontWeight.SemiBold), color = if (on) (if (c.dark) Color(0xFF10261A) else Color.White) else c.textPrimary)
            }
        }
    }
    Spacer(Modifier.height(8.dp))
    ChipRow {
        ChoiceChip("Tiap hari", selected.size == 7) { onChange(WeekOrder.toSet()) }
        ChoiceChip("Sen–Jum", selected == WeekOrder.take(5).toSet()) { onChange(WeekOrder.take(5).toSet()) }
        ChoiceChip("Sab–Min", selected == WeekOrder.drop(5).toSet()) { onChange(WeekOrder.drop(5).toSet()) }
    }
}

@Composable
fun ConfirmDialog(title: String, message: String, confirm: String, onConfirm: () -> Unit, onDismiss: () -> Unit) {
    val c = IOS.colors
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { Text(message) },
        confirmButton = { TextButton(onClick = onConfirm) { Text(confirm, color = c.red) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun IOSSheet(onDismiss: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    val c = IOS.colors
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = c.card
    ) {
        Column(Modifier.fillMaxWidth().imePadding().verticalScroll(rememberScrollState()).padding(start = 20.dp, end = 20.dp, bottom = 28.dp), content = content)
    }
}

@Composable
fun FieldLabel(text: String) {
    Text(text, style = IOSType.caption.copy(fontWeight = FontWeight.SemiBold), color = IOS.colors.textSecondary, modifier = Modifier.padding(top = 14.dp, bottom = 6.dp))
}
