package com.airil.rillrebirth.ui.screens

import android.content.Context
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.airil.rillrebirth.R
import com.airil.rillrebirth.RillTask
import com.airil.rillrebirth.Smart
import com.airil.rillrebirth.SkyView
import com.airil.rillrebirth.ui.components.CircleCheck
import com.airil.rillrebirth.ui.components.EmojiBadge
import com.airil.rillrebirth.ui.components.EmptyState
import com.airil.rillrebirth.ui.components.IOSCard
import com.airil.rillrebirth.ui.components.Pill
import com.airil.rillrebirth.ui.components.SectionTitle
import com.airil.rillrebirth.ui.components.SegmentRing
import com.airil.rillrebirth.ui.components.ThinBar
import com.airil.rillrebirth.ui.components.iosPress
import com.airil.rillrebirth.ui.data.TodayData
import com.airil.rillrebirth.ui.theme.IOS
import com.airil.rillrebirth.ui.theme.IOSType
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

@Composable
fun BerandaScreen(refresh: Int, openLegacy: (String) -> Unit) {
    val ctx = LocalContext.current
    val c = IOS.colors
    val haptic = LocalHapticFeedback.current
    var tick by remember { mutableIntStateOf(0) }
    val snap = remember(refresh, tick) { TodayData.snapshot(ctx) }

    val cal = Calendar.getInstance()
    val hour = cal.get(Calendar.HOUR_OF_DAY)
    val phase = Smart.phaseOf(hour)
    val greeting = when (phase) { 0 -> "Selamat pagi"; 1 -> "Selamat siang"; 2 -> "Selamat sore"; else -> "Selamat malam" }
    val dateText = remember(refresh) { SimpleDateFormat("EEEE, d MMMM", Locale("id", "ID")).format(Date()) }

    val prayerDone = snap.prayer.count { snap.done.contains(it.id) }
    val otherDone = snap.other.count { snap.done.contains(it.id) }
    val total = snap.totalCount.coerceAtLeast(1)
    val segments = listOf(
        prayerDone.toFloat() / total to c.primary,
        snap.workoutDone.toFloat() / total to c.orange,
        otherDone.toFloat() / total to c.blue
    )
    val level = snap.totalXp / 100 + 1
    val xpIn = snap.totalXp % 100

    val now = TodayData.nowMinutes()
    val pending = snap.live.filter { !snap.done.contains(it.id) }.sortedBy { TodayData.minutes(ctx, it) }
    val focus = (pending.filter { TodayData.minutes(ctx, it) >= now } + pending.filter { TodayData.minutes(ctx, it) < now }).take(2)

    LazyColumn(
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 120.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Beranda", style = IOSType.largeTitle, color = c.textPrimary)
                    Text(dateText, style = IOSType.body, color = c.textSecondary)
                }
                Box(
                    Modifier.size(48.dp).clip(RoundedCornerShape(24.dp)).iosPress(Role.Button) { openLegacy("Jadwal") },
                    contentAlignment = Alignment.Center
                ) { Icon(painterResource(R.drawable.ic_calendar), contentDescription = "Buka jadwal", tint = c.primaryText, modifier = Modifier.size(26.dp)) }
            }
        }
        item {
            val light = SkyView.lightText(phase)
            val main = if (light) Color.White else Color(SkyView.darkInk(phase))
            Box(Modifier.fillMaxWidth().height(150.dp).clip(RoundedCornerShape(28.dp))) {
                AndroidView(factory = { SkyView(it, phase, hour + cal.get(Calendar.MINUTE) / 60f) }, modifier = Modifier.matchParentSize())
                Column(Modifier.align(Alignment.BottomStart).padding(20.dp)) {
                    Text(greeting, style = IOSType.title, color = main)
                    Text(
                        if (snap.totalCount == 0) "Belum ada kegiatan hari ini" else "${snap.doneCount} dari ${snap.totalCount} sudah beres",
                        style = IOSType.body, color = main
                    )
                }
            }
        }
        item {
            IOSCard {
                Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                    SegmentRing(segments, Modifier.size(190.dp)) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("Hari ini", style = IOSType.caption, color = c.textSecondary)
                            Text("${snap.doneCount}/${snap.totalCount}", style = IOSType.number, color = c.textPrimary)
                            Text("kebiasaan", style = IOSType.caption, color = c.textSecondary)
                        }
                    }
                    Row(Modifier.padding(top = 14.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Pill("Ibadah $prayerDone/${snap.prayer.size}", c.primary)
                        Pill("Workout ${snap.workoutDone}/${snap.workoutTotal}", c.orange)
                        Pill("Lainnya $otherDone/${snap.other.size}", c.blue)
                    }
                }
            }
        }
        item {
            IOSCard {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("Level $level · ${Smart.levelTitle(level)}", style = IOSType.headline, color = c.textPrimary, modifier = Modifier.weight(1f))
                    Text("$xpIn/100 XP", style = IOSType.caption, color = c.textSecondary)
                }
                Box(Modifier.padding(top = 10.dp)) { ThinBar(xpIn / 100f, c.primary) }
            }
        }
        item { SectionTitle("Fokus hari ini") }
        if (focus.isEmpty()) {
            item {
                if (snap.totalCount == 0) EmptyState("🌱", "Belum ada kegiatan", "Tambahkan kebiasaan di menu Jadwal untuk mulai.", "Buka Jadwal") { openLegacy("Jadwal") }
                else EmptyState("🎉", "Semua beres", "Kamu sudah menyelesaikan semua kegiatan hari ini.")
            }
        } else {
            items(focus, key = { it.id }) { t ->
                FocusCard(ctx, t) {
                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    TodayData.setDone(ctx, t.id, true)
                    tick++
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StreakCard("🔥", "${snap.streak} hari", "Streak", Modifier.weight(1f), c.orange, pulse = snap.streak > 0)
                StreakCard("🏆", "${snap.bestStreak} hari", "Streak terbaik", Modifier.weight(1f), c.primary, pulse = false)
            }
        }
        item { SectionTitle("Lainnya") }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                MoreCard("📝", "Catatan & Target", Modifier.weight(1f)) { openLegacy("Home") }
                MoreCard("🏃", "Jogging", Modifier.weight(1f)) { openLegacy("Workout|jogging") }
            }
        }
    }
}

@Composable
private fun FocusCard(ctx: Context, t: RillTask, onDone: () -> Unit) {
    val c = IOS.colors
    val badge = TodayData.emojiFor(t)
    val sub = "${TodayData.timeLabel(ctx, t)} • ${if (Smart.isPrayer(t)) "Prioritas" else t.category} • ${t.xp} XP"
    IOSCard(Modifier.semantics { contentDescription = "${t.name}, $sub" }) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            EmojiBadge(badge, if (Smart.isPrayer(t)) c.primary else c.blue)
            Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                Text(t.name, style = IOSType.headline, color = c.textPrimary)
                Text(sub, style = IOSType.caption, color = c.textSecondary)
            }
            CircleCheck(checked = false, label = "Selesaikan ${t.name}") { if (it) onDone() }
        }
    }
}

@Composable
private fun StreakCard(emoji: String, value: String, label: String, modifier: Modifier, accent: Color, pulse: Boolean) {
    val c = IOS.colors
    val t = rememberInfiniteTransition(label = "fire")
    val s by t.animateFloat(1f, if (pulse) 1.18f else 1f, infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "scale")
    IOSCard(modifier.semantics { contentDescription = "$label $value" }) {
        Text(emoji, style = IOSType.title, modifier = Modifier.graphicsLayer { scaleX = s; scaleY = s })
        Text(value, style = IOSType.title, color = accent.let { if (c.dark) it else c.textPrimary }, modifier = Modifier.padding(top = 4.dp))
        Text(label, style = IOSType.caption, color = c.textSecondary)
    }
}

@Composable
private fun MoreCard(emoji: String, title: String, modifier: Modifier, onClick: () -> Unit) {
    val c = IOS.colors
    IOSCard(modifier.iosPress(Role.Button, onClick)) {
        Text(emoji, style = IOSType.title)
        Text(title, style = IOSType.headline, color = c.textPrimary, modifier = Modifier.padding(top = 4.dp))
        Text("Buka", style = IOSType.caption, color = c.primaryText)
    }
}
