package com.airil.rillrebirth.ui.screens

import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp
import com.airil.rillrebirth.ProgSession
import com.airil.rillrebirth.Programs
import com.airil.rillrebirth.ReadyProgram
import com.airil.rillrebirth.ReminderScheduler
import com.airil.rillrebirth.RunTracker
import com.airil.rillrebirth.Smart
import com.airil.rillrebirth.TaskStore
import com.airil.rillrebirth.WorkoutExercise
import com.airil.rillrebirth.WorkoutSession
import com.airil.rillrebirth.WorkoutStore
import com.airil.rillrebirth.ui.components.EmojiBadge
import com.airil.rillrebirth.ui.components.EmptyState
import com.airil.rillrebirth.ui.components.IOSCard
import com.airil.rillrebirth.ui.components.OutlineButton
import com.airil.rillrebirth.ui.components.PrimaryButton
import com.airil.rillrebirth.ui.components.SectionTitle
import com.airil.rillrebirth.ui.components.SegmentedControl
import com.airil.rillrebirth.ui.components.iosPress
import com.airil.rillrebirth.ui.theme.IOS
import com.airil.rillrebirth.ui.theme.IOSType

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WorkoutScreen(refresh: Int, openLegacy: (String) -> Unit) {
    val ctx = LocalContext.current
    val c = IOS.colors
    var seg by rememberSaveable { mutableIntStateOf(0) }
    var tick by remember { mutableIntStateOf(0) }
    var sheet by remember { mutableStateOf<ReadyProgram?>(null) }
    val sessions = remember(refresh, tick) { WorkoutStore.sessionsForDate(ctx) }
    val doneIds = remember(refresh, tick) { sessions.filter { WorkoutStore.isDone(ctx, it.id) }.map { it.id }.toSet() }
    val stats = remember(refresh, tick) { Smart.dayStats(ctx, TaskStore.load(ctx), 365) }

    Column(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 12.dp)) {
            Text("Workout", style = IOSType.largeTitle, color = c.textPrimary, modifier = Modifier.padding(start = 4.dp, bottom = 10.dp))
            SegmentedControl(listOf("Hari Ini", "Program", "Timer"), seg) { seg = it }
        }
        when (seg) {
            0 -> LazyColumn(contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 120.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                if (sessions.isEmpty()) {
                    item { EmptyState("🗓️", "Tidak ada sesi hari ini", "Bikin jadwal workout sendiri atau pakai program siap pakai.", "Bikin Jadwal") { openLegacy("Workout|builder") } }
                }
                items(sessions, key = { it.id }) { s ->
                    val done = doneIds.contains(s.id)
                    IOSCard {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            EmojiBadge(if (done) "✅" else "💪", c.primary, 44.dp)
                            Column(Modifier.padding(start = 12.dp)) {
                                Text(s.name, style = IOSType.title, color = c.textPrimary)
                                Text("${s.time} • ${s.durationMinutes} min • ${s.exercises.size} exercise", style = IOSType.body, color = c.textSecondary)
                            }
                        }
                        Spacer(Modifier.height(12.dp))
                        if (done) OutlineButton("Selesai ✓ · Lihat detail") { openLegacy("Workout|workout:${s.id}") }
                        else PrimaryButton("Mulai Sesi") { openLegacy("Workout|workout:${s.id}") }
                    }
                }
                item {
                    IOSCard {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            EmojiBadge("🏃", c.blue, 44.dp)
                            Column(Modifier.padding(start = 12.dp)) {
                                Text("Jogging", style = IOSType.title, color = c.textPrimary)
                                Text(
                                    if (RunTracker.active) "Sedang merekam • ${String.format(java.util.Locale.US, "%.2f", RunTracker.distM / 1000.0)} km"
                                    else "Offline tracking • Lokasi & langkah akan tersimpan",
                                    style = IOSType.body, color = c.textSecondary
                                )
                            }
                        }
                        Spacer(Modifier.height(12.dp))
                        OutlineButton(if (RunTracker.active) "Lanjutkan rekaman" else "Buka Jogging") { openLegacy("Workout|jogging") }
                    }
                }
                item { SectionTitle("Statistik") }
                item {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        IOSCard(Modifier.weight(1f)) {
                            Text("🔥 Streak workout", style = IOSType.caption, color = c.textSecondary)
                            Text("${Smart.workoutStreak(stats)} hari", style = IOSType.title, color = c.textPrimary, modifier = Modifier.padding(top = 4.dp))
                        }
                        IOSCard(Modifier.weight(1f)) {
                            Text("🏆 Rekor terbaik", style = IOSType.caption, color = c.textSecondary)
                            Text("${Smart.bestWorkoutStreak(stats)} hari", style = IOSType.title, color = c.textPrimary, modifier = Modifier.padding(top = 4.dp))
                        }
                    }
                }
            }
            1 -> LazyColumn(contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 120.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                item { Text("Program siap pakai. Ketuk untuk melihat isinya.", style = IOSType.body, color = c.textSecondary, modifier = Modifier.padding(start = 4.dp)) }
                items(Programs.all, key = { it.name }) { p ->
                    val perWeek = p.sessions.sumOf { it.days.size }
                    IOSCard(Modifier.iosPress(Role.Button) { sheet = p }) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(p.emoji, style = IOSType.title)
                            Column(Modifier.weight(1f).padding(start = 12.dp)) {
                                Text(p.name, style = IOSType.headline, color = c.textPrimary)
                                Text("${p.level} • $perWeek sesi/minggu", style = IOSType.caption, color = c.textSecondary)
                            }
                        }
                        Text(p.desc, style = IOSType.body, color = c.textSecondary, modifier = Modifier.padding(top = 8.dp))
                    }
                }
            }
            else -> Column(Modifier.verticalScroll(rememberScrollState()).padding(start = 16.dp, end = 16.dp, bottom = 120.dp)) {
                IOSCard {
                    Text("⏱️ Timer istirahat", style = IOSType.title, color = c.textPrimary)
                    Text("Atur durasi dengan menggulir angka, lalu mulai. Cocok untuk jeda antar-set.", style = IOSType.body, color = c.textSecondary, modifier = Modifier.padding(top = 4.dp, bottom = 12.dp))
                    PrimaryButton("Buka Timer") { openLegacy("Workout|timer") }
                }
            }
        }
    }

    val p = sheet
    if (p != null) {
        ModalBottomSheet(
            onDismissRequest = { sheet = null },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
            containerColor = c.card
        ) {
            Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(start = 20.dp, end = 20.dp, bottom = 28.dp)) {
                Text("${p.emoji} ${p.name}", style = IOSType.title, color = c.textPrimary)
                Text(p.desc, style = IOSType.body, color = c.textSecondary, modifier = Modifier.padding(top = 4.dp, bottom = 8.dp))
                p.sessions.forEach { ps ->
                    val days = ps.days.sortedBy { (it + 5) % 7 }.joinToString(" ") { Smart.weekdayLabel(it) }
                    Text("${ps.name} • $days • ${ps.duration} mnt", style = IOSType.headline, color = c.textPrimary, modifier = Modifier.padding(top = 10.dp))
                    ps.exercises.forEach { ex -> Text("• ${ex.name} — ${ex.sets} × ${ex.reps}", style = IOSType.body, color = c.textSecondary, modifier = Modifier.padding(top = 2.dp)) }
                }
                Spacer(Modifier.height(16.dp))
                PrimaryButton("PAKAI PROGRAM") {
                    applyProgram(ctx, p)
                    sheet = null; seg = 0; tick++
                }
            }
        }
    }
}

private fun applyProgram(ctx: android.content.Context, p: ReadyProgram) {
    val all = WorkoutStore.load(ctx)
    p.sessions.forEachIndexed { i, ps: ProgSession ->
        all.add(WorkoutSession(System.currentTimeMillis() + i, ps.name, p.time, ps.duration, ps.days.toMutableSet(), "", p.desc, false, true, ps.exercises.map { WorkoutExercise(it.name, it.sets, it.reps) }.toMutableList()))
    }
    WorkoutStore.save(ctx, all)
    ReminderScheduler.scheduleAll(ctx)
    Toast.makeText(ctx, "${p.name} ditambahkan ke jadwal workout ✓", Toast.LENGTH_LONG).show()
}
