package com.airil.rillrebirth

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import com.airil.rillrebirth.ui.components.IOSBottomBar
import com.airil.rillrebirth.ui.screens.BerandaScreen
import com.airil.rillrebirth.ui.screens.ChecklistScreen
import com.airil.rillrebirth.ui.screens.StatistikScreen
import com.airil.rillrebirth.ui.screens.WorkoutScreen
import com.airil.rillrebirth.ui.theme.IOS
import com.airil.rillrebirth.ui.theme.RillTheme

/** Single Compose host. Tabs that are not migrated yet open the previous View-based MainActivity. */
class ComposeActivity : ComponentActivity() {
    private val resumeTick = mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ReminderScheduler.scheduleAll(this)
        setContent {
            RillTheme {
                RillApp(resumeTick.intValue) { key ->
                    val parts = key.split("|")
                    val i = Intent(this, MainActivity::class.java).putExtra("tab", parts[0])
                    if (parts.size > 1) i.putExtra("open", parts[1])
                    startActivity(i)
                }
            }
        }
    }

    override fun onResume() { super.onResume(); resumeTick.intValue = resumeTick.intValue + 1 }

    override fun onPause() { super.onPause(); RillWidget.updateAll(this) }
}

@Composable
private fun RillApp(refresh: Int, openLegacy: (String) -> Unit) {
    val c = IOS.colors
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val view = LocalView.current
    val ctx = LocalContext.current
    SideEffect {
        val w = (ctx as Activity).window
        w.statusBarColor = c.background.toArgb()
        w.navigationBarColor = c.background.toArgb()
        val ctl = WindowCompat.getInsetsController(w, view)
        ctl.isAppearanceLightStatusBars = !c.dark
        ctl.isAppearanceLightNavigationBars = !c.dark
    }
    Box(Modifier.fillMaxSize().background(c.background)) {
        when (tab) {
            0 -> BerandaScreen(refresh, openLegacy)
            1 -> ChecklistScreen(refresh, openLegacy)
            2 -> WorkoutScreen(refresh, openLegacy)
            else -> StatistikScreen(refresh)
        }
        IOSBottomBar(selected = tab, onSelect = { tab = it }, modifier = Modifier.align(Alignment.BottomCenter))
    }
}
