package com.airil.rillrebirth.ui.screens

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.airil.rillrebirth.Smart
import com.airil.rillrebirth.TaskStore
import com.airil.rillrebirth.ui.components.EmptyState
import com.airil.rillrebirth.ui.components.IOSCard
import com.airil.rillrebirth.ui.components.SectionTitle
import com.airil.rillrebirth.ui.theme.IOS
import com.airil.rillrebirth.ui.theme.IOSType
import kotlin.math.roundToInt

private val monthShort = listOf("Jan", "Feb", "Mar", "Apr", "Mei", "Jun", "Jul", "Agu", "Sep", "Okt", "Nov", "Des")
private val dayHead = listOf("Sen", "Sel", "Rab", "Kam", "Jum", "Sab", "Min")

private data class StatsResult(
    val consistency: Int, val delta: Int, val mood: Float?, val workouts7: Int,
    val heat: List<Float?>,            // 84 cells, week rows x weekday columns (Mon..Sun), null = future
    val rowMonths: List<String>, val activeDays: Int,
    val weekly: List<Float>, val weekLabels: List<String>,
    val insights: List<String>, val hasData: Boolean
)

private fun avgRate(l: List<com.airil.rillrebirth.DayStat>): Float {
    val r = l.filter { it.total > 0 }.map { it.rate }
    return if (r.isEmpty()) 0f else r.sum() / r.size
}

private fun build(ctx: Context): StatsResult {
    val tasks = TaskStore.load(ctx)
    val stats = Smart.dayStats(ctx, tasks, 365)
    val last7 = stats.takeLast(7)
    val prev7 = stats.dropLast(7).takeLast(7)
    val c1 = avgRate(last7); val c0 = avgRate(prev7)
    val moods = Smart.moodSeries(ctx, 0).first.filterNotNull()
    // heatmap: 12 week rows ending with the current week (Monday first)
    val cal = java.util.Calendar.getInstance()
    val todayIdx = (cal.get(java.util.Calendar.DAY_OF_WEEK) + 5) % 7
    val cells = ArrayList<Float?>()
    val months = ArrayList<String>()
    var active = 0
    for (k in 0 until 84) {
        val daysAgo = (todayIdx + 77) - k
        if (daysAgo < 0) { cells.add(null); continue }
        val st = stats.getOrNull(stats.size - 1 - daysAgo)
        if (st == null) { cells.add(0f); continue }
        cells.add(if (st.total == 0) 0f else st.rate)
        if (st.done > 0) active++
    }
    var prevMonth = -1
    for (r in 0 until 12) {
        val daysAgo = (todayIdx + 77) - r * 7
        val st = stats.getOrNull(stats.size - 1 - daysAgo)
        val m = st?.date?.substring(5, 7)?.toIntOrNull() ?: -1
        months.add(if (m != -1 && m != prevMonth) monthShort[(m - 1).coerceIn(0, 11)] else "")
        if (m != -1) prevMonth = m
    }
    val chunks = stats.takeLast(56).chunked(7)
    val weekly = chunks.map { avgRate(it) }
    val labels = chunks.map { ch -> val d = ch.first().date; "${d.substring(8).toIntOrNull() ?: 0}/${d.substring(5, 7).toIntOrNull() ?: 0}" }
    return StatsResult(
        (c1 * 100).roundToInt(), ((c1 - c0) * 100).roundToInt(),
        if (moods.isEmpty()) null else moods.sum() / moods.size, last7.sumOf { it.workoutDone },
        cells, months, active, weekly, labels,
        Smart.insights(ctx, tasks, stats), stats.any { it.done > 0 }
    )
}

@Composable
fun StatistikScreen(refresh: Int) {
    val ctx = LocalContext.current
    val c = IOS.colors
    val r = remember(refresh) { build(ctx) }

    LazyColumn(contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 120.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Column {
                Text("Statistik", style = IOSType.largeTitle, color = c.textPrimary, modifier = Modifier.padding(start = 4.dp))
                Text("Wawasan dari kebiasaanmu", style = IOSType.body, color = c.textSecondary, modifier = Modifier.padding(start = 4.dp))
            }
        }
        if (!r.hasData) {
            item { EmptyState("📊", "Belum ada data", "Centang beberapa kegiatan dulu. Statistik dan wawasan akan muncul di sini.") }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                TopCard("✅ Konsistensi", "${r.consistency}%", if (r.delta >= 0) "Minggu ini ↑${r.delta}%" else "Minggu ini ↓${-r.delta}%", Modifier.weight(1f))
                TopCard("😊 Mood", if (r.mood == null) "–" else String.format(java.util.Locale.US, "%.1f", r.mood), "skala 1–5 · 7 hari", Modifier.weight(1f))
                TopCard("💪 Workout", "${r.workouts7}x", "7 hari terakhir", Modifier.weight(1f))
            }
        }
        item { SectionTitle("Aktivitas 12 minggu") }
        item {
            IOSCard {
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Spacer(Modifier.width(30.dp))
                    dayHead.forEach { Text(it, Modifier.weight(1f), style = IOSType.caption.copy(fontSize = 10.sp), color = c.textSecondary, textAlign = TextAlign.Center) }
                }
                Spacer(Modifier.height(6.dp))
                for (row in 0 until 12) {
                    Row(Modifier.padding(vertical = 2.dp), horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(r.rowMonths[row], Modifier.width(30.dp), style = IOSType.caption.copy(fontSize = 10.sp), color = c.textSecondary)
                        for (col in 0 until 7) {
                            val v = r.heat[row * 7 + col]
                            val color = when {
                                v == null -> Color.Transparent
                                v <= 0f -> c.track
                                v < 0.34f -> c.primary.copy(alpha = 0.35f)
                                v < 0.67f -> c.primary.copy(alpha = 0.6f)
                                v < 1f -> c.primary.copy(alpha = 0.85f)
                                else -> c.primary
                            }
                            Box(Modifier.weight(1f).aspectRatio(1f).clip(RoundedCornerShape(4.dp)).background(color))
                        }
                    }
                }
                Text("Aktif ${r.activeDays} dari 84 hari", style = IOSType.caption, color = c.textSecondary, modifier = Modifier.padding(top = 8.dp))
            }
        }
        item { SectionTitle("Konsistensi mingguan") }
        item {
            IOSCard {
                Row(Modifier.fillMaxWidth().height(120.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.Bottom) {
                    r.weekly.forEachIndexed { i, v ->
                        Column(Modifier.weight(1f).fillMaxHeight(), verticalArrangement = Arrangement.Bottom, horizontalAlignment = Alignment.CenterHorizontally) {
                            Box(
                                Modifier.fillMaxWidth().height((8 + 100 * v).dp).clip(RoundedCornerShape(6.dp))
                                    .background(if (i == r.weekly.lastIndex) c.primary else c.primary.copy(alpha = 0.45f))
                            )
                        }
                    }
                }
                Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    r.weekLabels.forEach { Text(it, Modifier.weight(1f), style = IOSType.caption.copy(fontSize = 9.sp), color = c.textSecondary, textAlign = TextAlign.Center) }
                }
            }
        }
        item { SectionTitle("Smart insights") }
        if (r.insights.isEmpty()) item { EmptyState("💡", "Belum ada wawasan", "Beberapa hari lagi, dan pola kebiasaanmu mulai terlihat.") }
        itemsIndexed(r.insights.take(4)) { i, text ->
            val accent = when {
                text.lowercase().contains("lewat") -> c.red
                i % 3 == 0 -> c.blue
                i % 3 == 1 -> c.orange
                else -> c.primary
            }
            val emoji = if (accent == c.red) "⚠️" else if (accent == c.blue) "💡" else if (accent == c.orange) "⏰" else "🌱"
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(accent.copy(alpha = if (c.dark) 0.22f else 0.14f)).padding(16.dp),
                verticalAlignment = Alignment.Top
            ) {
                Text(emoji, style = IOSType.headline)
                Text(text, style = IOSType.body, color = c.textPrimary, modifier = Modifier.padding(start = 12.dp))
            }
        }
    }
}

@Composable
private fun TopCard(label: String, value: String, sub: String, modifier: Modifier) {
    val c = IOS.colors
    IOSCard(modifier) {
        Text(label, style = IOSType.caption, color = c.textSecondary)
        Text(value, style = IOSType.title.copy(fontSize = 28.sp), color = c.textPrimary, modifier = Modifier.padding(top = 4.dp))
        Text(sub, style = IOSType.caption.copy(fontSize = 10.sp), color = c.textSecondary)
    }
}
