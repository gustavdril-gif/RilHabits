package com.airil.rillrebirth.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.airil.rillrebirth.R
import com.airil.rillrebirth.ui.theme.IOS
import com.airil.rillrebirth.ui.theme.IOSType

data class BarTab(val label: String, val icon: Int)

val RillTabs = listOf(
    BarTab("Beranda", R.drawable.ic_home),
    BarTab("Habit", R.drawable.ic_checklist),
    BarTab("Workout", R.drawable.ic_workout),
    BarTab("Statistik", R.drawable.ic_stats)
)

/**
 * Floating 4-item pill. It is translucent; a real backdrop blur needs Android 12+ and a helper library,
 * so it is intentionally not used here (the app must run on Android 10).
 */
@Composable
fun IOSBottomBar(selected: Int, onSelect: (Int) -> Unit, modifier: Modifier = Modifier) {
    val c = IOS.colors
    val shape = RoundedCornerShape(28.dp)
    Row(
        modifier = modifier
            .padding(horizontal = 16.dp, vertical = 16.dp)
            .fillMaxWidth()
            .height(72.dp)
            .shadow(12.dp, shape, ambientColor = Color.Black.copy(alpha = 0.10f), spotColor = Color.Black.copy(alpha = 0.10f))
            .clip(shape)
            .background(c.bar)
            .padding(8.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically
    ) {
        RillTabs.forEachIndexed { i, tab ->
            val on = i == selected
            Box(
                modifier = Modifier
                    .weight(1f)
                    .height(56.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(if (on) c.primarySoft else Color.Transparent)
                    .semantics { this.selected = on }
                    .iosPress(Role.Tab) { onSelect(i) },
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(painterResource(tab.icon), contentDescription = null, tint = if (on) c.primaryText else c.textSecondary, modifier = Modifier.size(22.dp))
                    Text(tab.label, style = IOSType.caption.copy(fontSize = 11.sp), color = if (on) c.primaryText else c.textSecondary, modifier = Modifier.padding(top = 2.dp))
                }
            }
        }
    }
}
