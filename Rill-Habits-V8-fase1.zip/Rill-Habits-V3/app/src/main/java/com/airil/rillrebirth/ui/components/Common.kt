package com.airil.rillrebirth.ui.components

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.airil.rillrebirth.R
import com.airil.rillrebirth.ui.theme.IOS
import com.airil.rillrebirth.ui.theme.IOSType

/** Subtle iOS press feedback (scale 0.98) instead of the Android ripple. */
@Composable
fun Modifier.iosPress(role: Role? = null, onClick: () -> Unit): Modifier {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) 0.98f else 1f, label = "press")
    return this
        .graphicsLayer { scaleX = scale; scaleY = scale }
        .clickable(interactionSource = src, indication = null, role = role, onClick = onClick)
}

@Composable
fun IOSCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    val c = IOS.colors
    val shape = RoundedCornerShape(20.dp)
    Column(
        modifier = modifier
            .fillMaxWidth()
            .shadow(8.dp, shape, ambientColor = Color.Black.copy(alpha = 0.06f), spotColor = Color.Black.copy(alpha = 0.06f))
            .clip(shape)
            .background(c.card)
            .padding(16.dp),
        content = content
    )
}

@Composable
fun Pill(text: String, dot: Color) {
    val c = IOS.colors
    Row(
        modifier = Modifier.clip(RoundedCornerShape(50)).background(c.track.copy(alpha = if (c.dark) 0.6f else 0.7f)).padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(8.dp).clip(CircleShape).background(dot))
        Spacer(Modifier.width(6.dp))
        Text(text, style = IOSType.caption, color = c.textPrimary)
    }
}

/** Thin 4dp progress bar with a spring animation. */
@Composable
fun ThinBar(fraction: Float, color: Color, modifier: Modifier = Modifier) {
    val c = IOS.colors
    val f by animateFloatAsState(fraction.coerceIn(0f, 1f), spring(dampingRatio = 0.7f, stiffness = Spring.StiffnessLow), label = "bar")
    Box(modifier.fillMaxWidth().height(4.dp).clip(RoundedCornerShape(2.dp)).background(c.track)) {
        Box(Modifier.fillMaxHeight().fillMaxWidth(f).background(color))
    }
}

/** Ring made of coloured segments (each is its share of the full circle). */
@Composable
fun SegmentRing(segments: List<Pair<Float, Color>>, modifier: Modifier = Modifier, stroke: Dp = 16.dp, content: @Composable () -> Unit) {
    val c = IOS.colors
    var target by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(Unit) { target = 1f }
    val p by animateFloatAsState(target, spring(dampingRatio = 0.55f, stiffness = Spring.StiffnessVeryLow), label = "ring")
    Box(modifier, contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val w = stroke.toPx()
            val arc = Size(size.width - w, size.height - w)
            val tl = Offset(w / 2f, w / 2f)
            drawArc(c.track, -90f, 360f, false, tl, arc, style = Stroke(w, cap = StrokeCap.Round))
            var start = -90f
            segments.forEach { (frac, color) ->
                val sweep = 360f * frac * p
                if (sweep > 0.5f) drawArc(color, start, sweep, false, tl, arc, style = Stroke(w, cap = StrokeCap.Round))
                start += sweep
            }
        }
        content()
    }
}

/** Circular checkbox (green fill + white check when selected). Accessible as a checkbox. */
@Composable
fun CircleCheck(checked: Boolean, label: String, onChange: (Boolean) -> Unit) {
    val c = IOS.colors
    Box(
        modifier = Modifier
            .size(44.dp)
            .semantics { contentDescription = label }
            .toggleable(value = checked, role = Role.Checkbox, onValueChange = onChange),
        contentAlignment = Alignment.Center
    ) {
        val fill = if (checked) c.primary else Color.Transparent
        Box(
            Modifier.size(28.dp).clip(CircleShape).background(fill)
                .then(if (checked) Modifier else Modifier.background(Color.Transparent, CircleShape)),
            contentAlignment = Alignment.Center
        ) {
            if (!checked) Canvas(Modifier.fillMaxSize()) { drawCircle(c.textSecondary.copy(alpha = 0.55f), style = Stroke(3.dp.toPx())) }
            else androidx.compose.material3.Icon(painterResource(R.drawable.ic_check_white), contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
        }
    }
}

/** Coloured circle with an emoji, used as the leading icon of habit rows. */
@Composable
fun EmojiBadge(emoji: String, color: Color, size: Dp = 40.dp) {
    Box(Modifier.size(size).clip(CircleShape).background(color.copy(alpha = 0.18f)), contentAlignment = Alignment.Center) {
        Text(emoji, style = IOSType.headline)
    }
}

@Composable
fun SectionTitle(text: String, modifier: Modifier = Modifier) {
    Text(text, style = IOSType.title, color = IOS.colors.textPrimary, modifier = modifier.padding(start = 4.dp, top = 8.dp))
}

@Composable
fun EmptyState(emoji: String, title: String, body: String, action: String? = null, onAction: () -> Unit = {}) {
    val c = IOS.colors
    IOSCard {
        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(emoji, style = IOSType.number)
            Text(title, style = IOSType.headline, color = c.textPrimary, modifier = Modifier.padding(top = 6.dp))
            Text(body, style = IOSType.body, color = c.textSecondary, modifier = Modifier.padding(top = 4.dp, bottom = 8.dp))
            if (action != null) {
                Box(
                    Modifier.clip(RoundedCornerShape(50)).background(c.primarySoft).iosPress(Role.Button, onAction).padding(horizontal = 20.dp, vertical = 10.dp)
                ) { Text(action, style = IOSType.body, color = c.primaryText) }
            }
        }
    }
}
