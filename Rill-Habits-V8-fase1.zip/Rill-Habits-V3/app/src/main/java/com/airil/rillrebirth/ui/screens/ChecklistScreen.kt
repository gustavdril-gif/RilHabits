package com.airil.rillrebirth.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.SwipeToDismissBox
import androidx.compose.material3.SwipeToDismissBoxValue
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberSwipeToDismissBoxState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.airil.rillrebirth.RillTask
import com.airil.rillrebirth.ui.components.CircleCheck
import com.airil.rillrebirth.ui.components.EmojiBadge
import com.airil.rillrebirth.ui.components.EmptyState
import com.airil.rillrebirth.ui.data.TodayData
import com.airil.rillrebirth.ui.theme.IOS
import com.airil.rillrebirth.ui.theme.IOSType
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val groupOrder = listOf("Pagi", "Siang", "Sore", "Malam")

private fun groupOf(minutes: Int): String = when {
    minutes in 240..659 -> "Pagi"
    minutes in 660..899 -> "Siang"
    minutes in 900..1079 -> "Sore"
    else -> "Malam"
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ChecklistScreen(refresh: Int, openLegacy: (String) -> Unit) {
    val ctx = LocalContext.current
    val c = IOS.colors
    val haptic = LocalHapticFeedback.current
    var tick by remember { mutableIntStateOf(0) }
    val snap = remember(refresh, tick) { TodayData.snapshot(ctx) }
    var journalFor by remember { mutableIntStateOf(-1) }
    var pendingDelete by remember { mutableStateOf<RillTask?>(null) }
    val dateText = remember(refresh) { SimpleDateFormat("EEEE, d MMM", Locale("id", "ID")).format(Date()) }

    val groups = snap.tasks.groupBy { groupOf(TodayData.minutes(ctx, it)) }
    val doneCount = snap.tasks.count { snap.done.contains(it.id) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 120.dp)
    ) {
        item(key = "header") {
            Column(Modifier.padding(bottom = 12.dp)) {
                Text("Habit", style = IOSType.largeTitle, color = c.textPrimary, modifier = Modifier.padding(start = 4.dp))
                Text("Hari ini, $dateText • $doneCount dari ${snap.tasks.size} selesai", style = IOSType.body, color = c.textSecondary, modifier = Modifier.padding(start = 4.dp))
            }
        }
        if (snap.tasks.isEmpty()) {
            item(key = "empty") {
                EmptyState("🌱", "Belum ada kebiasaan hari ini", "Tambahkan atau atur hari tiap kebiasaan di menu Jadwal.", "Buka Jadwal") { openLegacy("Jadwal") }
            }
        }
        groupOrder.forEach { g ->
            val list = (groups[g] ?: emptyList()).sortedBy { TodayData.minutes(ctx, it) }
            if (list.isNotEmpty()) {
                stickyHeader(key = "h_$g") {
                    Box(Modifier.fillMaxWidth().background(c.background).padding(start = 4.dp, top = 10.dp, bottom = 6.dp)) {
                        Text(g.uppercase(Locale.ROOT), style = IOSType.caption.copy(fontWeight = FontWeight.SemiBold), color = c.textSecondary)
                    }
                }
                itemsIndexed(list, key = { _, t -> t.id }) { i, t ->
                    val done = snap.done.contains(t.id)
                    val lapsed = TodayData.isLapsed(ctx, t, snap.done)
                    TaskRow(
                        t = t, done = done, lapsed = lapsed, first = i == 0, last = i == list.size - 1,
                        time = TodayData.timeLabel(ctx, t),
                        journalOpen = journalFor == t.id && done,
                        onToggle = { checked ->
                            haptic.performHapticFeedback(if (checked) HapticFeedbackType.TextHandleMove else HapticFeedbackType.LongPress)
                            TodayData.setDone(ctx, t.id, checked)
                            journalFor = if (checked) t.id else -1
                            tick++
                        },
                        onDelete = { pendingDelete = t },
                        ctx = ctx
                    )
                }
            }
        }
    }

    val del = pendingDelete
    if (del != null) {
        AlertDialog(
            onDismissRequest = { pendingDelete = null },
            title = { Text("Hapus kebiasaan?") },
            text = { Text("\"${del.name}\" akan dihapus dari jadwalmu.") },
            confirmButton = { TextButton(onClick = { TodayData.delete(ctx, del.id); pendingDelete = null; tick++ }) { Text("Hapus", color = c.red) } },
            dismissButton = { TextButton(onClick = { pendingDelete = null }) { Text("Batal") } }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TaskRow(
    t: RillTask, done: Boolean, lapsed: Boolean, first: Boolean, last: Boolean, time: String,
    journalOpen: Boolean, onToggle: (Boolean) -> Unit, onDelete: () -> Unit, ctx: android.content.Context
) {
    val c = IOS.colors
    val top = if (first) 20.dp else 0.dp
    val bottom = if (last) 20.dp else 0.dp
    val shape = RoundedCornerShape(topStart = top, topEnd = top, bottomStart = bottom, bottomEnd = bottom)
    val state = rememberSwipeToDismissBoxState(confirmValueChange = { v ->
        when (v) {
            SwipeToDismissBoxValue.StartToEnd -> { onToggle(!done); false }
            SwipeToDismissBoxValue.EndToStart -> { onDelete(); false }
            else -> false
        }
    })
    var note by remember(t.id, journalOpen) { mutableStateOf(TodayData.journal(ctx, t.id)) }
    val saved = if (!journalOpen) TodayData.journal(ctx, t.id) else ""

    Box(Modifier.fillMaxWidth().clip(shape)) {
        SwipeToDismissBox(
            state = state,
            backgroundContent = {
                val dir = state.dismissDirection
                val bg = when (dir) { SwipeToDismissBoxValue.StartToEnd -> c.primary; SwipeToDismissBoxValue.EndToStart -> c.red; else -> Color.Transparent }
                Box(
                    Modifier.fillMaxSize().background(bg).padding(horizontal = 20.dp),
                    contentAlignment = if (dir == SwipeToDismissBoxValue.StartToEnd) Alignment.CenterStart else Alignment.CenterEnd
                ) {
                    if (dir != SwipeToDismissBoxValue.Settled) Text(
                        if (dir == SwipeToDismissBoxValue.StartToEnd) (if (done) "Batalkan" else "Selesai") else "Hapus",
                        color = Color.White, style = IOSType.headline
                    )
                }
            }
        ) {
            Column(Modifier.fillMaxWidth().background(c.card)) {
                Row(Modifier.fillMaxWidth().padding(start = 14.dp, end = 6.dp, top = 8.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    EmojiBadge(TodayData.emojiFor(t), if (lapsed) c.textSecondary else if (t.category.lowercase(Locale.ROOT).contains("ibadah")) c.primary else c.blue)
                    Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                        Text(t.name, style = IOSType.headline, color = if (done || lapsed) c.textSecondary else c.textPrimary)
                        Text(
                            if (lapsed) "$time • Gugur" else "$time • ${t.category} • ${t.xp} XP",
                            style = IOSType.caption, color = c.textSecondary
                        )
                        if (saved.isNotBlank()) Text("“$saved”", style = IOSType.caption, color = c.primaryText)
                    }
                    CircleCheck(checked = done, label = (if (done) "Batalkan " else "Selesaikan ") + t.name, onChange = onToggle)
                }
                AnimatedVisibility(visible = journalOpen) {
                    Box(Modifier.fillMaxWidth().padding(start = 14.dp, end = 14.dp, bottom = 12.dp).clip(RoundedCornerShape(12.dp)).background(c.background).padding(12.dp)) {
                        BasicTextField(
                            value = note,
                            onValueChange = { note = it.take(200); TodayData.setJournal(ctx, t.id, note) },
                            textStyle = IOSType.body.copy(color = c.textPrimary),
                            cursorBrush = SolidColor(c.primary),
                            modifier = Modifier.fillMaxWidth(),
                            decorationBox = { inner ->
                                if (note.isEmpty()) Text("Gimana tadi? Tulis 1 kalimat", style = IOSType.body, color = c.textSecondary)
                                inner()
                            }
                        )
                    }
                }
                if (!last) Box(Modifier.fillMaxWidth().padding(start = 66.dp).background(c.separator).padding(top = 0.5.dp))
            }
        }
    }
}
