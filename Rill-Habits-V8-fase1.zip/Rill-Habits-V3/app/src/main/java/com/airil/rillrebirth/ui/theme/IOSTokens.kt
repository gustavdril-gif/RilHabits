package com.airil.rillrebirth.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

/** iOS 18 style palette. Text colours are chosen to keep at least 4.5:1 contrast on their backgrounds. */
@Immutable
data class IOSColors(
    val dark: Boolean,
    val background: Color,
    val card: Color,
    val bar: Color,
    val primary: Color,
    val primaryText: Color,
    val primarySoft: Color,
    val blue: Color,
    val orange: Color,
    val purple: Color,
    val red: Color,
    val textPrimary: Color,
    val textSecondary: Color,
    val separator: Color,
    val track: Color
)

val LightIOS = IOSColors(
    dark = false,
    background = Color(0xFFF2F2F7), card = Color(0xFFFFFFFF), bar = Color(0xE6FFFFFF),
    primary = Color(0xFF6A9A7B), primaryText = Color(0xFF3F7352), primarySoft = Color(0xFFE3F1E9),
    blue = Color(0xFF5B8DEF), orange = Color(0xFFFF9F0A), purple = Color(0xFFAF7BE8), red = Color(0xFFE5483D),
    textPrimary = Color(0xFF1C1C1E), textSecondary = Color(0xFF6C6C70),
    separator = Color(0x1F3C3C43), track = Color(0xFFE5E5EA)
)

val DarkIOS = IOSColors(
    dark = true,
    background = Color(0xFF1C1C1E), card = Color(0xFF2C2C2E), bar = Color(0xE62C2C2E),
    primary = Color(0xFF7FB491), primaryText = Color(0xFF9BD0AD), primarySoft = Color(0xFF24382B),
    blue = Color(0xFF7AA5FF), orange = Color(0xFFFFB340), purple = Color(0xFFC9A0F5), red = Color(0xFFFF6961),
    textPrimary = Color(0xFFF2F2F7), textSecondary = Color(0xFFAEAEB2),
    separator = Color(0x33FFFFFF), track = Color(0xFF3A3A3C)
)

val LocalIOS = staticCompositionLocalOf { LightIOS }

object IOS {
    val colors: IOSColors
        @Composable @ReadOnlyComposable get() = LocalIOS.current
}

/** Text styles (system rounded-ish sans; no font files are bundled to keep the app small). */
object IOSType {
    val largeTitle = TextStyle(fontFamily = FontFamily.SansSerif, fontSize = 34.sp, fontWeight = FontWeight.Bold, lineHeight = 40.sp)
    val title = TextStyle(fontFamily = FontFamily.SansSerif, fontSize = 22.sp, fontWeight = FontWeight.Bold)
    val headline = TextStyle(fontFamily = FontFamily.SansSerif, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
    val body = TextStyle(fontFamily = FontFamily.SansSerif, fontSize = 15.sp, fontWeight = FontWeight.Normal)
    val caption = TextStyle(fontFamily = FontFamily.SansSerif, fontSize = 12.sp, fontWeight = FontWeight.Normal)
    val number = TextStyle(fontFamily = FontFamily.SansSerif, fontSize = 40.sp, fontWeight = FontWeight.Bold)
}

@Composable
fun RillTheme(dark: Boolean = isSystemInDarkTheme(), content: @Composable () -> Unit) {
    val c = if (dark) DarkIOS else LightIOS
    val scheme = if (dark) darkColorScheme(primary = c.primary, background = c.background, surface = c.card, onSurface = c.textPrimary, onBackground = c.textPrimary)
    else lightColorScheme(primary = c.primary, background = c.background, surface = c.card, onSurface = c.textPrimary, onBackground = c.textPrimary)
    CompositionLocalProvider(LocalIOS provides c) {
        MaterialTheme(colorScheme = scheme, content = content)
    }
}
