package com.airil.rillrebirth.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.airil.rillrebirth.ui.components.EmptyState
import com.airil.rillrebirth.ui.theme.IOS
import com.airil.rillrebirth.ui.theme.IOSType

/** Placeholder for tabs that are not migrated yet: opens the previous (View-based) screen for that tab. */
@Composable
fun LegacyTab(title: String, subtitle: String, legacyKey: String, openLegacy: (String) -> Unit) {
    val c = IOS.colors
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 120.dp)) {
        Text(title, style = IOSType.largeTitle, color = c.textPrimary, modifier = Modifier.padding(start = 4.dp))
        Text(subtitle, style = IOSType.body, color = c.textSecondary, modifier = Modifier.padding(start = 4.dp, bottom = 16.dp))
        EmptyState(
            emoji = "🛠️", title = "Sedang dipindahkan",
            body = "Menu ini belum memakai tampilan baru. Semua fiturnya tetap berfungsi di tampilan lama.",
            action = "Buka $title", onAction = { openLegacy(legacyKey) }
        )
    }
}
