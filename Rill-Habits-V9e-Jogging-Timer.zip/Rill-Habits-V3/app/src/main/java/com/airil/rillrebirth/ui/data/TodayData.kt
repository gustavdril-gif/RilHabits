package com.airil.rillrebirth.ui.data

import android.content.Context
import com.airil.rillrebirth.PrayerTimes
import com.airil.rillrebirth.R
import com.airil.rillrebirth.RillTask
import com.airil.rillrebirth.Smart
import com.airil.rillrebirth.TaskStore
import com.airil.rillrebirth.TodayInfo
import com.airil.rillrebirth.ui.components.HabitIcons
import com.airil.rillrebirth.WorkoutStore
import java.util.Calendar

/** Reads "today" straight from the existing stores, so data from older versions keeps working. */
object TodayData {
    data class Snapshot(
        val allTasks: List<RillTask>,
        val tasks: List<RillTask>,          // scheduled for today
        val done: Set<Int>,
        val live: List<RillTask>,           // today's tasks that have not lapsed
        val workoutTotal: Int,
        val workoutDone: Int,
        val totalXp: Int,
        val streak: Int,
        val bestStreak: Int
    ) {
        val prayer get() = live.filter { Smart.isPrayer(it) }
        val other get() = live.filter { !Smart.isPrayer(it) }
        val doneCount get() = live.count { done.contains(it.id) } + workoutDone
        val totalCount get() = live.size + workoutTotal
    }

    fun nowMinutes(): Int { val c = Calendar.getInstance(); return c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE) }

    fun minutes(ctx: Context, t: RillTask): Int = TodayInfo.taskMinutes(ctx, t)

    fun timeLabel(ctx: Context, t: RillTask): String = PrayerTimes.format(minutes(ctx, t))

    fun isLapsed(ctx: Context, t: RillTask, done: Set<Int>): Boolean =
        !done.contains(t.id) && Smart.isPrayer(t) && nowMinutes() > minutes(ctx, t) + Smart.PRAYER_GRACE_MIN

    fun snapshot(ctx: Context): Snapshot {
        val all = TaskStore.load(ctx)
        val dow = Calendar.getInstance().get(Calendar.DAY_OF_WEEK)
        val today = all.filter { it.runsOn(dow) }
        val done = TaskStore.doneToday(ctx).toSet()
        val live = today.filter { !isLapsed(ctx, it, done) }
        val sessions = WorkoutStore.sessionsForDate(ctx)
        val stats = Smart.dayStats(ctx, all, 365)
        return Snapshot(
            all, today, done, live, sessions.size, sessions.count { WorkoutStore.isDone(ctx, it.id) },
            TaskStore.totalXp(ctx) + WorkoutStore.totalWorkoutXp(ctx), Smart.habitStreak(stats), Smart.bestHabitStreak(stats)
        )
    }

    fun setDone(ctx: Context, id: Int, checked: Boolean) {
        val d = TaskStore.doneToday(ctx)
        if (checked) d.add(id) else d.remove(id)
        TaskStore.saveDone(ctx, d)
    }

    fun delete(ctx: Context, id: Int) {
        val list = TaskStore.load(ctx)
        list.removeAll { it.id == id }
        TaskStore.save(ctx, list)
        val d = TaskStore.doneToday(ctx); d.remove(id); TaskStore.saveDone(ctx, d)
        com.airil.rillrebirth.ReminderScheduler.scheduleAll(ctx)
    }

    // ---- one-sentence journal after finishing a habit ----
    private fun journalKey(id: Int) = "journal_${TaskStore.today()}_$id"
    fun journal(ctx: Context, id: Int): String = ctx.getSharedPreferences("rill_data", Context.MODE_PRIVATE).getString(journalKey(id), "") ?: ""
    fun setJournal(ctx: Context, id: Int, text: String) {
        ctx.getSharedPreferences("rill_data", Context.MODE_PRIVATE).edit().putString(journalKey(id), text.take(200)).apply()
    }

    fun emojiFor(t: RillTask): String {
        val k = (t.category + " " + t.name).lowercase()
        return when {
            Smart.isPrayer(t) -> "🕌"
            k.contains("belajar") || k.contains("sekolah") || k.contains("tugas") -> "📚"
            k.contains("olahraga") || k.contains("jog") || k.contains("lari") || k.contains("workout") -> "🏃"
            k.contains("refleksi") || k.contains("evaluasi") -> "📝"
            else -> "🌱"
        }
    }

    /** Drawable behind the habit's icon; the keyword matching lives in [HabitIcons]. */
    fun iconFor(t: RillTask): Int = HabitIcons.forTask(t).res

    // ---- rituals: morning = tasks before 11:00, evening = tasks from 18:00 ----
    fun ritualTasks(ctx: Context, kind: String): List<RillTask> {
        val snap = snapshot(ctx)
        return snap.live.filter { !snap.done.contains(it.id) && (if (kind == "pagi") minutes(ctx, it) < 660 else minutes(ctx, it) >= 1080) }
            .sortedBy { minutes(ctx, it) }
    }

    /** "pagi", "malam" or "" depending on the hour and whether such tasks are still pending. */
    fun ritualOffer(ctx: Context): String {
        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val kind = when { h in 4..10 -> "pagi"; h >= 17 -> "malam"; else -> "" }
        return if (kind.isNotEmpty() && ritualTasks(ctx, kind).isNotEmpty()) kind else ""
    }
}
