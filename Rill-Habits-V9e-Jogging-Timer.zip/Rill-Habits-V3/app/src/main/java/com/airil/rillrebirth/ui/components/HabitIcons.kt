package com.airil.rillrebirth.ui.components

import androidx.annotation.DrawableRes
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.airil.rillrebirth.R
import com.airil.rillrebirth.RillTask
import com.airil.rillrebirth.ui.theme.IOS
import com.airil.rillrebirth.ui.theme.IOSColors
import java.util.Locale

enum class Tone { GREEN, BLUE, ORANGE, PURPLE, RED;
    fun color(c: IOSColors): Color = when (this) { GREEN -> c.primary; BLUE -> c.blue; ORANGE -> c.orange; PURPLE -> c.purple; RED -> c.red }
}

/** [twoTone] icons (the green mosque) carry their own colours and are not tinted. */
data class HabitIcon(@DrawableRes val res: Int, val tone: Tone, val twoTone: Boolean = false)

/**
 * Picks an icon from the words in a habit's name (then its category).
 * Matching is word based and forgiving: "Mandi pagi" -> shower, "Sikat gigi" -> tooth, "Ngaji" -> Quran.
 * Rules are checked top to bottom, the first match wins, so specific phrases come before general words.
 *
 * Key syntax:  "kata"  = any word that STARTS with it (makan -> makanan)
 *              "=kata" = the whole word only (=mandi must not match "mandiri")
 *              "dua kata" = phrase that starts at a word boundary
 */
object HabitIcons {
    private class Rule(val icon: HabitIcon, vararg val keys: String)

    private fun r(@DrawableRes res: Int, tone: Tone, vararg keys: String) = Rule(HabitIcon(res, tone), *keys)

    val MOSQUE = HabitIcon(R.drawable.ic_mosque, Tone.GREEN, twoTone = true)
    val FALLBACK = HabitIcon(R.drawable.ic_sprout, Tone.GREEN)

    private val rules: List<Rule> = listOf(
        // --- ibadah ---
        r(R.drawable.ic_heart, Tone.RED, "sedekah", "shodaqoh", "infak", "infaq", "zakat", "donasi", "amal", "wakaf", "berbagi", "volunteer", "relawan"),
        Rule(MOSQUE, "shalat", "sholat", "salat", "solat", "subuh", "shubuh", "dzuhur", "zuhur", "dhuhur", "duhur", "ashar", "asar",
            "maghrib", "magrib", "isya", "isha", "dhuha", "duha", "tahajud", "tahajjud", "witir", "rawatib", "tarawih", "taraweh",
            "jumat", "jum at", "jumatan", "berjamaah", "jamaah", "masjid", "mushola", "musholla", "surau", "kajian", "ibadah"),
        r(R.drawable.ic_quran, Tone.GREEN, "quran", "al quran", "alquran", "tilawah", "tadarus", "ngaji", "mengaji", "hafalan", "hafal",
            "murajaah", "muraja ah", "tahfidz", "tahfiz", "tafsir"),
        r(R.drawable.ic_beads, Tone.GREEN, "dzikir", "zikir", "doa", "wirid", "tasbih", "istighfar", "shalawat", "sholawat", "matsurat"),
        r(R.drawable.ic_utensils, Tone.ORANGE, "buka puasa", "sahur", "iftar", "takjil"),
        r(R.drawable.ic_crescent, Tone.GREEN, "puasa", "shaum", "shiyam", "ramadhan", "ramadan"),

        // --- kebersihan & tubuh ---
        r(R.drawable.ic_shower, Tone.BLUE, "=mandi", "=shower", "keramas", "bersih diri", "membersihkan diri"),
        r(R.drawable.ic_tooth, Tone.BLUE, "sikat gigi", "gosok gigi", "gigi", "dentist", "floss"),
        r(R.drawable.ic_scissors, Tone.PURPLE, "cukur", "potong rambut", "barbershop", "salon", "pangkas", "gunting"),
        r(R.drawable.ic_sparkle, Tone.PURPLE, "skincare", "skin care", "wajah", "cuci muka", "masker", "lotion", "sunscreen", "perawatan", "syukur", "gratitude"),
        r(R.drawable.ic_pill, Tone.RED, "minum obat", "obat", "vitamin", "suplemen", "supplement", "terapi"),
        r(R.drawable.ic_pulse, Tone.RED, "dokter", "cek kesehatan", "check up", "checkup", "kesehatan", "timbang", "berat badan", "tensi", "gula darah", "rumah sakit", "kontrol", "medis"),
        r(R.drawable.ic_drop, Tone.BLUE, "wudhu", "wudu", "minum", "air putih", "=air", "hidrasi", "water", "gelas"),

        // --- tidur & bangun ---
        r(R.drawable.ic_alarm, Tone.ORANGE, "bangun", "alarm", "=wake"),
        r(R.drawable.ic_bed, Tone.PURPLE, "tidur", "sleep", "rebahan", "istirahat", "=nap", "bedtime"),

        // --- hewan peliharaan (sebelum makan, supaya kasih makan kucing = cakar) ---
        r(R.drawable.ic_paw, Tone.ORANGE, "kucing", "anjing", "hewan", "peliharaan", "=pet", "burung", "kelinci"),

        // --- makan & minum ---
        r(R.drawable.ic_coffee, Tone.ORANGE, "kopi", "ngopi", "teh", "coffee", "cafe", "kafe"),
        r(R.drawable.ic_pot, Tone.ORANGE, "masak", "memasak", "cook", "meal prep", "cuci piring", "dapur"),
        r(R.drawable.ic_utensils, Tone.ORANGE, "makan", "sarapan", "brunch", "lunch", "dinner", "diet", "camilan", "snack", "buah", "sayur", "nasi", "meal"),

        // --- olahraga ---
        r(R.drawable.ic_run, Tone.ORANGE, "jogging", "=jog", "lari", "running", "=run", "=jalan", "jalan kaki", "jalan pagi", "jalan santai", "walking", "=walk", "langkah", "treadmill"),
        r(R.drawable.ic_bike, Tone.ORANGE, "sepeda", "gowes", "cycling", "bersepeda"),
        r(R.drawable.ic_swim, Tone.BLUE, "renang", "berenang", "swim"),
        r(R.drawable.ic_ball, Tone.ORANGE, "futsal", "sepak bola", "main bola", "=bola", "basket", "badminton", "voli", "tenis", "tennis", "padel", "olahraga bola"),
        r(R.drawable.ic_lotus, Tone.PURPLE, "yoga", "meditasi", "meditate", "mindful", "napas", "relaksasi", "peregangan", "stretch", "pilates", "tenang"),
        r(R.drawable.ic_dumbbell, Tone.ORANGE, "olahraga", "workout", "=gym", "fitness", "angkat beban", "push up", "pushup", "sit up", "situp", "plank", "squat", "latihan", "kardio", "cardio", "hiit", "calisthenic"),

        // --- belajar & kerja ---
        r(R.drawable.ic_globe, Tone.BLUE, "bahasa", "inggris", "english", "arab", "jepang", "korea", "mandarin", "vocab", "kosakata", "duolingo", "speaking", "ielts", "toefl"),
        r(R.drawable.ic_book, Tone.BLUE, "baca", "buku", "novel", "reading", "literasi", "kitab"),
        r(R.drawable.ic_grad, Tone.BLUE, "belajar", "sekolah", "kuliah", "kelas", "tugas", "=pr", "ujian", "skripsi", "tesis", "thesis", "kuis", "=les", "kursus", "course", "study", "materi", "kampus"),
        r(R.drawable.ic_laptop, Tone.BLUE, "coding", "ngoding", "program", "laptop", "desain", "design", "editing", "=ui", "website", "aplikasi", "freelance"),
        r(R.drawable.ic_mail, Tone.BLUE, "email", "surel", "surat", "inbox"),
        r(R.drawable.ic_briefcase, Tone.BLUE, "kerja", "kantor", "meeting", "rapat", "proyek", "project", "klien", "client", "deadline", "presentasi", "laporan", "bisnis", "usaha", "kerjaan"),
        r(R.drawable.ic_pen, Tone.PURPLE, "nulis", "menulis", "tulis", "jurnal", "journal", "diary", "blog", "mengarang"),
        r(R.drawable.ic_note, Tone.PURPLE, "catat", "catatan", "refleksi", "evaluasi", "review harian", "notes", "ringkas"),

        // --- rumah tangga ---
        r(R.drawable.ic_shirt, Tone.PURPLE, "cuci baju", "cuci pakaian", "laundry", "setrika", "jemur baju", "lipat baju", "baju", "pakaian"),
        r(R.drawable.ic_broom, Tone.PURPLE, "sapu", "nyapu", "menyapu", "=pel", "ngepel", "mengepel", "nyuci", "bersih", "bersihin", "beres", "rapi", "merapikan", "cuci", "kebersihan", "piket"),
        r(R.drawable.ic_cart, Tone.ORANGE, "belanja", "beli", "pasar", "groceries", "supermarket", "shopping"),
        r(R.drawable.ic_wallet, Tone.GREEN, "nabung", "tabungan", "uang", "keuangan", "budget", "anggaran", "bayar", "tagihan", "cicilan", "gaji", "investasi", "finance", "dompet", "hutang", "utang"),
        r(R.drawable.ic_sprout, Tone.GREEN, "siram", "tanam", "tanaman", "kebun", "berkebun", "bunga", "garden"),

        // --- sosial & lainnya ---
        r(R.drawable.ic_people, Tone.BLUE, "keluarga", "orang tua", "ortu", "=ibu", "=ayah", "=bapak", "mama", "papa", "silaturahmi", "teman", "sahabat", "kumpul", "kencan", "anak", "pasangan", "telepon", "telpon", "video call", "nongkrong"),
        r(R.drawable.ic_phone, Tone.PURPLE, "=hp", "gadget", "sosmed", "medsos", "instagram", "tiktok", "screen time", "detoks", "detox", "ponsel", "smartphone"),
        r(R.drawable.ic_music, Tone.PURPLE, "musik", "music", "nyanyi", "bernyanyi", "gitar", "piano", "lagu", "podcast", "biola"),
        r(R.drawable.ic_car, Tone.BLUE, "mobil", "motor", "perjalanan", "mudik", "berangkat", "pulang", "commute", "kendaraan", "servis", "travel", "liburan", "trip"),
        r(R.drawable.ic_gift, Tone.RED, "hadiah", "kado", "ulang tahun", "birthday", "perayaan", "surprise"),
        r(R.drawable.ic_calendar, Tone.BLUE, "rencana", "planning", "agenda", "jadwal", "review mingguan", "weekly", "kalender", "perencanaan"),
        r(R.drawable.ic_target, Tone.RED, "target", "goal", "tujuan", "fokus", "focus", "prioritas"),
        r(R.drawable.ic_sun, Tone.ORANGE, "pagi", "matahari", "jemur", "sunrise", "morning"),
        r(R.drawable.ic_moon, Tone.PURPLE, "malam", "night", "evening")
    )

    private fun normalize(s: String): String =
        s.lowercase(Locale.ROOT).replace(Regex("[^a-z0-9]+"), " ").trim()

    private fun matches(rule: Rule, padded: String, tokens: List<String>): Boolean = rule.keys.any { key ->
        when {
            key.startsWith("=") -> tokens.contains(key.substring(1))
            key.contains(' ') -> padded.contains(" $key")
            else -> tokens.any { it.startsWith(key) }
        }
    }

    /** "Mandi sebelum subuh" -> ["Mandi", "subuh"]: the main activity is whatever comes first. */
    private val splitter = Regex("[,;/&+()\\-–—]|\\b(sebelum|setelah|sesudah|selepas|habis|abis|usai|menjelang|jelang|bakda|ba'da|dan|untuk|dengan|sama|di|ke)\\b", RegexOption.IGNORE_CASE)

    private fun findIn(text: String): HabitIcon? {
        val norm = normalize(text)
        if (norm.isEmpty()) return null
        val tokens = norm.split(' ')
        val padded = " $norm "
        return rules.firstOrNull { matches(it, padded, tokens) }?.icon
    }

    private fun find(text: String): HabitIcon? {
        if (text.isBlank()) return null
        for (part in text.split(splitter)) findIn(part)?.let { return it }
        return findIn(text)   // phrases that span a connector, e.g. "ke masjid"
    }

    /** Looks at [name] first (what the person typed), then [category], then falls back to [fallback]. */
    fun resolve(name: String, category: String = "", fallback: HabitIcon = FALLBACK): HabitIcon =
        find(name) ?: find(category) ?: fallback

    fun forTask(t: RillTask): HabitIcon = if (t.prayer.isNotEmpty()) MOSQUE else resolve(t.name, t.category)
}

/** Round badge for a habit: a coloured circle with a white glyph, or a soft green circle with the two-tone mosque. */
@Composable
fun HabitBadge(icon: HabitIcon, size: Dp = 40.dp, dim: Boolean = false) {
    val c = IOS.colors
    if (icon.twoTone) {
        Box(
            Modifier.size(size).clip(CircleShape).background(c.primarySoft).alpha(if (dim) 0.45f else 1f),
            contentAlignment = Alignment.Center
        ) {
            val res = if (c.dark && icon.res == R.drawable.ic_mosque) R.drawable.ic_mosque_night else icon.res
            Image(painterResource(res), contentDescription = null, modifier = Modifier.size(size * 0.68f))
        }
    } else {
        IconBadge(icon.res, if (dim) c.textSecondary else icon.tone.color(c), size)
    }
}

@Composable
fun HabitBadge(task: RillTask, size: Dp = 40.dp, dim: Boolean = false) = HabitBadge(HabitIcons.forTask(task), size, dim)
