package com.airil.rillrebirth

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** One planned run in the weekly jogging schedule. [day] is a Calendar.DAY_OF_WEEK value. */
data class JogPlan(val id: Long, val day: Int, val time: String, val km: Double)

object JogPlanStore {
    private const val KEY = "jog_plans_json"
    private val order = listOf(2, 3, 4, 5, 6, 7, 1)   // Monday first
    private val names = mapOf(1 to "Minggu", 2 to "Senin", 3 to "Selasa", 4 to "Rabu", 5 to "Kamis", 6 to "Jumat", 7 to "Sabtu")

    fun dayName(day: Int): String = names[day] ?: "Hari"
    fun dayShort(day: Int): String = Smart.weekdayLabel(day)

    private fun prefs(c: Context) = c.getSharedPreferences("rill_data", Context.MODE_PRIVATE)

    fun load(c: Context): List<JogPlan> {
        val out = mutableListOf<JogPlan>()
        try {
            val a = JSONArray(prefs(c).getString(KEY, "[]") ?: "[]")
            for (i in 0 until a.length()) {
                val o = a.optJSONObject(i) ?: continue
                out.add(JogPlan(o.optLong("id"), o.optInt("day", 2), o.optString("time", "06:30"), o.optDouble("km", 3.0)))
            }
        } catch (_: Exception) { }
        return out.sortedWith(compareBy({ order.indexOf(it.day) }, { it.time }))
    }

    private fun save(c: Context, list: List<JogPlan>) {
        val a = JSONArray()
        list.forEach { a.put(JSONObject().put("id", it.id).put("day", it.day).put("time", it.time).put("km", it.km)) }
        prefs(c).edit().putString(KEY, a.toString()).apply()
    }

    fun nextId(c: Context): Long = (load(c).maxOfOrNull { it.id } ?: 0L) + 1L
    fun upsert(c: Context, p: JogPlan) { save(c, load(c).filter { it.id != p.id } + p) }
    fun delete(c: Context, id: Long) { save(c, load(c).filter { it.id != id }) }
}
