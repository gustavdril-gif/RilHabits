package com.airil.rillrebirth.ui.screens

import android.app.TimePickerDialog
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp
import com.airil.rillrebirth.Programs
import com.airil.rillrebirth.ReminderScheduler
import com.airil.rillrebirth.WorkoutExercise
import com.airil.rillrebirth.WorkoutSession
import com.airil.rillrebirth.WorkoutStore
import com.airil.rillrebirth.ui.components.ChipRow
import com.airil.rillrebirth.ui.components.ChoiceChip
import com.airil.rillrebirth.ui.components.ConfirmDialog
import com.airil.rillrebirth.ui.components.DayPicker
import com.airil.rillrebirth.ui.components.FieldLabel
import com.airil.rillrebirth.ui.components.GuideSheet
import com.airil.rillrebirth.ui.components.IOSCard
import com.airil.rillrebirth.ui.components.IOSField
import com.airil.rillrebirth.ui.components.IOSSheet
import com.airil.rillrebirth.ui.components.OutlineButton
import com.airil.rillrebirth.ui.components.PrimaryButton
import com.airil.rillrebirth.ui.components.RillNav
import com.airil.rillrebirth.ui.components.ScreenScaffold
import com.airil.rillrebirth.ui.components.iosPress
import com.airil.rillrebirth.ui.theme.IOS
import com.airil.rillrebirth.ui.theme.IOSType
import java.util.Locale

/** "Bikin Jadwal": create or edit one workout session. id = 0 creates a new one. */
@Composable
fun BuilderScreen(nav: RillNav, id: Long) {
    val ctx = LocalContext.current
    val c = IOS.colors
    val existing = remember(id) { if (id == 0L) null else WorkoutStore.load(ctx).find { it.id == id } }
    val isNew = existing == null
    val sessionId = remember(id) { existing?.id ?: System.currentTimeMillis() }
    var name by remember { mutableStateOf(existing?.name ?: "") }
    var time by remember { mutableStateOf(existing?.time ?: "18:00") }
    var duration by remember { mutableStateOf(existing?.durationMinutes ?: 30) }
    var days by remember { mutableStateOf(existing?.days?.toSet() ?: setOf(2, 4, 6)) }
    var oneOff by remember { mutableStateOf(existing?.oneOffDate ?: "") }
    var reminder by remember { mutableStateOf(existing?.reminder ?: true) }
    var active by remember { mutableStateOf(existing?.active ?: true) }
    val notes = remember { existing?.notes ?: "" }
    val exercises = remember { mutableStateListOf<WorkoutExercise>().apply { existing?.exercises?.forEach { add(WorkoutExercise(it.name, it.sets, it.reps)) } } }
    var picker by remember { mutableStateOf(false) }
    var sessionPicker by remember { mutableStateOf(false) }
    var editIndex by remember { mutableStateOf(-2) }          // -1 = new, >=0 = edit
    var guide by remember { mutableStateOf<String?>(null) }
    var confirmDelete by remember { mutableStateOf(false) }

    fun save() {
        val n = name.trim()
        if (n.isEmpty()) { Toast.makeText(ctx, "Beri nama sesi dulu.", Toast.LENGTH_SHORT).show(); return }
        if (days.isEmpty() && oneOff.isBlank()) { Toast.makeText(ctx, "Pilih minimal satu hari.", Toast.LENGTH_SHORT).show(); return }
        if (exercises.isEmpty()) { Toast.makeText(ctx, "Tambahkan minimal satu gerakan.", Toast.LENGTH_SHORT).show(); return }
        val s = WorkoutSession(sessionId, n, time, duration, days.toMutableSet(), oneOff, notes, reminder, active, exercises.map { WorkoutExercise(it.name, it.sets, it.reps) }.toMutableList())
        val all = WorkoutStore.load(ctx)
        val idx = all.indexOfFirst { it.id == s.id }
        if (idx >= 0) all[idx] = s else all.add(s)
        WorkoutStore.save(ctx, all)
        ReminderScheduler.scheduleAll(ctx)
        Toast.makeText(ctx, "Jadwal tersimpan ✓", Toast.LENGTH_SHORT).show()
        nav.back()
    }

    ScreenScaffold(title = if (isNew) "Bikin Jadwal" else "Edit Jadwal", onBack = { nav.back() }) {
        item {
            IOSCard {
                FieldLabel("NAMA SESI")
                IOSField(name, { name = it }, "mis. Push Day", singleLine = true)
                FieldLabel("HARI")
                if (oneOff.isNotBlank()) Text("📅 Sekali jalan pada $oneOff. Pilih hari untuk menjadikannya berulang.", style = IOSType.caption, color = c.textSecondary, modifier = Modifier.padding(bottom = 6.dp))
                DayPicker(days) { days = it; oneOff = "" }
            }
        }
        item {
            IOSCard {
                FieldLabel("JAM & DURASI")
                Box(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(c.primarySoft).iosPress(Role.Button) {
                        val p = time.split(":")
                        TimePickerDialog(ctx, { _, h, m -> time = String.format(Locale.US, "%02d:%02d", h, m) }, p.getOrNull(0)?.toIntOrNull() ?: 18, p.getOrNull(1)?.toIntOrNull() ?: 0, true).show()
                    }.padding(vertical = 14.dp),
                    contentAlignment = Alignment.Center
                ) { Text("🕒  $time", style = IOSType.title, color = c.primaryText) }
                Spacer(Modifier.height(10.dp))
                ChipRow { listOf(15, 30, 45, 60, 90).forEach { m -> ChoiceChip("$m mnt", duration == m) { duration = m } } }
            }
        }
        item {
            IOSCard {
                FieldLabel("GERAKAN (${exercises.size})")
                if (exercises.isEmpty()) Text("Belum ada gerakan. Tambahkan satu per satu, atau ambil dari program siap pakai.", style = IOSType.body, color = c.textSecondary)
                exercises.forEachIndexed { i, ex ->
                    Row(Modifier.fillMaxWidth().iosPress(Role.Button) { editIndex = i }.padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("${i + 1}. ${ex.name}", style = IOSType.headline, color = c.textPrimary)
                            Text("${ex.sets} set × ${ex.reps}", style = IOSType.caption, color = c.textSecondary)
                        }
                        Text("Hapus", style = IOSType.caption, color = c.red, modifier = Modifier.iosPress(Role.Button) { exercises.removeAt(i) }.padding(8.dp))
                    }
                }
                Spacer(Modifier.height(6.dp))
                OutlineButton("+ Tambah gerakan") { picker = true }
                Spacer(Modifier.height(8.dp))
                OutlineButton("Ambil dari program siap pakai") { sessionPicker = true }
            }
        }
        item {
            IOSCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Ingatkan saya di jam ini", style = IOSType.body, color = c.textPrimary, modifier = Modifier.weight(1f))
                    Switch(checked = reminder, onCheckedChange = { reminder = it })
                }
                if (!isNew) Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 8.dp)) {
                    Text("Program aktif", style = IOSType.body, color = c.textPrimary, modifier = Modifier.weight(1f))
                    Switch(checked = active, onCheckedChange = { active = it })
                }
            }
        }
        item { PrimaryButton("Simpan jadwal") { save() } }
        if (!isNew) item { OutlineButton("Hapus jadwal") { confirmDelete = true } }
    }

    if (confirmDelete) ConfirmDialog("Hapus jadwal?", "\"$name\" akan dihapus permanen.", "Hapus", {
        val all = WorkoutStore.load(ctx); all.removeAll { it.id == sessionId }; WorkoutStore.save(ctx, all)
        ReminderScheduler.scheduleAll(ctx); confirmDelete = false; nav.back()
    }, { confirmDelete = false })

    if (picker) IOSSheet({ picker = false }) {
        Text("Pilih gerakan", style = IOSType.title, color = c.textPrimary)
        Spacer(Modifier.height(8.dp))
        Programs.library.forEach { ex ->
            Row(Modifier.fillMaxWidth().iosPress(Role.Button) { exercises.add(WorkoutExercise(ex.name, ex.sets, ex.reps)); picker = false }.padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(ex.name, style = IOSType.body, color = c.textPrimary, modifier = Modifier.weight(1f))
                Text("Panduan", style = IOSType.caption, color = c.primaryText, modifier = Modifier.clip(RoundedCornerShape(50)).background(c.primarySoft).iosPress(Role.Button) { guide = ex.name }.padding(horizontal = 12.dp, vertical = 6.dp))
            }
        }
        OutlineButton("✍️ Tulis sendiri…") { picker = false; editIndex = -1 }
    }

    if (sessionPicker) IOSSheet({ sessionPicker = false }) {
        Text("Ambil dari program", style = IOSType.title, color = c.textPrimary)
        Spacer(Modifier.height(8.dp))
        Programs.all.forEach { p ->
            p.sessions.forEach { ps ->
                Column(Modifier.fillMaxWidth().iosPress(Role.Button) {
                    ps.exercises.forEach { exercises.add(WorkoutExercise(it.name, it.sets, it.reps)) }
                    if (name.isBlank()) name = ps.name
                    duration = ps.duration
                    sessionPicker = false
                }.padding(vertical = 10.dp)) {
                    Text("${p.emoji} ${p.name} · ${ps.name}", style = IOSType.headline, color = c.textPrimary)
                    Text("${ps.exercises.size} gerakan · ${ps.duration} mnt", style = IOSType.caption, color = c.textSecondary)
                }
            }
        }
    }

    if (editIndex >= -1) {
        val cur = if (editIndex >= 0) exercises.getOrNull(editIndex) else null
        var n by remember(editIndex) { mutableStateOf(cur?.name ?: "") }
        var sets by remember(editIndex) { mutableStateOf((cur?.sets ?: 3).toString()) }
        var reps by remember(editIndex) { mutableStateOf(cur?.reps ?: "10") }
        IOSSheet({ editIndex = -2 }) {
            Text(if (cur == null) "Gerakan baru" else "Edit gerakan", style = IOSType.title, color = c.textPrimary)
            FieldLabel("NAMA GERAKAN")
            IOSField(n, { n = it }, "mis. Push Up", singleLine = true)
            FieldLabel("SET")
            IOSField(sets, { sets = it.filter { ch -> ch.isDigit() }.take(2) }, "3", singleLine = true, numeric = true)
            FieldLabel("REPETISI / DETIK")
            IOSField(reps, { reps = it.take(12) }, "10 atau 30 detik", singleLine = true)
            if (n.isNotBlank()) {
                Text("Lihat panduan gerakan ›", style = IOSType.body, color = c.primaryText, modifier = Modifier.iosPress(Role.Button) { guide = n }.padding(vertical = 12.dp))
            }
            PrimaryButton("Simpan") {
                if (n.isBlank()) { Toast.makeText(ctx, "Isi nama gerakan.", Toast.LENGTH_SHORT).show(); return@PrimaryButton }
                val ex = WorkoutExercise(n.trim(), (sets.toIntOrNull() ?: 3).coerceIn(1, 20), reps.trim().ifBlank { "10" })
                if (editIndex >= 0) exercises[editIndex] = ex else exercises.add(ex)
                editIndex = -2
            }
        }
    }
    guide?.let { GuideSheet(it) { guide = null } }
}
