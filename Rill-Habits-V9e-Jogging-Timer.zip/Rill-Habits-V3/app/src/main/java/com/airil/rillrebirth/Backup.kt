package com.airil.rillrebirth

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Whole-app backup: every value in the app's single preferences file goes into one JSON file. */
object Backup {
    private const val MARK = "RilHabit"
    private const val PREFS = "rill_data"
    const val REQ_EXPORT = 4101
    const val REQ_IMPORT = 4102

    fun export(c: Context): String {
        val p = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val data = JSONObject()
        for ((key, value) in p.all) {
            if (key.startsWith(SecretStore.PREFIX)) continue
            val o = JSONObject()
            when (value) {
                is String -> o.put("t", "s").put("v", value)
                is Boolean -> o.put("t", "b").put("v", value)
                is Int -> o.put("t", "i").put("v", value)
                is Long -> o.put("t", "l").put("v", value)
                is Float -> o.put("t", "f").put("v", value.toDouble())
                is Set<*> -> o.put("t", "ss").put("v", JSONArray(value.map { it.toString() }))
                else -> continue
            }
            data.put(key, o)
        }
        return JSONObject().put("app", MARK).put("version", 1).put("exported", System.currentTimeMillis()).put("data", data).toString()
    }

    /** Parses and validates without touching current data. Returns the parsed root or null. */
    fun parse(json: String): JSONObject? = try {
        val root = JSONObject(json)
        if (root.optString("app") == MARK && root.optJSONObject("data") != null) root else null
    } catch (_: Exception) { null }

    fun summary(root: JSONObject): String {
        val data = root.optJSONObject("data") ?: return ""
        fun count(key: String): Int = try { JSONArray(data.optJSONObject(key)?.optString("v") ?: "[]").length() } catch (_: Exception) { 0 }
        val date = root.optLong("exported", 0L).let { if (it > 0) SimpleDateFormat("d MMM yyyy HH:mm", Locale("id", "ID")).format(Date(it)) else "-" }
        return "Dibuat: $date\nKegiatan: ${count("tasks_json")} · Workout: ${count("workouts_v2_json")} · Catatan: ${count("notes_json")} · Target: ${count("goals_json")}"
    }

    fun restore(c: Context, root: JSONObject): Boolean {
        val data = root.optJSONObject("data") ?: return false
        val prefs = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val ed = prefs.edit()
        prefs.all.keys.filter { !it.startsWith(SecretStore.PREFIX) }.forEach { ed.remove(it) }
        val keys = data.keys()
        while (keys.hasNext()) {
            val key = keys.next()
            if (key.startsWith(SecretStore.PREFIX)) continue
            val o = data.optJSONObject(key) ?: continue
            when (o.optString("t")) {
                "s" -> ed.putString(key, o.optString("v"))
                "b" -> ed.putBoolean(key, o.optBoolean("v"))
                "i" -> ed.putInt(key, o.optInt("v"))
                "l" -> ed.putLong(key, o.optLong("v"))
                "f" -> ed.putFloat(key, o.optDouble("v").toFloat())
                "ss" -> {
                    val a = o.optJSONArray("v") ?: JSONArray()
                    val set = HashSet<String>()
                    for (i in 0 until a.length()) set.add(a.optString(i))
                    ed.putStringSet(key, set)
                }
            }
        }
        return ed.commit()
    }
}
