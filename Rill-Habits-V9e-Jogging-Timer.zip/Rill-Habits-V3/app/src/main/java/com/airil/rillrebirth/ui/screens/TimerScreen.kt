package com.airil.rillrebirth.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.airil.rillrebirth.WorkoutExercise
import com.airil.rillrebirth.WorkoutStore
import com.airil.rillrebirth.ui.components.BackButton
import com.airil.rillrebirth.ui.components.GuideSheet
import com.airil.rillrebirth.ui.components.LoopWheel
import com.airil.rillrebirth.ui.components.RillNav
import com.airil.rillrebirth.ui.components.SegmentRing
import com.airil.rillrebirth.ui.components.TimerEngine
import com.airil.rillrebirth.ui.components.iosPress
import com.airil.rillrebirth.ui.theme.IOS
import com.airil.rillrebirth.ui.theme.IOSType
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private fun clock(sec: Long): String =
    if (sec >= 3600) String.format(Locale.US, "%d:%02d:%02d", sec / 3600, (sec % 3600) / 60, sec % 60)
    else String.format(Locale.US, "%02d:%02d", sec / 60, sec % 60)

/** Free timer (flow = -1) or the rest timer between exercises (flow = workout id). */
@Composable
fun TimerScreen(nav: RillNav, flow: Long) {
    val ctx = LocalContext.current
    val c = IOS.colors
    val e = TimerEngine
    val view = LocalView.current
    DisposableEffect(e.state) { view.keepScreenOn = e.state == 1; onDispose { view.keepScreenOn = false } }

    var seen by remember { mutableIntStateOf(e.finishedCount) }
    LaunchedEffect(e.finishedCount) {
        if (e.finishedCount != seen) { seen = e.finishedCount; if (flow >= 0) nav.back() }
    }

    var hours by remember { mutableIntStateOf((e.configured / 3600).toInt().coerceIn(0, 23)) }
    var mins by remember { mutableIntStateOf(((e.configured % 3600) / 60).toInt()) }
    var secs by remember { mutableIntStateOf((e.configured % 60).toInt()) }
    var guide by remember { mutableStateOf<String?>(null) }
    var wheelKey by remember { mutableIntStateOf(0) }
    fun push() { e.configure((hours * 3600L + mins * 60L + secs).coerceAtLeast(1L)) }

    val next: WorkoutExercise? = remember(flow) {
        if (flow < 0) null else {
            val s = WorkoutStore.load(ctx).find { it.id == flow }
            if (s == null) null else {
                val checked = WorkoutStore.exerciseChecks(ctx, flow)
                val idx = (0 until s.exercises.size).firstOrNull { !checked.contains(it) }
                if (idx == null) null else s.exercises[idx]
            }
        }
    }

    Column(Modifier.fillMaxSize().background(c.background).padding(horizontal = 16.dp)) {
        // header: round back button on the left, big centred title
        Box(Modifier.fillMaxWidth().height(56.dp).padding(top = 8.dp), contentAlignment = Alignment.Center) {
            Box(Modifier.align(Alignment.CenterStart)) { BackButton(null) { nav.back() } }
            Text(if (flow >= 0) "Istirahat" else "Timer", style = IOSType.largeTitle, color = c.textPrimary, maxLines = 1)
        }

        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(top = 12.dp)) {
            if (next != null) {
                Text(
                    "Berikutnya: ${next.name} · ${next.sets} set × ${next.reps} — ketuk untuk panduan",
                    style = IOSType.body, color = c.textSecondary,
                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 4.dp).fillMaxWidth().clickableNoRipple { guide = next.name }
                )
                Spacer(Modifier.height(8.dp))
            }

            val cardShape = RoundedCornerShape(32.dp)
            Column(
                Modifier.fillMaxWidth()
                    .shadow(10.dp, cardShape, ambientColor = Color.Black.copy(alpha = 0.07f), spotColor = Color.Black.copy(alpha = 0.07f))
                    .clip(cardShape).background(c.card).padding(horizontal = 12.dp, vertical = 16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                if (e.state == 0) {
                    key(wheelKey) {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            LoopWheel(24, hours, Modifier.weight(1f)) { hours = it; push() }
                            Box(Modifier.width(1.dp).height(250.dp).background(c.separator))
                            LoopWheel(60, mins, Modifier.weight(1f)) { mins = it; push() }
                            Box(Modifier.width(1.dp).height(250.dp).background(c.separator))
                            LoopWheel(60, secs, Modifier.weight(1f)) { secs = it; push() }
                        }
                    }
                    Row(Modifier.fillMaxWidth().padding(top = 6.dp)) {
                        listOf("jam", "menit", "detik").forEach {
                            Text(it, style = IOSType.body.copy(fontSize = 18.sp), color = c.textSecondary, textAlign = TextAlign.Center, modifier = Modifier.weight(1f))
                        }
                    }
                } else {
                    val total = (e.configured + e.extra).coerceAtLeast(1L)
                    val frac = ((total - e.remaining).toFloat() / total).coerceIn(0f, 1f)
                    val urgent = e.state == 1 && e.remaining <= 10
                    val ringColor = when { urgent -> c.red; e.state == 2 -> c.textSecondary.copy(alpha = 0.7f); else -> c.primary }
                    Spacer(Modifier.height(8.dp))
                    SegmentRing(listOf(frac to ringColor), Modifier.size(260.dp), 14.dp) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                clock(e.remaining),
                                style = IOSType.number.copy(fontSize = if (e.remaining >= 3600) 44.sp else 56.sp, fontWeight = FontWeight.Medium),
                                color = if (urgent) c.red else c.textPrimary, maxLines = 1
                            )
                            Text(
                                if (e.state == 1) "berjalan" else "dijeda",
                                style = IOSType.caption.copy(fontSize = 12.sp), color = if (e.state == 1) c.primaryText else c.textSecondary,
                                modifier = Modifier.padding(top = 2.dp).clip(RoundedCornerShape(50))
                                    .background((if (e.state == 1) c.primarySoft else c.track.copy(alpha = 0.7f)))
                                    .padding(horizontal = 10.dp, vertical = 3.dp)
                            )
                            if (e.state == 1) Text(
                                "Selesai pukul " + SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(System.currentTimeMillis() + e.remaining * 1000)),
                                style = IOSType.caption, color = c.textSecondary, modifier = Modifier.padding(top = 6.dp)
                            )
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                }
            }

            // quick presets (setup) or +30 dtk (running)
            Spacer(Modifier.height(18.dp))
            if (e.state == 0) {
                val current = hours * 3600 + mins * 60 + secs
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    listOf(30 to "30 dtk", 60 to "1 mnt", 180 to "3 mnt", 300 to "5 mnt", 600 to "10 mnt", 1200 to "20 mnt", 3600 to "1 jam").forEach { (sec, label) ->
                        val on = current == sec
                        Box(
                            Modifier.height(46.dp).clip(RoundedCornerShape(16.dp))
                                .background(if (on) c.primarySoft else c.track.copy(alpha = if (c.dark) 0.7f else 0.8f))
                                .semantics { contentDescription = "Atur $label" }
                                .iosPress(Role.Button) {
                                    hours = sec / 3600; mins = (sec % 3600) / 60; secs = sec % 60
                                    e.configure(sec.toLong()); wheelKey++
                                }
                                .padding(horizontal = 20.dp),
                            contentAlignment = Alignment.Center
                        ) { Text(label, style = IOSType.body.copy(fontSize = 17.sp, fontWeight = FontWeight.Medium), color = if (on) c.primaryText else c.textPrimary, maxLines = 1) }
                    }
                }
            } else {
                Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Box(
                        Modifier.height(46.dp).clip(RoundedCornerShape(16.dp)).background(c.track.copy(alpha = if (c.dark) 0.7f else 0.8f))
                            .iosPress(Role.Button) { e.extend(30L) }.padding(horizontal = 24.dp),
                        contentAlignment = Alignment.Center
                    ) { Text("+30 dtk", style = IOSType.body.copy(fontSize = 17.sp, fontWeight = FontWeight.Medium), color = c.textPrimary) }
                }
            }
            Spacer(Modifier.height(12.dp))
        }

        // bottom actions
        Row(Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 20.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            if (e.state == 0) {
                BigButton("Batal", Modifier.weight(1f), filled = false, strong = false) { nav.back() }
                BigButton("Mulai", Modifier.weight(1f), filled = true) { push(); e.start() }
            } else {
                BigButton("Batal", Modifier.weight(1f), filled = false, strong = true) { e.stop() }
                BigButton(if (e.state == 1) "Jeda" else "Lanjut", Modifier.weight(1f), filled = true) { if (e.state == 1) e.pause() else e.start() }
            }
        }
    }
    guide?.let { GuideSheet(it) { guide = null } }
}

private fun Modifier.clickableNoRipple(onClick: () -> Unit): Modifier = this.then(
    Modifier.clickable(
        interactionSource = androidx.compose.foundation.interaction.MutableInteractionSource(),
        indication = null, onClick = onClick
    )
)

/** Big rounded action button: gray (Batal) or app-green (Mulai). */
@Composable
private fun BigButton(text: String, modifier: Modifier, filled: Boolean, strong: Boolean = true, onClick: () -> Unit) {
    val c = IOS.colors
    val bg = if (filled) (if (c.dark) c.primary else c.primaryText) else c.track.copy(alpha = if (c.dark) 0.8f else 0.9f)
    val fg = if (filled) (if (c.dark) Color(0xFF10261A) else Color.White) else if (strong) c.textPrimary else c.textSecondary
    Box(
        modifier.height(60.dp).clip(RoundedCornerShape(20.dp)).background(bg)
            .semantics { contentDescription = text }
            .iosPress(Role.Button, onClick),
        contentAlignment = Alignment.Center
    ) { Text(text, style = IOSType.headline.copy(fontSize = 20.sp, fontWeight = FontWeight.SemiBold), color = fg) }
}
