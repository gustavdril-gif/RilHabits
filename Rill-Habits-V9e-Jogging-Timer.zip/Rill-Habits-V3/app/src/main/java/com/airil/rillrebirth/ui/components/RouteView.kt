package com.airil.rillrebirth.ui.components

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.view.View
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min

/** Draws a route as a pace-coloured line on a paper-map style background (no map tiles, works offline). */
class RouteView(context: Context) : View(context) {
    private val d = context.resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var pts: List<DoubleArray> = emptyList()
    private var seg: FloatArray = FloatArray(0)     // pace colour factor per segment 0 (slow) .. 1 (fast)
    private var cum: DoubleArray = DoubleArray(0)   // cumulative metres per point

    fun setRoute(route: List<DoubleArray>) {
        pts = route
        val n = route.size
        seg = FloatArray(max(0, n - 1)); cum = DoubleArray(n)
        if (n >= 2) {
            val kx = cos(Math.toRadians((route.minOf { it[0] } + route.maxOf { it[0] }) / 2))
            val speeds = DoubleArray(n - 1)
            for (i in 1 until n) {
                val dx = (route[i][1] - route[i - 1][1]) * kx * 111320.0
                val dy = (route[i][0] - route[i - 1][0]) * 110540.0
                val dm = Math.sqrt(dx * dx + dy * dy)
                cum[i] = cum[i - 1] + dm
                val dt = route[i][2] - route[i - 1][2]
                speeds[i - 1] = if (dt > 0) dm / dt else -1.0
            }
            val valid = speeds.filter { it > 0 }.sorted()
            if (valid.size >= 2) {
                val lo = valid[(valid.size * 0.1).toInt()]; val hi = valid[min(valid.size - 1, (valid.size * 0.9).toInt())]
                for (i in speeds.indices) seg[i] = if (speeds[i] <= 0 || hi <= lo) 0.5f else ((speeds[i] - lo) / (hi - lo)).coerceIn(0.0, 1.0).toFloat()
            } else for (i in seg.indices) seg[i] = 0.5f
        }
        invalidate()
    }

    private fun mix(a: Int, b: Int, t: Float): Int {
        val r = (Color.red(a) + (Color.red(b) - Color.red(a)) * t).toInt()
        val g = (Color.green(a) + (Color.green(b) - Color.green(a)) * t).toInt()
        val bl = (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * t).toInt()
        return Color.rgb(r, g, bl)
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        p.style = Paint.Style.FILL; p.color = 0xFFEAF4E4.toInt()
        c.drawRoundRect(0f, 0f, w, h, 18 * d, 18 * d, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = 1f * d; p.color = 0xFFD5E6CF.toInt()
        var gx = 36 * d; while (gx < w) { c.drawLine(gx, 0f, gx, h, p); gx += 36 * d }
        var gy = 36 * d; while (gy < h) { c.drawLine(0f, gy, w, gy, p); gy += 36 * d }
        if (pts.size < 2) {
            p.style = Paint.Style.FILL; p.color = 0xFF7C8F7C.toInt(); p.textSize = 13 * d; p.textAlign = Paint.Align.CENTER
            c.drawText("Rute muncul saat kamu mulai bergerak", w / 2, h / 2, p)
            return
        }
        val minLat = pts.minOf { it[0] }; val maxLat = pts.maxOf { it[0] }
        val minLng = pts.minOf { it[1] }; val maxLng = pts.maxOf { it[1] }
        val kx = cos(Math.toRadians((minLat + maxLat) / 2))
        val pad = 28 * d
        val spanX = max((maxLng - minLng) * kx, 1e-6); val spanY = max(maxLat - minLat, 1e-6)
        val scale = min((w - 2 * pad) / spanX, (h - 2 * pad) / spanY)
        val offX = (w - spanX * scale) / 2; val offY = (h - spanY * scale) / 2
        fun px(lng: Double) = (offX + (lng - minLng) * kx * scale).toFloat()
        fun py(lat: Double) = (h - (offY + (lat - minLat) * scale)).toFloat()
        p.strokeCap = Paint.Cap.ROUND; p.strokeJoin = Paint.Join.ROUND
        p.color = Color.WHITE; p.strokeWidth = 9 * d
        val path = Path(); path.moveTo(px(pts[0][1]), py(pts[0][0]))
        for (i in 1 until pts.size) path.lineTo(px(pts[i][1]), py(pts[i][0]))
        c.drawPath(path, p)
        p.strokeWidth = 5 * d
        for (i in 1 until pts.size) {
            p.color = mix(0xFFFF8A3D.toInt(), 0xFF3FAF54.toInt(), seg[i - 1])
            c.drawLine(px(pts[i - 1][1]), py(pts[i - 1][0]), px(pts[i][1]), py(pts[i][0]), p)
        }
        // km markers
        p.style = Paint.Style.FILL; p.textAlign = Paint.Align.CENTER; p.textSize = 9 * d
        var nextKm = 1
        for (i in 1 until pts.size) {
            if (cum[i] >= nextKm * 1000.0) {
                val x = px(pts[i][1]); val y = py(pts[i][0])
                p.color = Color.WHITE; c.drawCircle(x, y, 9 * d, p)
                p.color = 0xFF2E7D32.toInt(); c.drawText("$nextKm", x, y + 3.2f * d, p)
                nextKm++
            }
        }
        val s = pts.first(); val e = pts.last()
        p.color = Color.WHITE; c.drawCircle(px(s[1]), py(s[0]), 8 * d, p); c.drawCircle(px(e[1]), py(e[0]), 8 * d, p)
        p.color = 0xFF2E9E4F.toInt(); c.drawCircle(px(s[1]), py(s[0]), 5.5f * d, p)
        p.color = 0xFFE53935.toInt(); c.drawCircle(px(e[1]), py(e[0]), 5.5f * d, p)
    }
}

