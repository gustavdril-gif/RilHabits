package com.airil.rillrebirth.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.airil.rillrebirth.R
import com.airil.rillrebirth.ui.theme.IOS
import com.airil.rillrebirth.ui.theme.IOSType
import dev.chrisbanes.haze.HazeState
import dev.chrisbanes.haze.HazeStyle
import dev.chrisbanes.haze.HazeTint
import dev.chrisbanes.haze.hazeEffect

data class BarTab(val label: String, val icon: Int)

val RillTabs = listOf(
    BarTab("Beranda", R.drawable.ic_home),
    BarTab("Habit", R.drawable.ic_checklist),
    BarTab("Workout", R.drawable.ic_workout),
    BarTab("Statistik", R.drawable.ic_stats)
)

/** Floating glass tab bar. Android 11 and below use Haze's experimental RenderScript blur path. */
@Composable
fun IOSBottomBar(
    selected: Int,
    onSelect: (Int) -> Unit,
    hazeState: HazeState,
    modifier: Modifier = Modifier
) {
    val colors = IOS.colors
    val shape = RoundedCornerShape(30.dp)
    val glassStyle = remember {
        HazeStyle(
            backgroundColor = Color.White.copy(alpha = 0.42f),
            blurRadius = 24.dp,
            tint = HazeTint(color = Color.White.copy(alpha = 0.28f)),
            noiseFactor = 0.08f
        )
    }

    Row(
        modifier = modifier
            .padding(horizontal = 16.dp, vertical = 14.dp)
            .fillMaxWidth()
            .height(72.dp)
            .shadow(16.dp, shape, ambientColor = Color.Black.copy(alpha = 0.12f), spotColor = Color.Black.copy(alpha = 0.12f))
            .clip(shape)
            .hazeEffect(state = hazeState, style = glassStyle) { blurEnabled = true }
            .background(Color.White.copy(alpha = 0.30f))
            .border(1.dp, Color.White.copy(alpha = 0.62f), shape)
            .padding(8.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically
    ) {
        RillTabs.forEachIndexed { index, tab ->
            val active = index == selected
            Box(
                modifier = Modifier
                    .weight(1f)
                    .height(56.dp)
                    .clip(RoundedCornerShape(22.dp))
                    .background(if (active) colors.primarySoft.copy(alpha = 0.92f) else Color.Transparent)
                    .semantics { this.selected = active }
                    .iosPress(Role.Tab) { onSelect(index) },
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        painter = painterResource(tab.icon),
                        contentDescription = tab.label,
                        tint = if (active) colors.primaryText else colors.textSecondary,
                        modifier = Modifier.size(22.dp)
                    )
                    Text(
                        text = tab.label,
                        style = IOSType.caption.copy(fontSize = 11.sp),
                        color = if (active) colors.primaryText else colors.textSecondary,
                        modifier = Modifier.padding(top = 2.dp)
                    )
                }
            }
        }
    }
}
