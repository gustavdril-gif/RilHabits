package com.airil.rillrebirth.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.airil.rillrebirth.TaskStore
import com.airil.rillrebirth.ui.components.IOSCard
import com.airil.rillrebirth.ui.components.OutlineButton
import com.airil.rillrebirth.ui.components.PrimaryButton
import com.airil.rillrebirth.ui.components.RillNav
import com.airil.rillrebirth.ui.components.ScreenScaffold
import com.airil.rillrebirth.ui.data.TodayData
import com.airil.rillrebirth.ui.theme.IOS
import com.airil.rillrebirth.ui.theme.IOSType

/** Walks through the pending morning/evening habits one by one. */
@Composable
fun RitualScreen(nav: RillNav, kind: String) {
    val ctx = LocalContext.current
    val c = IOS.colors
    val haptic = LocalHapticFeedback.current
    val ids = remember(kind) { TodayData.ritualTasks(ctx, kind).map { it.id } }
    var idx by remember { mutableIntStateOf(0) }
    var done by remember { mutableIntStateOf(0) }
    var skipped by remember { mutableIntStateOf(0) }
    var tick by remember { mutableIntStateOf(0) }
    val title = if (kind == "pagi") "Ritual Pagi 🌅" else "Ritual Malam 🌙"
    val all = remember(tick) { TaskStore.load(ctx) }
    val doneSet = remember(tick) { TaskStore.doneToday(ctx).toSet() }

    var i = idx
    while (i < ids.size && (all.none { it.id == ids[i] } || doneSet.contains(ids[i]))) i++
    val task = if (i < ids.size) all.find { it.id == ids[i] } else null

    ScreenScaffold(title = if (task == null) (if (done > 0) "Ritual selesai 🎉" else "Ritual ditutup") else title, onBack = { nav.back() }) {
        if (task == null) {
            item {
                IOSCard {
                    Text("$done tugas selesai", style = IOSType.title, color = c.primaryText)
                    if (skipped > 0) Text("$skipped dilewati — tetap ada di Habit kalau mau dikerjakan nanti.", style = IOSType.body, color = c.textSecondary, modifier = Modifier.padding(top = 4.dp))
                }
            }
            item { PrimaryButton("Kembali ke Beranda") { nav.back() } }
        } else {
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                    ids.forEachIndexed { k, id ->
                        val st = when { k == i -> 1; doneSet.contains(id) -> 2; k < i -> 3; else -> 0 }
                        Box(
                            Modifier.padding(horizontal = 4.dp).size(if (st == 1) 12.dp else 9.dp).clip(CircleShape)
                                .background(when (st) { 2 -> c.primary; 1 -> c.primary.copy(alpha = 0.5f); 3 -> c.track; else -> c.track })
                        )
                    }
                }
                Text("Langkah ${i + 1} dari ${ids.size}", style = IOSType.caption, color = c.textSecondary, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(top = 8.dp))
            }
            item {
                IOSCard {
                    Text("${TodayData.timeLabel(ctx, task)} · ${task.category}", style = IOSType.body, color = c.primaryText)
                    Text(task.name, style = IOSType.title.copy(fontSize = 26.sp), color = c.textPrimary, modifier = Modifier.padding(vertical = 10.dp))
                    Text("+${task.xp} EXP", style = IOSType.caption, color = c.textSecondary)
                }
            }
            item {
                PrimaryButton("Selesai ✓") {
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    TodayData.setDone(ctx, task.id, true)
                    done++; idx = i + 1; tick++
                }
            }
            item { OutlineButton("Lewati dulu") { skipped++; idx = i + 1; tick++ } }
        }
    }
}
