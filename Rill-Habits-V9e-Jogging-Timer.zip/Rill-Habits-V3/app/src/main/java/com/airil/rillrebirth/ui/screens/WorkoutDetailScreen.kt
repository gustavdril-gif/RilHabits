package com.airil.rillrebirth.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp
import com.airil.rillrebirth.Smart
import com.airil.rillrebirth.TaskStore
import com.airil.rillrebirth.WorkoutExercise
import com.airil.rillrebirth.WorkoutSession
import com.airil.rillrebirth.WorkoutStore
import com.airil.rillrebirth.ui.components.CircleCheck
import com.airil.rillrebirth.ui.components.EmptyState
import com.airil.rillrebirth.ui.components.GuideSheet
import com.airil.rillrebirth.ui.components.IOSCard
import com.airil.rillrebirth.ui.components.OutlineButton
import com.airil.rillrebirth.ui.components.PrimaryButton
import com.airil.rillrebirth.ui.components.RillNav
import com.airil.rillrebirth.ui.components.RillRoutes
import com.airil.rillrebirth.ui.components.ScreenScaffold
import com.airil.rillrebirth.ui.components.ThinBar
import com.airil.rillrebirth.ui.components.iosPress
import com.airil.rillrebirth.ui.theme.IOS
import com.airil.rillrebirth.ui.theme.IOSType
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun WorkoutDetailScreen(nav: RillNav, id: Long) {
    val ctx = LocalContext.current
    val c = IOS.colors
    val haptic = LocalHapticFeedback.current
    val scope = rememberCoroutineScope()
    var tick by remember { mutableIntStateOf(0) }
    var guide by remember { mutableStateOf<String?>(null) }
    val session: WorkoutSession? = remember(id, tick) { WorkoutStore.load(ctx).find { it.id == id } }
    if (session == null) {
        ScreenScaffold("Sesi tidak ditemukan", { nav.back() }) { item { EmptyState("🗓️", "Sesi sudah dihapus", "Kembali dan pilih sesi lain.") } }
        return
    }
    val checked = remember(id, tick) { WorkoutStore.exerciseChecks(ctx, id).toSet() }
    val total = session.exercises.size
    val isDone = remember(id, tick) { WorkoutStore.isDone(ctx, id) }
    val streak = remember(tick) { Smart.workoutStreak(Smart.dayStats(ctx, TaskStore.load(ctx), 365)) }
    val nextIndex = if (isDone) -1 else (0 until total).firstOrNull { !checked.contains(it) } ?: -1
    val days = session.days.sortedBy { (it + 5) % 7 }.joinToString(" ") { Smart.weekdayLabel(it) }

    fun toggle(index: Int, value: Boolean) {
        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
        val next = WorkoutStore.exerciseChecks(ctx, id)
        if (value) next.add(index) else next.remove(index)
        WorkoutStore.saveExerciseChecks(ctx, id, next)
        if (value && next.size >= total) {
            WorkoutStore.setDone(ctx, id, true)
            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
            Toast.makeText(ctx, "Workout selesai! 🔥", Toast.LENGTH_LONG).show()
            tick++
        } else {
            if (!value && WorkoutStore.isDone(ctx, id)) WorkoutStore.setDone(ctx, id, false)
            tick++
            if (value) scope.launch { delay(320); nav.go(RillRoutes.timer(id)) }
        }
    }

    ScreenScaffold(
        title = session.name, onBack = { nav.back() },
        subtitle = "${if (session.oneOffDate.isNotBlank()) session.oneOffDate else days} · ${session.time} · ${session.durationMinutes} menit",
        trailing = {
            Box(Modifier.clip(RoundedCornerShape(20.dp)).iosPress(Role.Button) { nav.go(RillRoutes.builder(id)) }.padding(horizontal = 12.dp, vertical = 10.dp)) {
                Text("Edit", style = IOSType.headline, color = c.primaryText)
            }
        }
    ) {
        if (session.notes.isNotBlank()) item { Text(session.notes, style = IOSType.body, color = c.textSecondary, modifier = Modifier.padding(horizontal = 4.dp)) }
        item {
            IOSCard {
                if (isDone) {
                    Text("✅ Sesi selesai!", style = IOSType.title, color = c.textPrimary)
                    Text("+20 XP · Streak workout $streak hari 🔥", style = IOSType.body, color = c.textSecondary, modifier = Modifier.padding(top = 4.dp))
                } else {
                    Text("${checked.size} dari $total gerakan", style = IOSType.headline, color = c.textPrimary)
                    Box(Modifier.padding(top = 10.dp)) { ThinBar(if (total == 0) 0f else checked.size.toFloat() / total, c.orange) }
                }
            }
        }
        if (total == 0) {
            item { Text("Belum ada gerakan di sesi ini. Tambahkan lewat Edit.", style = IOSType.body, color = c.textSecondary, modifier = Modifier.padding(horizontal = 4.dp)) }
            item {
                if (isDone) OutlineButton("Batalkan status selesai") { WorkoutStore.setDone(ctx, id, false); tick++ }
                else PrimaryButton("Tandai sesi selesai") { WorkoutStore.setDone(ctx, id, true); tick++ }
            }
        } else {
            item {
                IOSCard {
                    session.exercises.forEachIndexed { i, ex -> ExerciseRow(ex, i, checked.contains(i), i == nextIndex, { toggle(i, it) }, { guide = ex.name }, last = i == total - 1) }
                }
            }
            if (!isDone) item { Text("Centang gerakan yang selesai — timer istirahat muncul otomatis, lalu lanjut ke gerakan berikutnya.", style = IOSType.caption, color = c.textSecondary, modifier = Modifier.padding(horizontal = 4.dp)) }
        }
    }
    guide?.let { GuideSheet(it) { guide = null } }
}

@Composable
private fun ExerciseRow(ex: WorkoutExercise, index: Int, checked: Boolean, next: Boolean, onToggle: (Boolean) -> Unit, onInfo: () -> Unit, last: Boolean) {
    val c = IOS.colors
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(if (next) c.orange.copy(alpha = if (c.dark) 0.2f else 0.12f) else androidx.compose.ui.graphics.Color.Transparent)
            .padding(start = 8.dp, top = 4.dp, bottom = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f).padding(vertical = 6.dp)) {
            Text(ex.name, style = IOSType.headline, color = if (checked) c.textSecondary else c.textPrimary)
            Text("${ex.sets} set × ${ex.reps}", style = IOSType.caption, color = c.textSecondary)
        }
        Box(
            Modifier.size(44.dp).clickable(onClickLabel = "Panduan ${ex.name}") { onInfo() },
            contentAlignment = Alignment.Center
        ) {
            Box(Modifier.size(26.dp).clip(CircleShape).background(c.track), contentAlignment = Alignment.Center) { Text("i", style = IOSType.caption, color = c.textSecondary) }
        }
        CircleCheck(checked, (if (checked) "Batalkan " else "Selesaikan ") + ex.name, onToggle)
    }
}
