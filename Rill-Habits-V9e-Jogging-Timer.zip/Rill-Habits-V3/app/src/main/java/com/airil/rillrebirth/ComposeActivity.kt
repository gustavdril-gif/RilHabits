package com.airil.rillrebirth

import android.app.Activity
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.airil.rillrebirth.ui.components.IOSBottomBar
import com.airil.rillrebirth.ui.components.RillNav
import com.airil.rillrebirth.ui.components.RillRoutes
import com.airil.rillrebirth.ui.components.TimerEngine
import com.airil.rillrebirth.ui.screens.BerandaScreen
import com.airil.rillrebirth.ui.screens.BuilderScreen
import com.airil.rillrebirth.ui.screens.ChecklistScreen
import com.airil.rillrebirth.ui.screens.JadwalScreen
import com.airil.rillrebirth.ui.screens.JoggingHubScreen
import com.airil.rillrebirth.ui.screens.JoggingLiveScreen
import com.airil.rillrebirth.ui.screens.JoggingSummaryScreen
import com.airil.rillrebirth.ui.screens.NotesGoalsScreen
import com.airil.rillrebirth.ui.screens.RitualScreen
import com.airil.rillrebirth.ui.screens.StatistikScreen
import com.airil.rillrebirth.ui.screens.TimerScreen
import com.airil.rillrebirth.ui.screens.WorkoutDetailScreen
import com.airil.rillrebirth.ui.screens.WorkoutScreen
import com.airil.rillrebirth.ui.theme.IOS
import com.airil.rillrebirth.ui.theme.RillTheme
import dev.chrisbanes.haze.hazeSource
import dev.chrisbanes.haze.rememberHazeState

/** The single activity of the app. Every screen is a Compose destination. */
class ComposeActivity : ComponentActivity() {
    private val resumeTick = mutableIntStateOf(0)
    private val pendingOpen = mutableStateOf<String?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ReminderScheduler.scheduleAll(this)
        TimerEngine.init(this)
        pendingOpen.value = intent?.getStringExtra("open")
        addOnNewIntentListener { i -> pendingOpen.value = i.getStringExtra("open") }
        setContent {
            RillTheme {
                RillApp(resumeTick.intValue, pendingOpen.value) { pendingOpen.value = null }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        resumeTick.intValue = resumeTick.intValue + 1
    }

    override fun onPause() {
        super.onPause()
        RillWidget.updateAll(this)
    }
}

@Composable
private fun RillApp(refresh: Int, open: String?, onOpenConsumed: () -> Unit) {
    val colors = IOS.colors
    val navController = rememberNavController()
    val nav = remember(navController) { RillNav(navController) }
    val hazeState = rememberHazeState(blurEnabled = true)
    val backStackEntry = navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry.value?.destination?.route ?: RillRoutes.HOME
    val selectedTab = RillRoutes.tabIndex(currentRoute)
    val view = LocalView.current
    val context = LocalContext.current

    SideEffect {
        val window = (context as Activity).window
        window.statusBarColor = colors.background.toArgb()
        window.navigationBarColor = colors.background.toArgb()
        val controller = WindowCompat.getInsetsController(window, view)
        controller.isAppearanceLightStatusBars = !colors.dark
        controller.isAppearanceLightNavigationBars = !colors.dark
    }

    LaunchedEffect(open) {
        if (open == "jogging") nav.go(if (RunTracker.active) RillRoutes.JOG_LIVE else RillRoutes.JOGGING)
        if (open != null) onOpenConsumed()
    }

    Box(Modifier.fillMaxSize().background(colors.background)) {
        NavHost(
            navController = navController,
            startDestination = RillRoutes.HOME,
            modifier = Modifier.fillMaxSize().hazeSource(state = hazeState)
        ) {
            composable(RillRoutes.HOME) { BerandaScreen(refresh, nav) }
            composable(RillRoutes.CHECKLIST) { ChecklistScreen(refresh, nav) }
            composable(RillRoutes.WORKOUT) { WorkoutScreen(refresh, nav) }
            composable(RillRoutes.STATS) { StatistikScreen(refresh, nav) }
            composable(RillRoutes.JADWAL) { JadwalScreen(nav) }
            composable(RillRoutes.NOTES) { NotesGoalsScreen(nav) }
            composable(RillRoutes.JOGGING) { JoggingHubScreen(nav) }
            composable(RillRoutes.JOG_LIVE) { JoggingLiveScreen(nav) }
            composable(RillRoutes.JOG_SUM, arguments = listOf(navArgument("id") { type = NavType.LongType })) { e ->
                JoggingSummaryScreen(nav, e.arguments?.getLong("id") ?: 0L)
            }
            composable(RillRoutes.TIMER, arguments = listOf(navArgument("flow") { type = NavType.LongType })) { e ->
                TimerScreen(nav, e.arguments?.getLong("flow") ?: -1L)
            }
            composable(RillRoutes.WO_DETAIL, arguments = listOf(navArgument("id") { type = NavType.LongType })) { e ->
                WorkoutDetailScreen(nav, e.arguments?.getLong("id") ?: 0L)
            }
            composable(RillRoutes.BUILDER, arguments = listOf(navArgument("id") { type = NavType.LongType })) { e ->
                BuilderScreen(nav, e.arguments?.getLong("id") ?: 0L)
            }
            composable(RillRoutes.RITUAL, arguments = listOf(navArgument("kind") { type = NavType.StringType })) { e ->
                RitualScreen(nav, e.arguments?.getString("kind") ?: "pagi")
            }
        }

        // The tab bar lives on Beranda only. Habit, Workout and Statistik hide it and show a back button at the top left.
        AnimatedVisibility(
            visible = currentRoute == RillRoutes.HOME,
            enter = slideInVertically { it } + fadeIn(),
            exit = slideOutVertically { it } + fadeOut(),
            modifier = Modifier.align(Alignment.BottomCenter)
        ) {
            IOSBottomBar(
                selected = selectedTab,
                hazeState = hazeState,
                onSelect = { index ->
                    val route = RillRoutes.routeFor(index)
                    if (route != RillRoutes.HOME && route != currentRoute) navController.navigate(route) { launchSingleTop = true }
                }
            )
        }
    }
}
