package com.airil.rillrebirth.ui.components

import android.view.Gravity
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.airil.rillrebirth.ui.theme.IOS
import org.maplibre.android.MapLibre
import org.maplibre.android.camera.CameraUpdateFactory
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.geometry.LatLngBounds
import org.maplibre.android.maps.MapLibreMap
import org.maplibre.android.maps.MapView
import org.maplibre.android.maps.Style
import org.maplibre.android.style.layers.CircleLayer
import org.maplibre.android.style.layers.LineLayer
import org.maplibre.android.style.layers.Property
import org.maplibre.android.style.layers.PropertyFactory
import org.maplibre.android.style.sources.GeoJsonSource
import org.maplibre.geojson.Feature
import org.maplibre.geojson.FeatureCollection
import org.maplibre.geojson.LineString
import org.maplibre.geojson.Point

/**
 * Open-source map (MapLibre Native). Free vector styles, no API key:
 *  - light: OpenFreeMap "positron"  (OpenMapTiles data, OpenStreetMap contributors)
 *  - dark : CARTO "dark-matter"     (OpenStreetMap contributors, CARTO)
 * To use another provider, change [LIGHT_STYLE] / [DARK_STYLE].
 */
const val LIGHT_STYLE = "https://tiles.openfreemap.org/styles/positron"
const val DARK_STYLE = "https://basemaps.cartocdn.com/gl/dark-matter-gl-style/style.json"

private class MapParams(
    val route: List<DoubleArray>,   // lat, lng, movSeconds
    val me: DoubleArray?,           // lat, lng of the blue dot
    val follow: Boolean,
    val fit: Boolean,
    val bottomPx: Int,
    val zoom: Double
)

private class MapHolder(val dashed: Boolean, val lineColor: Int, val dotColor: Int) {
    var map: MapLibreMap? = null
    var style: Style? = null
    var p: MapParams? = null
    var camKey: String = ""

    fun addLayers(st: Style) {
        st.addSource(GeoJsonSource("rill-route"))
        val line = LineLayer("rill-route-line", "rill-route").withProperties(
            PropertyFactory.lineColor(lineColor),
            PropertyFactory.lineWidth(if (dashed) 3f else 5.5f),
            PropertyFactory.lineCap(Property.LINE_CAP_ROUND),
            PropertyFactory.lineJoin(Property.LINE_JOIN_ROUND)
        )
        if (dashed) line.setProperties(PropertyFactory.lineDasharray(arrayOf(2f, 2f)))
        st.addLayer(line)
        st.addSource(GeoJsonSource("rill-me"))
        st.addLayer(CircleLayer("rill-me-halo", "rill-me").withProperties(PropertyFactory.circleRadius(12f), PropertyFactory.circleColor(0xFFFFFFFF.toInt())))
        st.addLayer(CircleLayer("rill-me-dot", "rill-me").withProperties(PropertyFactory.circleRadius(8f), PropertyFactory.circleColor(dotColor)))
    }

    fun render() {
        val st = style ?: return
        val map = map ?: return
        val p = p ?: return
        val pts = p.route.map { LatLng(it[0], it[1]) }

        st.getSourceAs<GeoJsonSource>("rill-route")?.let { src ->
            if (pts.size >= 2) src.setGeoJson(Feature.fromGeometry(LineString.fromLngLats(pts.map { Point.fromLngLat(it.longitude, it.latitude) })))
            else src.setGeoJson(FeatureCollection.fromFeatures(ArrayList<Feature>()))
        }
        st.getSourceAs<GeoJsonSource>("rill-me")?.let { src ->
            val m = p.me
            if (m != null) src.setGeoJson(Feature.fromGeometry(Point.fromLngLat(m[1], m[0])))
            else src.setGeoJson(FeatureCollection.fromFeatures(ArrayList<Feature>()))
        }

        val focus: LatLng? = p.me?.let { LatLng(it[0], it[1]) } ?: pts.lastOrNull()
        val key = "${pts.size}|${focus?.latitude}|${focus?.longitude}|${p.fit}|${p.follow}|${p.bottomPx}"
        if (key == camKey) return
        camKey = key
        map.setPadding(0, 0, 0, p.bottomPx)
        try {
            when {
                p.fit && pts.size >= 2 -> {
                    val b = LatLngBounds.Builder().includes(pts).build()
                    val pad = 64
                    map.moveCamera(CameraUpdateFactory.newLatLngBounds(b, pad, pad, pad, pad))
                }
                p.follow && focus != null -> map.easeCamera(CameraUpdateFactory.newLatLngZoom(focus, p.zoom), 600)
                focus != null -> map.moveCamera(CameraUpdateFactory.newLatLngZoom(focus, p.zoom))
                else -> map.moveCamera(CameraUpdateFactory.newLatLngZoom(LatLng(-6.2, 106.82), 11.0))
            }
        } catch (_: Exception) {
            focus?.let { map.moveCamera(CameraUpdateFactory.newLatLngZoom(it, p.zoom)) }
        }
    }
}

/**
 * @param route    points as [lat, lng, movSeconds]
 * @param me       position of the blue dot (null = none)
 * @param follow   keep the camera on the newest point (live recording)
 * @param fit      zoom to fit the whole route (summary)
 * @param dashed   draw the route as a thin dashed line (a past run shown as a hint)
 * @param bottomPadDp  part of the map hidden under a sheet; the camera centres in the visible part
 * Falls back to the offline [RouteView] drawing if the map style cannot be loaded (no internet).
 */
@Composable
fun RillMap(
    route: List<DoubleArray>,
    modifier: Modifier = Modifier,
    me: DoubleArray? = null,
    follow: Boolean = false,
    fit: Boolean = false,
    dashed: Boolean = false,
    interactive: Boolean = false,
    bottomPadDp: Int = 0,
    zoom: Double = 15.5
) {
    val ctx = LocalContext.current
    val c = IOS.colors
    val density = LocalDensity.current.density
    val lifecycle = LocalLifecycleOwner.current.lifecycle
    var failed by remember { mutableStateOf(false) }
    val lineColor = c.blue.toArgb()
    val dotColor = c.blue.toArgb()

    // Re-created when the theme flips, so the map style switches between light and dark.
    val holder = remember(c.dark, dashed) { MapHolder(dashed, lineColor, dotColor) }
    val mapView = remember(c.dark, dashed, interactive) {
        MapLibre.getInstance(ctx.applicationContext)
        MapView(ctx).also { mv ->
            mv.addOnDidFailLoadingMapListener { failed = true }
            mv.getMapAsync { map ->
                holder.map = map
                map.uiSettings.apply {
                    isLogoEnabled = false
                    isCompassEnabled = false
                    isAttributionEnabled = true
                    attributionGravity = Gravity.TOP or Gravity.END
                    setAttributionMargins(0, (10 * density).toInt(), (10 * density).toInt(), 0)
                    isRotateGesturesEnabled = false
                    isTiltGesturesEnabled = false
                    if (!interactive) setAllGesturesEnabled(false)
                }
                map.setStyle(Style.Builder().fromUri(if (c.dark) DARK_STYLE else LIGHT_STYLE)) { st ->
                    holder.addLayers(st)
                    holder.style = st
                    holder.render()
                }
            }
        }
    }

    DisposableEffect(mapView, lifecycle) {
        var destroyed = false
        var created = false
        val obs = LifecycleEventObserver { _, e ->
            if (destroyed) return@LifecycleEventObserver
            when (e) {
                Lifecycle.Event.ON_CREATE -> { if (!created) { mapView.onCreate(null); created = true } }
                Lifecycle.Event.ON_START -> mapView.onStart()
                Lifecycle.Event.ON_RESUME -> mapView.onResume()
                Lifecycle.Event.ON_PAUSE -> mapView.onPause()
                Lifecycle.Event.ON_STOP -> mapView.onStop()
                Lifecycle.Event.ON_DESTROY -> { mapView.onDestroy(); destroyed = true }
                else -> Unit
            }
        }
        // Compose enters while the activity is already resumed, so make sure onCreate ran first.
        if (!created) { mapView.onCreate(null); created = true }
        lifecycle.addObserver(obs)
        onDispose {
            lifecycle.removeObserver(obs)
            if (!destroyed) {
                destroyed = true
                try { mapView.onPause(); mapView.onStop(); mapView.onDestroy() } catch (_: Exception) { }
            }
        }
    }

    // SideEffect (not AndroidView.update) so the map refreshes on every recomposition, e.g. each new GPS point.
    SideEffect { holder.p = MapParams(route, me, follow, fit, (bottomPadDp * density).toInt(), zoom); holder.render() }

    if (failed) {
        AndroidView(factory = { RouteView(it) }, update = { it.setRoute(route) }, modifier = modifier)
    } else {
        AndroidView(factory = { mapView }, modifier = modifier)
    }
}
