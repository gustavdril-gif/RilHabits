package com.airil.rillrebirth

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import java.util.Calendar

data class TodaySnapshot(val done: Int, val total: Int, val percent: Int, val nextLine: String, val streak: Int, val level: Int, val xpToday: Int)

/** Computes "today" without an Activity so the widget can show it. Mirrors the in-app rules (days, lapsed prayers, prayer-linked times). */
object TodayInfo {
    fun taskMinutes(c: Context, t: RillTask): Int {
        if (t.prayer.isNotEmpty()) PrayerTimes.minutes(c, t.prayer)?.let { return it }
        val p = t.time.split(":")
        return (p.getOrNull(0)?.toIntOrNull() ?: 0) * 60 + (p.getOrNull(1)?.toIntOrNull() ?: 0)
    }

    fun snapshot(c: Context): TodaySnapshot {
        val cal = Calendar.getInstance()
        val now = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
        val all = TaskStore.load(c)
        val today = all.filter { it.runsOn(cal.get(Calendar.DAY_OF_WEEK)) }
        val done = TaskStore.doneToday(c)
        fun lapsed(t: RillTask) = !done.contains(t.id) && Smart.isPrayer(t) && now > taskMinutes(c, t) + Smart.PRAYER_GRACE_MIN
        val live = today.filter { !lapsed(it) }
        val sessions = WorkoutStore.sessionsForDate(c)
        val sessionsDone = sessions.count { WorkoutStore.isDone(c, it.id) }
        val total = live.size + sessions.size
        val doneN = live.count { done.contains(it.id) } + sessionsDone
        val pending = live.filter { !done.contains(it.id) }.sortedBy { taskMinutes(c, it) }
        val next = pending.firstOrNull { taskMinutes(c, it) >= now } ?: pending.firstOrNull()
        val line = when {
            total == 0 -> "Belum ada kegiatan hari ini"
            next != null -> "Berikutnya: ${next.name} · ${PrayerTimes.format(taskMinutes(c, next))}"
            sessionsDone < sessions.size -> "Tinggal workout hari ini 💪"
            else -> "Semua selesai 🎉"
        }
        val streak = Smart.habitStreak(Smart.dayStats(c, all, 120))
        val level = (TaskStore.totalXp(c) + WorkoutStore.totalWorkoutXp(c)) / 100 + 1
        val xpToday = TaskStore.xpFor(c, done) + WorkoutStore.workoutXpToday(c)
        return TodaySnapshot(doneN, total, if (total == 0) 0 else doneN * 100 / total, line, streak, level, xpToday)
    }
}

/** Home-screen widget: today's progress, the next task, streak and level. Tap opens the app. */
class RillWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        appWidgetIds.forEach { render(context, appWidgetManager, it) }
    }

    companion object {
        fun updateAll(context: Context) {
            try {
                val mgr = AppWidgetManager.getInstance(context)
                val ids = mgr.getAppWidgetIds(ComponentName(context, RillWidget::class.java))
                ids.forEach { render(context, mgr, it) }
            } catch (_: Exception) { }
        }

        private fun render(context: Context, mgr: AppWidgetManager, id: Int) {
            val s = try { TodayInfo.snapshot(context) } catch (_: Exception) { null }
            val v = RemoteViews(context.packageName, R.layout.widget_progress)
            if (s == null) {
                v.setTextViewText(R.id.w_main, "RilHabit")
                v.setTextViewText(R.id.w_next, "Buka aplikasi untuk memuat data")
            } else {
                v.setTextViewText(R.id.w_main, if (s.total == 0) "Santai hari ini" else "${s.done} dari ${s.total} selesai")
                v.setTextViewText(R.id.w_percent, "${s.percent}%")
                v.setProgressBar(R.id.w_bar, 100, s.percent, false)
                v.setTextViewText(R.id.w_next, s.nextLine)
                v.setTextViewText(R.id.w_stats, "🔥 Streak ${s.streak} hari  ·  Level ${s.level}  ·  +${s.xpToday} EXP")
            }
            val open = PendingIntent.getActivity(
                context, 77, Intent(context, ComposeActivity::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or if (android.os.Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0
            )
            v.setOnClickPendingIntent(R.id.w_root, open)
            mgr.updateAppWidget(id, v)
        }
    }
}
