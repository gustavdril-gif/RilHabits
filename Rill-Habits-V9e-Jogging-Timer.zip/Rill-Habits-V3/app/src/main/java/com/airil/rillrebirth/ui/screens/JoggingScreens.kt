package com.airil.rillrebirth.ui.screens

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.LocationManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import com.airil.rillrebirth.JogPlan
import com.airil.rillrebirth.JogPlanStore
import com.airil.rillrebirth.R
import com.airil.rillrebirth.ui.components.BackButton
import com.airil.rillrebirth.ui.components.ChipRow
import com.airil.rillrebirth.ui.components.ChoiceChip
import com.airil.rillrebirth.ui.components.FieldLabel
import com.airil.rillrebirth.ui.components.IOSField
import com.airil.rillrebirth.ui.components.IOSSheet
import com.airil.rillrebirth.ui.components.RillMap
import com.airil.rillrebirth.ui.components.WeekOrder
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.airil.rillrebirth.Fmt
import com.airil.rillrebirth.RunRecord
import com.airil.rillrebirth.RunService
import com.airil.rillrebirth.RunStore
import com.airil.rillrebirth.RunTracker
import com.airil.rillrebirth.ui.components.ConfirmDialog
import com.airil.rillrebirth.ui.components.EmptyState
import com.airil.rillrebirth.ui.components.IOSCard
import com.airil.rillrebirth.ui.components.OutlineButton
import com.airil.rillrebirth.ui.components.PrimaryButton
import com.airil.rillrebirth.ui.components.RillNav
import com.airil.rillrebirth.ui.components.RillRoutes
import com.airil.rillrebirth.ui.components.RouteView
import com.airil.rillrebirth.ui.components.ScreenScaffold
import com.airil.rillrebirth.ui.components.SectionTitle
import com.airil.rillrebirth.ui.components.ThinBar
import com.airil.rillrebirth.ui.components.iosPress
import com.airil.rillrebirth.ui.data.TodayData
import com.airil.rillrebirth.ui.theme.IOS
import com.airil.rillrebirth.ui.theme.IOSType
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.max
import kotlin.math.roundToInt

private fun dateText(ms: Long) = SimpleDateFormat("EEE, d MMM · HH:mm", Locale("id", "ID")).format(Date(ms))

private fun openAppSettings(ctx: Context) {
    try { ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}"))) } catch (_: Exception) { }
}

// ============================ HUB ============================
private fun kmLabel(k: Double) = if (k % 1.0 == 0.0) k.toInt().toString() else String.format(Locale.US, "%.1f", k)

private fun lastKnown(ctx: Context): DoubleArray? {
    val fine = ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
    val coarse = ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
    if (!fine && !coarse) return null
    return try {
        val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val l = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER, LocationManager.PASSIVE_PROVIDER)
            .mapNotNull { p -> try { lm.getLastKnownLocation(p) } catch (_: Exception) { null } }
            .maxByOrNull { it.time }
        l?.let { doubleArrayOf(it.latitude, it.longitude) }
    } catch (_: Exception) { null }
}

/** Small floating chip on top of the map. */
@Composable
private fun MapChip(text: String, dot: Color, modifier: Modifier = Modifier) {
    val c = IOS.colors
    Row(
        modifier.shadow(6.dp, RoundedCornerShape(50), ambientColor = Color.Black.copy(alpha = 0.12f), spotColor = Color.Black.copy(alpha = 0.12f))
            .clip(RoundedCornerShape(50)).background(c.card).padding(horizontal = 12.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(8.dp).clip(CircleShape).background(dot))
        Spacer(Modifier.width(7.dp))
        Text(text, style = IOSType.caption.copy(fontWeight = FontWeight.Medium), color = c.textPrimary)
    }
}

@Composable
private fun StatTile(icon: Int, value: String, label: String, modifier: Modifier = Modifier) {
    val c = IOS.colors
    Row(modifier.clip(RoundedCornerShape(18.dp)).background(c.background).padding(horizontal = 14.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(painterResource(icon), contentDescription = null, tint = c.primaryText, modifier = Modifier.size(24.dp))
        Spacer(Modifier.width(10.dp))
        Column {
            Text(value, style = IOSType.title, color = c.textPrimary, maxLines = 1)
            Text(label, style = IOSType.caption, color = c.textSecondary, maxLines = 1)
        }
    }
}

@Composable
fun JoggingHubScreen(nav: RillNav) {
    val ctx = LocalContext.current
    val c = IOS.colors
    var tick by remember { mutableIntStateOf(0) }
    var tips by remember { mutableStateOf(false) }
    var gpsOff by remember { mutableStateOf(false) }
    var denied by remember { mutableStateOf(false) }
    var planEdit by remember { mutableStateOf<JogPlan?>(null) }
    var planNew by remember { mutableStateOf(false) }
    val runs = remember(tick) { RunStore.load(ctx) }
    val plans = remember(tick) { JogPlanStore.load(ctx) }
    val recovered = remember(tick) { if (RunTracker.active) emptyList() else RunStore.recoverPoints(ctx) }
    val beep = remember(tick) { ctx.getSharedPreferences("rill_data", Context.MODE_PRIVATE).getBoolean("run_beep", true) }
    val lastRoute = remember(runs) { runs.maxByOrNull { it.start }?.let { RunStore.parseRoute(it.route) } ?: emptyList() }
    val myLoc = remember(tick) { lastKnown(ctx) }
    val gpsOn = try { (ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager).isProviderEnabled(LocationManager.GPS_PROVIDER) } catch (_: Exception) { false }

    fun beginRun() {
        val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        if (!lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) { gpsOff = true; return }
        RunTracker.begin(ctx)
        RunService.send(ctx, RunService.ACTION_START)
        nav.go(RillRoutes.JOG_LIVE)
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { _ ->
        tick++
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) beginRun() else denied = true
    }
    fun requestStart() {
        val need = mutableListOf<String>()
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) { need.add(Manifest.permission.ACCESS_FINE_LOCATION); need.add(Manifest.permission.ACCESS_COARSE_LOCATION) }
        if (Build.VERSION.SDK_INT >= 29 && ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACTIVITY_RECOGNITION) != PackageManager.PERMISSION_GRANTED) need.add(Manifest.permission.ACTIVITY_RECOGNITION)
        if (need.isNotEmpty()) launcher.launch(need.toTypedArray()) else beginRun()
    }

    val weekStart = remember { Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0); add(Calendar.DAY_OF_YEAR, -((get(Calendar.DAY_OF_WEEK) + 5) % 7)) }.timeInMillis }
    val monthStart = remember { Calendar.getInstance().apply { set(Calendar.DAY_OF_MONTH, 1); set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }.timeInMillis }
    val w = runs.filter { it.start >= weekStart }
    val m = runs.filter { it.start >= monthStart }
    val best = runs.filter { it.distM >= 1000 }.minOfOrNull { it.avgPaceSec } ?: 0
    val longest = runs.maxOfOrNull { it.distM } ?: 0.0
    val onPrimary = if (c.dark) Color(0xFF10261A) else Color.White

    BoxWithConstraints(Modifier.fillMaxSize().background(c.background)) {
        val sheetTop = maxHeight * 0.30f
        RillMap(
            route = lastRoute, me = myLoc, dashed = true, fit = myLoc == null && lastRoute.size >= 2,
            bottomPadDp = (maxHeight.value * 0.70f).toInt(), zoom = 14.5, modifier = Modifier.fillMaxSize()
        )
        // top overlay: back button + GPS status
        Box(Modifier.fillMaxWidth().padding(top = 12.dp, start = 16.dp, end = 16.dp)) {
            Box(Modifier.align(Alignment.CenterStart)) { BackButton(null) { nav.back() } }
            MapChip(if (gpsOn) "GPS aktif" else "GPS mati", if (gpsOn) c.primary else c.orange, Modifier.align(Alignment.Center))
        }

        Column(
            Modifier.fillMaxSize().padding(top = sheetTop)
                .clip(RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp)).background(c.card)
                .verticalScroll(rememberScrollState())
                .padding(start = 20.dp, end = 20.dp, top = 22.dp, bottom = 40.dp)
        ) {
            if (RunTracker.active) {
                Text("Jogging sedang direkam", style = IOSType.title, color = c.textPrimary, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                Text("${Fmt.km(RunTracker.distM)} km · ${Fmt.dur(RunTracker.elapsedMs())}", style = IOSType.body, color = c.textSecondary, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(top = 2.dp, bottom = 14.dp))
                PrimaryButton("Buka rekaman", height = 54.dp) { nav.go(RillRoutes.JOG_LIVE) }
            } else {
                if (recovered.size >= 2) {
                    Column(Modifier.fillMaxWidth().padding(bottom = 16.dp).clip(RoundedCornerShape(18.dp)).background(c.background).padding(16.dp)) {
                        Text("Rekaman terputus ditemukan", style = IOSType.headline, color = c.orange)
                        Text("${Fmt.km(recovered.last().dist)} km sempat terekam sebelum aplikasi berhenti. Simpan sebagai jogging?", style = IOSType.body, color = c.textSecondary, modifier = Modifier.padding(top = 2.dp, bottom = 10.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            OutlineButton("Buang", Modifier.weight(1f)) { RunTracker.activeFile(ctx).delete(); tick++ }
                            PrimaryButton("Simpan", Modifier.weight(1f)) {
                                val start = ctx.getSharedPreferences("rill_data", Context.MODE_PRIVATE).getLong("run_active_start", recovered.first().t)
                                val r = RunStore.recordFrom(ctx, start, recovered.last().t - start, recovered.last().mov, recovered.last().dist, recovered, 0, true)
                                RunStore.attachTrack(ctx, r.id); RunStore.add(ctx, r); tick++; nav.go(RillRoutes.jogSum(r.id))
                            }
                        }
                    }
                }
                Text("Siap lari?", style = IOSType.largeTitle, color = c.textPrimary, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(14.dp))
                PrimaryButton("Mulai Jogging", height = 54.dp) { requestStart() }
                Spacer(Modifier.height(10.dp))
                ChipRow {
                    ChoiceChip("Bunyi tiap km: ${if (beep) "Aktif" else "Mati"}", beep) {
                        ctx.getSharedPreferences("rill_data", Context.MODE_PRIVATE).edit().putBoolean("run_beep", !beep).apply(); tick++
                    }
                    ChoiceChip("Tips rekaman", false) { tips = true }
                }
            }

            Spacer(Modifier.height(18.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StatTile(R.drawable.ic_route, "${Fmt.km(w.sumOf { it.distM })} km", "minggu ini", Modifier.weight(1f))
                StatTile(R.drawable.ic_calendar, "${Fmt.km(m.sumOf { it.distM })} km", "bulan ini", Modifier.weight(1f))
            }
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StatTile(R.drawable.ic_clock, Fmt.pace(best), "pace terbaik", Modifier.weight(1f))
                StatTile(R.drawable.ic_peak, "${Fmt.km(longest)} km", "lari terjauh", Modifier.weight(1f))
            }

            // ---- schedule ----
            Spacer(Modifier.height(26.dp))
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("Jadwal jogging mu", style = IOSType.title, color = c.textPrimary, modifier = Modifier.weight(1f))
                Box(Modifier.clip(RoundedCornerShape(50)).background(c.primarySoft).iosPress(Role.Button) { planNew = true }.padding(horizontal = 14.dp, vertical = 7.dp)) {
                    Text("+ Tambah", style = IOSType.caption.copy(fontWeight = FontWeight.SemiBold), color = c.primaryText)
                }
            }
            if (plans.isEmpty()) {
                Text("Belum ada jadwal. Ketuk Tambah untuk menentukan hari, jam, dan target jarak larimu.", style = IOSType.body, color = c.textSecondary, modifier = Modifier.padding(top = 8.dp))
            } else {
                Spacer(Modifier.height(6.dp))
                plans.forEachIndexed { i, p ->
                    if (i > 0) Box(Modifier.fillMaxWidth().height(1.dp).background(c.separator))
                    Row(Modifier.fillMaxWidth().iosPress(Role.Button) { planEdit = p }.padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(40.dp).clip(CircleShape).background(if (c.dark) c.primary else c.primaryText), contentAlignment = Alignment.Center) {
                            Text(JogPlanStore.dayShort(p.day), style = IOSType.caption.copy(fontWeight = FontWeight.SemiBold), color = onPrimary)
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(JogPlanStore.dayName(p.day), style = IOSType.headline, color = c.textPrimary)
                            Text("Pukul ${p.time} · ${kmLabel(p.km)} km", style = IOSType.caption, color = c.textSecondary)
                        }
                    }
                }
            }

            // ---- history ----
            Spacer(Modifier.height(26.dp))
            Text("Riwayat", style = IOSType.title, color = c.textPrimary)
            if (runs.isEmpty()) {
                Text("Belum ada rekaman. Lari pertamamu akan muncul di sini.", style = IOSType.body, color = c.textSecondary, modifier = Modifier.padding(top = 8.dp))
            } else {
                Spacer(Modifier.height(6.dp))
                runs.sortedByDescending { it.start }.take(30).forEachIndexed { i, r ->
                    if (i > 0) Box(Modifier.fillMaxWidth().height(1.dp).background(c.separator))
                    Column(Modifier.fillMaxWidth().iosPress(Role.Button) { nav.go(RillRoutes.jogSum(r.id)) }.padding(vertical = 10.dp)) {
                        Text("${dateText(r.start)} · ${Fmt.km(r.distM)} km", style = IOSType.headline, color = c.textPrimary)
                        Text("${Fmt.dur(r.movMs)} · pace ${Fmt.pace(r.avgPaceSec)}/km", style = IOSType.caption, color = c.textSecondary)
                    }
                }
            }
        }
    }

    if (planNew) PlanSheet(null) { planNew = false; tick++ }
    planEdit?.let { p -> PlanSheet(p) { planEdit = null; tick++ } }

    if (tips) AlertDialog(
        onDismissRequest = { tips = false },
        title = { Text("Agar rekaman tidak terputus") },
        text = { Text("Di HP Xiaomi/Redmi, sistem sering mematikan aplikasi di latar belakang. Cek sekali saja:\n\n1. Pengaturan → Aplikasi → Rill Habits → Penghemat baterai → Tanpa batasan.\n2. Aktifkan Mulai otomatis.\n3. Izin → Lokasi → \"Izinkan sepanjang waktu\" atau \"Saat aplikasi digunakan\".\n4. Kunci aplikasi di layar aplikasi terbaru.\n5. Nyalakan Lokasi dengan akurasi tinggi (GPS).\n\nJika sesi sempat terputus, bagian yang sudah terekam bisa dipulihkan di halaman ini.") },
        confirmButton = { TextButton(onClick = { tips = false }) { Text("Mengerti") } },
        dismissButton = { TextButton(onClick = { tips = false; openAppSettings(ctx) }) { Text("Buka pengaturan aplikasi") } }
    )
    if (gpsOff) AlertDialog(
        onDismissRequest = { gpsOff = false },
        title = { Text("GPS mati") }, text = { Text("Nyalakan Lokasi (GPS) dulu supaya jejakmu terekam.") },
        confirmButton = { TextButton(onClick = { gpsOff = false; try { ctx.startActivity(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)) } catch (_: Exception) { } }) { Text("Buka pengaturan lokasi") } },
        dismissButton = { TextButton(onClick = { gpsOff = false }) { Text("Batal") } }
    )
    if (denied) AlertDialog(
        onDismissRequest = { denied = false },
        title = { Text("Izin lokasi dibutuhkan") }, text = { Text("Tanpa izin lokasi, jejak dan pace tidak bisa direkam. Kamu bisa mengizinkannya di pengaturan aplikasi.") },
        confirmButton = { TextButton(onClick = { denied = false; openAppSettings(ctx) }) { Text("Buka pengaturan") } },
        dismissButton = { TextButton(onClick = { denied = false }) { Text("Batal") } }
    )
}

/** Add / edit one weekly run (day, time, distance target). */
@Composable
private fun PlanSheet(existing: JogPlan?, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val c = IOS.colors
    var day by remember { mutableIntStateOf(existing?.day ?: Calendar.MONDAY) }
    var time by remember { mutableStateOf(existing?.time ?: "06:30") }
    var km by remember { mutableStateOf(existing?.let { kmLabel(it.km) } ?: "3") }
    var confirm by remember { mutableStateOf(false) }
    IOSSheet(onClose) {
        Text(if (existing == null) "Jadwal jogging baru" else "Ubah jadwal", style = IOSType.title, color = c.textPrimary)
        FieldLabel("HARI")
        ChipRow { WeekOrder.forEach { d -> ChoiceChip(JogPlanStore.dayName(d), day == d) { day = d } } }
        FieldLabel("JAM (HH:MM)")
        IOSField(time, { time = it.filter { ch -> ch.isDigit() || ch == ':' }.take(5) }, "06:30", singleLine = true)
        FieldLabel("TARGET JARAK (KM)")
        IOSField(km, { km = it.filter { ch -> ch.isDigit() || ch == '.' || ch == ',' }.take(5) }, "3", singleLine = true, numeric = true)
        Spacer(Modifier.height(16.dp))
        PrimaryButton("Simpan") {
            val t = time.trim()
            val dist = km.replace(',', '.').toDoubleOrNull()
            if (!Regex("^([01]?[0-9]|2[0-3]):[0-5][0-9]$").matches(t)) { Toast.makeText(ctx, "Isi jam yang valid, mis. 06:30.", Toast.LENGTH_LONG).show(); return@PrimaryButton }
            if (dist == null || dist <= 0.0 || dist > 100.0) { Toast.makeText(ctx, "Isi target jarak antara 0 dan 100 km.", Toast.LENGTH_LONG).show(); return@PrimaryButton }
            val hh = t.substringBefore(":").toInt(); val mm = t.substringAfter(":").toInt()
            JogPlanStore.upsert(ctx, JogPlan(existing?.id ?: JogPlanStore.nextId(ctx), day, String.format(Locale.US, "%02d:%02d", hh, mm), dist))
            onClose()
        }
        if (existing != null) {
            Spacer(Modifier.height(8.dp))
            OutlineButton("Hapus jadwal") { confirm = true }
        }
    }
    if (confirm && existing != null) ConfirmDialog("Hapus jadwal?", "Jadwal ${JogPlanStore.dayName(existing.day)} pukul ${existing.time} akan dihapus.", "Hapus", {
        JogPlanStore.delete(ctx, existing.id); confirm = false; onClose()
    }, { confirm = false })
}

// ============================ LIVE ============================
@Composable
fun JoggingLiveScreen(nav: RillNav) {
    val ctx = LocalContext.current
    val c = IOS.colors
    val view = LocalView.current
    var clock by remember { mutableLongStateOf(0L) }
    var confirm by remember { mutableStateOf(false) }
    DisposableEffect(Unit) { view.keepScreenOn = true; onDispose { view.keepScreenOn = false } }
    LaunchedEffect(Unit) { while (true) { kotlinx.coroutines.delay(1000); clock++ } }
    LaunchedEffect(clock) { if (!RunTracker.active && clock > 1) nav.back() }

    @Suppress("UNUSED_VARIABLE") val tickRead = clock   // reading it makes this screen recompose every second
    val paused = RunTracker.paused
    val age = System.currentTimeMillis() - RunTracker.lastFixMs
    val (gpsText, gpsColor) = when {
        paused -> Pair("Dijeda", c.textSecondary)
        RunTracker.lastFixMs == 0L -> Pair("Mencari sinyal GPS…", c.orange)
        age > 15000 -> Pair("Sinyal GPS hilang", c.red)
        RunTracker.accuracy <= 12f -> Pair("GPS sangat baik", c.primary)
        RunTracker.accuracy <= 22f -> Pair("GPS baik", c.primary)
        else -> Pair("GPS cukup", c.orange)
    }
    val paceNow = if (!paused && RunTracker.curSpeed > 0.8f) Fmt.pace((1000f / RunTracker.curSpeed).roundToInt()) else "--:--"
    val st = RunTracker.steps()
    val steps = if (st > 0) "$st" else if (RunTracker.distM > 0) "≈${(RunTracker.distM / 0.9).toInt()}" else "0"
    val all = RunTracker.pts
    val step = max(1, all.size / 200)
    val route = all.filterIndexed { i, _ -> i % step == 0 || i == all.lastIndex }.map { doubleArrayOf(it.lat, it.lng, it.mov / 1000.0) }
    val me = route.lastOrNull()?.let { doubleArrayOf(it[0], it[1]) }
    val pillBg = if (c.dark) Color.Black else c.card
    val pillFg = if (c.dark) Color.White else c.textPrimary

    Box(Modifier.fillMaxSize().background(c.background)) {
        RillMap(route = route, me = me, follow = true, bottomPadDp = 240, zoom = 16.5, modifier = Modifier.fillMaxSize())

        Box(Modifier.fillMaxWidth().padding(top = 14.dp, start = 16.dp, end = 16.dp)) {
            Box(Modifier.align(Alignment.TopStart)) { BackButton(null) { nav.back() } }
            Column(Modifier.align(Alignment.TopCenter), horizontalAlignment = Alignment.CenterHorizontally) {
                Row(
                    Modifier.shadow(8.dp, RoundedCornerShape(40.dp), ambientColor = Color.Black.copy(alpha = 0.15f), spotColor = Color.Black.copy(alpha = 0.15f))
                        .clip(RoundedCornerShape(40.dp)).background(pillBg).padding(horizontal = 22.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(painterResource(R.drawable.ic_pin), contentDescription = null, tint = pillFg, modifier = Modifier.size(26.dp))
                    Spacer(Modifier.width(10.dp))
                    Text(Fmt.dur(RunTracker.elapsedMs()), style = IOSType.number.copy(fontSize = 44.sp), color = pillFg, maxLines = 1)
                }
                Spacer(Modifier.height(8.dp))
                MapChip(gpsText, gpsColor)
            }
        }

        Column(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth()
                .clip(RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp)).background(c.card)
                .padding(start = 20.dp, end = 20.dp, top = 22.dp, bottom = 22.dp)
        ) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                LiveStat(Fmt.km(RunTracker.distM), "km Jarak", Modifier.weight(1f))
                LiveStat(paceNow, "Pace /km", Modifier.weight(1f))
                LiveStat(steps, "Langkah", Modifier.weight(1f))
            }
            Spacer(Modifier.height(18.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlineButton(if (paused) "Lanjutkan" else "Jeda", Modifier.weight(1f), height = 54.dp) { if (paused) RunTracker.resume() else RunTracker.pause(); clock++ }
                PrimaryButton("Selesai", Modifier.weight(1f), height = 54.dp) { confirm = true }
            }
        }
    }

    if (confirm) ConfirmDialog("Selesaikan jogging?", "Rekaman akan disimpan ke riwayatmu.", "Selesai", {
        confirm = false
        val rec = RunTracker.buildRecord(ctx)
        RunService.send(ctx, RunService.ACTION_STOP)
        RunTracker.reset()
        ctx.getSharedPreferences("rill_data", Context.MODE_PRIVATE).edit().remove("run_active_start").apply()
        if (rec.distM < 50.0) {
            RunTracker.activeFile(ctx).delete()
            Toast.makeText(ctx, "Jaraknya terlalu pendek, rekaman dibuang.", Toast.LENGTH_LONG).show()
            nav.back()
        } else {
            RunStore.attachTrack(ctx, rec.id)
            RunStore.add(ctx, rec)
            // tick today's matching habit ("jogging" / "lari") automatically
            val snap = TodayData.snapshot(ctx)
            val hits = snap.tasks.filter { !snap.done.contains(it.id) && (it.name.lowercase(Locale.ROOT).contains("jog") || it.name.lowercase(Locale.ROOT).contains("lari")) }
            hits.forEach { TodayData.setDone(ctx, it.id, true) }
            if (hits.isNotEmpty()) Toast.makeText(ctx, "Kegiatan \"${hits[0].name}\" dicentang otomatis ✅", Toast.LENGTH_LONG).show()
            nav.replace(RillRoutes.jogSum(rec.id), RillRoutes.JOG_LIVE)
        }
    }, { confirm = false })
}

@Composable
private fun LiveStat(value: String, label: String, modifier: Modifier) {
    val c = IOS.colors
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, style = IOSType.number.copy(fontSize = 38.sp), color = c.textPrimary, maxLines = 1)
        Text(label, style = IOSType.body, color = c.textSecondary, maxLines = 1)
    }
}

@Composable
private fun BigTile(label: String, value: String, modifier: Modifier) {
    val c = IOS.colors
    IOSCard(modifier) {
        Text(value, style = IOSType.title.copy(fontSize = 28.sp), color = c.textPrimary, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
        Text(label, style = IOSType.caption, color = c.textSecondary, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
    }
}

// ============================ SUMMARY ============================
@Composable
fun JoggingSummaryScreen(nav: RillNav, id: Long) {
    val ctx = LocalContext.current
    val c = IOS.colors
    val r: RunRecord? = remember(id) { RunStore.load(ctx).find { it.id == id } }
    var confirmDelete by remember { mutableStateOf(false) }
    val gpxLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/gpx+xml")) { uri ->
        if (uri != null && r != null) {
            try {
                ctx.contentResolver.openOutputStream(uri)?.use { it.write(RunStore.gpx(ctx, r).toByteArray(Charsets.UTF_8)) }
                Toast.makeText(ctx, "GPX tersimpan ✅", Toast.LENGTH_LONG).show()
            } catch (_: Exception) { Toast.makeText(ctx, "Gagal menyimpan GPX.", Toast.LENGTH_LONG).show() }
        }
    }
    if (r == null) {
        ScreenScaffold("Rekaman tidak ditemukan", { nav.back() }) { item { EmptyState("👟", "Rekaman sudah dihapus", "Kembali ke riwayat jogging.") } }
        return
    }
    val pts = remember(id) { RunStore.parseRoute(r.route) }
    val bestKm = r.splits.filter { it > 0 }.minOrNull()
    val partialPace = if (r.partialM >= 100 && r.partialSec > 0) (r.partialSec * 1000.0 / r.partialM).roundToInt() else null
    val fastest = (r.splits + listOfNotNull(partialPace)).filter { it > 0 }.minOrNull() ?: 1

    ScreenScaffold(title = "Jogging", onBack = { nav.back() }, subtitle = dateText(r.start)) {
        item { RillMap(route = pts, fit = true, modifier = Modifier.fillMaxWidth().height(260.dp).clip(RoundedCornerShape(20.dp))) }
        item {
            IOSCard {
                Text("${Fmt.km(r.distM)} km", style = IOSType.number.copy(fontSize = 40.sp), color = c.primaryText, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                Text("${Fmt.dur(r.durMs)} total · pace ${Fmt.pace(r.avgPaceSec)}/km", style = IOSType.body, color = c.textSecondary, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                BigTile("⏱️ waktu bergerak", Fmt.dur(r.movMs), Modifier.weight(1f))
                BigTile("⚡ ${if (bestKm != null) "pace km tercepat" else "pace rata-rata"}", Fmt.pace(bestKm ?: r.avgPaceSec), Modifier.weight(1f))
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                BigTile(if (r.stepsEst) "👟 langkah (perkiraan)" else "👟 langkah", "${if (r.stepsEst) "≈" else ""}${r.steps}", Modifier.weight(1f))
                BigTile("🥁 langkah/menit", if (r.cadence > 0) "${r.cadence}" else "--", Modifier.weight(1f))
            }
        }
        item { SectionTitle("Pace tiap kilometer") }
        if (r.splits.isEmpty() && r.partialM < 100) item { Text("Belum ada satu kilometer penuh.", style = IOSType.body, color = c.textSecondary, modifier = Modifier.padding(horizontal = 4.dp)) }
        else item {
            IOSCard {
                @Composable
                fun row(label: String, sec: Int) {
                    val pct = if (sec <= 0) 0f else (fastest.toFloat() / sec).coerceIn(0.08f, 1f)
                    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(label, style = IOSType.caption, color = c.textPrimary, modifier = Modifier.size(width = 58.dp, height = 18.dp))
                        Box(Modifier.weight(1f).padding(horizontal = 8.dp)) { ThinBar(pct, if (sec == fastest) c.primary else c.orange) }
                        Text(Fmt.pace(sec), style = IOSType.caption, color = c.textPrimary, textAlign = TextAlign.End, modifier = Modifier.size(width = 44.dp, height = 18.dp))
                    }
                }
                r.splits.forEachIndexed { i, s -> row("Km ${i + 1}", s) }
                if (partialPace != null) row(String.format(Locale.US, "%.2f km", r.partialM / 1000.0), partialPace)
                Text("Hijau = km tercepat · Pace dihitung dari waktu bergerak.", style = IOSType.caption, color = c.textSecondary, modifier = Modifier.padding(top = 6.dp))
            }
        }
        if (pts.isNotEmpty()) item {
            OutlineButton("Buka lokasi di aplikasi Peta") {
                try { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("geo:${pts[0][0]},${pts[0][1]}?z=16"))) } catch (_: Exception) { Toast.makeText(ctx, "Tidak ada aplikasi peta.", Toast.LENGTH_LONG).show() }
            }
        }
        item {
            OutlineButton("Ekspor GPX (untuk Strava dll.)") {
                try { gpxLauncher.launch("jogging-${SimpleDateFormat("yyyy-MM-dd-HHmm", Locale.US).format(Date(r.start))}.gpx") } catch (_: Exception) { Toast.makeText(ctx, "Tidak ada aplikasi file.", Toast.LENGTH_LONG).show() }
            }
        }
        item { OutlineButton("Hapus rekaman") { confirmDelete = true } }
    }
    if (confirmDelete) ConfirmDialog("Hapus rekaman ini?", "Rekaman jogging ini akan dihapus permanen.", "Hapus", { RunStore.delete(ctx, r.id); confirmDelete = false; nav.back() }, { confirmDelete = false })
}
