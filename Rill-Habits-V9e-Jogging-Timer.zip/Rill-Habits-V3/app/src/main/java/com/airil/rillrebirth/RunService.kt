package com.airil.rillrebirth

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.Vibrator

/** Records a run in the foreground so GPS keeps working with the screen off. Data goes to [RunTracker]. */
class RunService : Service() {
    companion object {
        const val ACTION_START = "rill.run.start"
        const val ACTION_TOGGLE = "rill.run.toggle"
        const val ACTION_STOP = "rill.run.stop"
        private const val CHANNEL = "rill_run"
        private const val NOTIF_ID = 4501

        fun send(c: Context, action: String) {
            val i = Intent(c, RunService::class.java).setAction(action)
            try { if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i) else c.startService(i) } catch (_: Exception) { }
        }
    }

    private val handler = Handler(Looper.getMainLooper())
    private var lm: LocationManager? = null
    private var sm: SensorManager? = null
    private var wake: PowerManager.WakeLock? = null
    private var running = false

    private val locListener = object : LocationListener {
        override fun onLocationChanged(location: Location) { RunTracker.onLocation(location) }
        @Deprecated("Required on API < 30")
        override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
        override fun onProviderEnabled(provider: String) {}
        override fun onProviderDisabled(provider: String) {}
    }

    private val stepListener = object : SensorEventListener {
        override fun onSensorChanged(event: SensorEvent) {
            val v = event.values[0]
            if (RunTracker.steps0 < 0f) RunTracker.steps0 = v
            RunTracker.stepsNow = v
        }
        override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
    }

    private val ticker = object : Runnable {
        override fun run() {
            if (!running) return
            try { (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(NOTIF_ID, notification()) } catch (_: Exception) { }
            handler.postDelayed(this, 4000)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun notification(): Notification {
        if (Build.VERSION.SDK_INT >= 26) {
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(NotificationChannel(CHANNEL, "Rekaman jogging", NotificationManager.IMPORTANCE_LOW))
        }
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0
        val open = PendingIntent.getActivity(this, 0, Intent(this, ComposeActivity::class.java).putExtra("open", "jogging").addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP), flags)
        val toggle = PendingIntent.getService(this, 2, Intent(this, RunService::class.java).setAction(ACTION_TOGGLE), flags)
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL) else Notification.Builder(this)
        val text = "${Fmt.km(RunTracker.distM)} km · ${Fmt.dur(RunTracker.elapsedMs())}${if (RunTracker.paused) " · dijeda" else ""}"
        return b.setContentTitle("Jogging sedang direkam").setContentText(text).setSmallIcon(R.drawable.ic_workout)
            .setContentIntent(open).setOngoing(true).addAction(0, if (RunTracker.paused) "Lanjut" else "Jeda", toggle).build()
    }

    private fun goForeground() {
        val n = notification()
        try {
            if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION) else startForeground(NOTIF_ID, n)
        } catch (_: Exception) {
            try { startForeground(NOTIF_ID, n) } catch (_: Exception) { }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        goForeground()
        when (intent?.action) {
            ACTION_START -> startTracking()
            ACTION_TOGGLE -> { if (RunTracker.paused) RunTracker.resume() else RunTracker.pause() }
            else -> { stopTracking(); return START_NOT_STICKY }
        }
        if (!RunTracker.active) { stopTracking() }
        return START_NOT_STICKY
    }

    private fun startTracking() {
        if (running) return
        running = true
        RunTracker.onKm = { km -> kmSignal(km) }
        try {
            lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
            lm?.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, locListener, Looper.getMainLooper())
        } catch (_: SecurityException) { } catch (_: Exception) { }
        try {
            sm = getSystemService(Context.SENSOR_SERVICE) as SensorManager
            val s = sm?.getDefaultSensor(Sensor.TYPE_STEP_COUNTER)
            if (s != null) sm?.registerListener(stepListener, s, SensorManager.SENSOR_DELAY_UI)
        } catch (_: Exception) { }
        try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "RilHabit:run").apply { acquire(4 * 60 * 60 * 1000L) }
        } catch (_: Exception) { }
        handler.postDelayed(ticker, 4000)
    }

    private fun kmSignal(km: Int) {
        if (!getSharedPreferences("rill_data", Context.MODE_PRIVATE).getBoolean("run_beep", true)) return
        try { (getSystemService(Context.VIBRATOR_SERVICE) as Vibrator).vibrate(longArrayOf(0, 180, 120, 180), -1) } catch (_: Exception) { }
        try { ToneGenerator(AudioManager.STREAM_MUSIC, 90).startTone(ToneGenerator.TONE_PROP_BEEP2, 350) } catch (_: Exception) { }
    }

    private fun stopTracking() {
        running = false
        handler.removeCallbacks(ticker)
        try { lm?.removeUpdates(locListener) } catch (_: Exception) { }
        try { sm?.unregisterListener(stepListener) } catch (_: Exception) { }
        try { if (wake?.isHeld == true) wake?.release() } catch (_: Exception) { }
        RunTracker.onKm = null
        stopForeground(true)
        stopSelf()
    }

    override fun onDestroy() {
        running = false
        handler.removeCallbacks(ticker)
        try { lm?.removeUpdates(locListener) } catch (_: Exception) { }
        try { sm?.unregisterListener(stepListener) } catch (_: Exception) { }
        try { if (wake?.isHeld == true) wake?.release() } catch (_: Exception) { }
        super.onDestroy()
    }
}
