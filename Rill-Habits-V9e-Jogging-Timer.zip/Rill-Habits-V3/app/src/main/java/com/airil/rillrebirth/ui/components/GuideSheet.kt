package com.airil.rillrebirth.ui.components

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.airil.rillrebirth.Guide
import com.airil.rillrebirth.ui.theme.IOS
import com.airil.rillrebirth.ui.theme.IOSType

/** How-to sheet for an exercise (muscles, steps, tip) with a link to search for a video. */
@Composable
fun GuideSheet(name: String, onDismiss: () -> Unit) {
    val c = IOS.colors
    val ctx = LocalContext.current
    val info = Guide.find(name)
    IOSSheet(onDismiss) {
        Text(name, style = IOSType.title, color = c.textPrimary)
        if (info != null) {
            FieldLabel("OTOT YANG BEKERJA")
            Text(info.muscle, style = IOSType.body, color = c.textPrimary)
            FieldLabel("LANGKAH")
            info.steps.forEachIndexed { i, s -> Text("${i + 1}. $s", style = IOSType.body, color = c.textPrimary, modifier = Modifier.padding(bottom = 4.dp)) }
            FieldLabel("TIPS")
            Text(info.tip, style = IOSType.body, color = c.textPrimary)
        } else {
            Text("Belum ada panduan tertulis untuk gerakan ini. Kamu bisa mencari video contoh supaya gerakannya benar.", style = IOSType.body, color = c.textSecondary, modifier = Modifier.padding(top = 8.dp))
        }
        Spacer(Modifier.height(16.dp))
        OutlineButton("Cari video contoh") {
            try {
                ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode("cara $name"))))
            } catch (_: Exception) { Toast.makeText(ctx, "Tidak ada aplikasi untuk membuka video.", Toast.LENGTH_SHORT).show() }
        }
        Spacer(Modifier.height(8.dp))
        PrimaryButton("Mengerti", onClick = onDismiss)
    }
}
