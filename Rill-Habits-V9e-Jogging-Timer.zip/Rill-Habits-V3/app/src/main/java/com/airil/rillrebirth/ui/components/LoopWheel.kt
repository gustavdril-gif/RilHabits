package com.airil.rillrebirth.ui.components

import androidx.compose.foundation.gestures.snapping.rememberSnapFlingBehavior
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.airil.rillrebirth.ui.theme.IOS
import com.airil.rillrebirth.ui.theme.IOSType
import kotlin.math.abs

/**
 * iOS-style looping number wheel (0..count-1, wraps around). The centre number is big and dark,
 * the rows above and below shrink and fade. Ticks + haptics on every step.
 */
@Composable
fun LoopWheel(count: Int, value: Int, modifier: Modifier = Modifier, itemH: Dp = 64.dp, onValueChange: (Int) -> Unit) {
    val c = IOS.colors
    val density = LocalDensity.current
    val itemPx = with(density) { itemH.toPx() }
    val total = count * 400
    val base = (total / 2) - ((total / 2) % count)
    val state = rememberLazyListState(initialFirstVisibleItemIndex = base + value.coerceIn(0, count - 1))
    val snap = rememberSnapFlingBehavior(state)
    val selectedIndex by remember {
        derivedStateOf { state.firstVisibleItemIndex + (if (state.firstVisibleItemScrollOffset > itemPx / 2) 1 else 0) }
    }
    val tick = remember { TickSound() }
    val haptic = LocalHapticFeedback.current
    DisposableEffect(Unit) { onDispose { tick.release() } }
    var first by remember { mutableStateOf(true) }
    LaunchedEffect(selectedIndex) {
        if (first) first = false else { tick.tick(); haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove) }
        onValueChange(selectedIndex % count)
    }
    LazyColumn(
        state = state, flingBehavior = snap,
        modifier = modifier.height(itemH * 5),
        contentPadding = PaddingValues(vertical = itemH * 2)
    ) {
        items(total) { i ->
            Box(
                Modifier.fillMaxWidth().height(itemH).graphicsLayer {
                    // distance (in rows) from the centre row, read at draw time so scrolling stays smooth
                    val d = abs((i - state.firstVisibleItemIndex) - state.firstVisibleItemScrollOffset / itemPx)
                    val s = when { d <= 1f -> 1f - 0.62f * d; d <= 2f -> 0.38f - 0.08f * (d - 1f); else -> 0.3f }
                    val a = when { d <= 1f -> 1f - 0.45f * d; d <= 2f -> 0.55f - 0.2f * (d - 1f); else -> 0.35f }
                    scaleX = s; scaleY = s; alpha = a
                },
                contentAlignment = Alignment.Center
            ) {
                Text(
                    (i % count).toString(),
                    style = IOSType.number.copy(fontSize = 76.sp, fontWeight = FontWeight.Medium),
                    color = c.textPrimary, maxLines = 1, softWrap = false, textAlign = TextAlign.Center
                )
            }
        }
    }
}
