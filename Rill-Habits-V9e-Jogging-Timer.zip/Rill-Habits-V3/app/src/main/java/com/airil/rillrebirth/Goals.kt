package com.airil.rillrebirth

import android.app.AlertDialog
import android.content.Context
import android.graphics.Color
import android.text.InputType
import android.view.Gravity
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

/** kind: "keyword" (count finished tasks whose name/category contains keyword), "workout", or "perfect" (days at 100%). period: "week" | "month". */
data class Goal(val id: Long, var title: String, var kind: String, var keyword: String, var target: Int, var period: String)
data class Badge(val goalId: Long, val title: String, val periodStart: String, val period: String, val ts: Long)

object GoalStore {
    private const val GOALS = "goals_json"
    private const val BADGES = "badges_json"
    private val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)

    private fun prefs(c: Context) = c.getSharedPreferences("rill_data", Context.MODE_PRIVATE)

    fun load(c: Context): MutableList<Goal> {
        val arr = try { JSONArray(prefs(c).getString(GOALS, "[]") ?: "[]") } catch (_: Exception) { JSONArray() }
        val out = mutableListOf<Goal>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            out.add(Goal(o.optLong("id"), o.optString("title"), o.optString("kind", "keyword"), o.optString("keyword"), o.optInt("target", 1).coerceAtLeast(1), o.optString("period", "month")))
        }
        return out
    }

    fun save(c: Context, list: List<Goal>) {
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("id", it.id).put("title", it.title).put("kind", it.kind).put("keyword", it.keyword).put("target", it.target).put("period", it.period)) }
        prefs(c).edit().putString(GOALS, arr.toString()).apply()
    }

    fun loadBadges(c: Context): MutableList<Badge> {
        val arr = try { JSONArray(prefs(c).getString(BADGES, "[]") ?: "[]") } catch (_: Exception) { JSONArray() }
        val out = mutableListOf<Badge>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            out.add(Badge(o.optLong("goalId"), o.optString("title"), o.optString("start"), o.optString("period", "month"), o.optLong("ts")))
        }
        return out
    }

    private fun saveBadges(c: Context, list: List<Badge>) {
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("goalId", it.goalId).put("title", it.title).put("start", it.periodStart).put("period", it.period).put("ts", it.ts)) }
        prefs(c).edit().putString(BADGES, arr.toString()).apply()
    }

    /** First day of the current week (Monday) or month. */
    fun periodStart(period: String): Calendar {
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0); cal.set(Calendar.SECOND, 0); cal.set(Calendar.MILLISECOND, 0)
        if (period == "week") {
            val back = (cal.get(Calendar.DAY_OF_WEEK) + 5) % 7   // Monday -> 0
            cal.add(Calendar.DAY_OF_YEAR, -back)
        } else cal.set(Calendar.DAY_OF_MONTH, 1)
        return cal
    }

    fun periodKey(period: String): String = fmt.format(periodStart(period).time)

    fun periodLabel(period: String): String = if (period == "week") "minggu ini" else "bulan ini"

    fun progress(c: Context, g: Goal, tasks: List<RillTask>, stats: List<DayStat>): Int {
        val start = periodStart(g.period)
        val startKey = fmt.format(start.time)
        val todayKey = fmt.format(Calendar.getInstance().time)
        val dates = ArrayList<String>()
        val cal = start.clone() as Calendar
        while (fmt.format(cal.time) <= todayKey && dates.size < 40) { dates.add(fmt.format(cal.time)); cal.add(Calendar.DAY_OF_YEAR, 1) }
        return when (g.kind) {
            "workout" -> {
                val root = WorkoutStore.workoutDoneRoot(c)
                var n = 0
                dates.forEach { d ->
                    val o = root.optJSONObject(d) ?: return@forEach
                    val keys = o.keys()
                    while (keys.hasNext()) if (o.optBoolean(keys.next(), false)) n++
                }
                n
            }
            "runkm" -> {
                val startMs = start.timeInMillis
                (RunStore.load(c).filter { it.start >= startMs }.sumOf { it.distM } / 1000.0).toInt()
            }
            "perfect" -> stats.count { it.date >= startKey && it.date <= todayKey && it.total > 0 && it.rate >= 0.999f }
            else -> {
                val kw = g.keyword.trim().lowercase(Locale.ROOT)
                if (kw.isEmpty()) 0 else {
                    val root = TaskStore.allDone(c)
                    val byId = tasks.associateBy { it.id }
                    var n = 0
                    dates.forEach { d ->
                        val arr = root.optJSONArray(d) ?: return@forEach
                        for (i in 0 until arr.length()) {
                            val t = byId[arr.optInt(i)] ?: continue
                            if (t.name.lowercase(Locale.ROOT).contains(kw) || t.category.lowercase(Locale.ROOT).contains(kw)) n++
                        }
                    }
                    n
                }
            }
        }
    }

    /** Awards a badge once per goal per period when the target is reached. Returns the new badges. */
    fun checkAwards(c: Context, tasks: List<RillTask>, stats: List<DayStat>): List<Badge> {
        val goals = load(c)
        if (goals.isEmpty()) return emptyList()
        val badges = loadBadges(c)
        val fresh = mutableListOf<Badge>()
        goals.forEach { g ->
            val key = periodKey(g.period)
            if (badges.any { it.goalId == g.id && it.periodStart == key }) return@forEach
            if (progress(c, g, tasks, stats) >= g.target) {
                val b = Badge(g.id, g.title, key, g.period, System.currentTimeMillis())
                badges.add(b); fresh.add(b)
            }
        }
        if (fresh.isNotEmpty()) saveBadges(c, badges)
        return fresh
    }
}
