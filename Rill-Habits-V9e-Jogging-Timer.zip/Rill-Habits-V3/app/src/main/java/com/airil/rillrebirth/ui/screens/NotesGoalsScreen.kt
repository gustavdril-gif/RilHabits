package com.airil.rillrebirth.ui.screens

import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.airil.rillrebirth.Goal
import com.airil.rillrebirth.GoalStore
import com.airil.rillrebirth.NoteItem
import com.airil.rillrebirth.NoteStore
import com.airil.rillrebirth.SecretActivity
import com.airil.rillrebirth.SecretStore
import com.airil.rillrebirth.Smart
import com.airil.rillrebirth.TaskStore
import com.airil.rillrebirth.noteDiffDays
import com.airil.rillrebirth.noteExpiry
import com.airil.rillrebirth.ui.components.ChipRow
import com.airil.rillrebirth.ui.components.ChoiceChip
import com.airil.rillrebirth.ui.components.CircleCheck
import com.airil.rillrebirth.ui.components.ConfirmDialog
import com.airil.rillrebirth.ui.components.EmptyState
import com.airil.rillrebirth.ui.components.FieldLabel
import com.airil.rillrebirth.ui.components.IOSCard
import com.airil.rillrebirth.ui.components.IOSField
import com.airil.rillrebirth.ui.components.IOSSheet
import com.airil.rillrebirth.ui.components.OutlineButton
import com.airil.rillrebirth.ui.components.PrimaryButton
import com.airil.rillrebirth.ui.components.RillNav
import com.airil.rillrebirth.ui.components.ScreenScaffold
import com.airil.rillrebirth.ui.components.SectionTitle
import com.airil.rillrebirth.ui.components.SegmentedControl
import com.airil.rillrebirth.ui.components.ThinBar
import com.airil.rillrebirth.ui.components.iosPress
import com.airil.rillrebirth.ui.theme.IOS
import com.airil.rillrebirth.ui.theme.IOSType
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private fun kindLabel(kind: String) = when (kind) { "workout" -> "sesi workout selesai"; "perfect" -> "hari sempurna"; "runkm" -> "km lari"; else -> "kali selesai" }

@Composable
fun NotesGoalsScreen(nav: RillNav) {
    val ctx = LocalContext.current
    val c = IOS.colors
    var seg by rememberSaveable { mutableIntStateOf(0) }
    var tick by remember { mutableIntStateOf(0) }
    var noteEdit by remember { mutableStateOf<NoteItem?>(null) }
    var noteNew by remember { mutableStateOf(false) }
    var goalEdit by remember { mutableStateOf<Goal?>(null) }
    var goalNew by remember { mutableStateOf(false) }

    val notes = remember(tick) { NoteStore.sorted(NoteStore.load(ctx)) }
    val goals = remember(tick) { GoalStore.load(ctx) }
    val tasks = remember(tick) { TaskStore.load(ctx) }
    val stats = remember(tick) { Smart.dayStats(ctx, tasks, 365) }
    val badges = remember(tick) { GoalStore.loadBadges(ctx).sortedByDescending { it.ts } }

    ScreenScaffold(title = "Catatan & Target", onBack = { nav.back() }) {
        item { SegmentedControl(listOf("Catatan", "Target"), seg) { seg = it } }
        if (seg == 0) {
            item { Text("Catatan hilang otomatis setelah masa berlakunya habis.", style = IOSType.caption, color = c.textSecondary, modifier = Modifier.padding(horizontal = 4.dp)) }
            if (notes.isEmpty()) item { EmptyState("📝", "Belum ada catatan", "Tulis hal yang harus dikerjakan atau diingat, lalu atur berapa lama bertahan.") }
            else item {
                IOSCard {
                    notes.forEachIndexed { i, n ->
                        val (label, urgent) = noteExpiry(n)
                        Row(Modifier.fillMaxWidth().iosPress(Role.Button) { noteEdit = n }.padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                            CircleCheck(n.done, (if (n.done) "Batalkan " else "Selesaikan ") + "catatan") { v ->
                                val all = NoteStore.load(ctx); all.find { it.id == n.id }?.done = v; NoteStore.save(ctx, all); tick++
                            }
                            Column(Modifier.weight(1f).padding(start = 4.dp)) {
                                Text(n.text, style = IOSType.body, color = if (n.done) c.textSecondary else c.textPrimary, maxLines = 3, overflow = TextOverflow.Ellipsis)
                                Text(if (n.done) "Selesai · $label" else label, style = IOSType.caption, color = if (urgent && !n.done) c.red else c.textSecondary)
                            }
                        }
                    }
                }
            }
            item { PrimaryButton("+ Tambah catatan") { noteNew = true } }
        } else {
            item { Text("Progres dihitung otomatis dari kegiatan dan workout yang kamu selesaikan. Target mingguan dan bulanan mulai dari nol di periode baru.", style = IOSType.caption, color = c.textSecondary, modifier = Modifier.padding(horizontal = 4.dp)) }
            if (goals.isEmpty()) item { EmptyState("🎯", "Belum ada target", "Contoh: jogging 20 kali bulan ini, atau 50 km lari bulan ini.") }
            goals.forEach { g ->
                item(key = "g${g.id}") {
                    val p = GoalStore.progress(ctx, g, tasks, stats)
                    val done = p >= g.target
                    IOSCard(Modifier.iosPress(Role.Button) { goalEdit = g }) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(g.title, style = IOSType.headline, color = c.textPrimary, modifier = Modifier.weight(1f))
                            Text(if (done) "✅ Tercapai" else "$p/${g.target}", style = IOSType.caption, color = if (done) c.primaryText else c.textSecondary)
                        }
                        Box(Modifier.padding(top = 8.dp, bottom = 6.dp)) { ThinBar((p.toFloat() / g.target).coerceAtMost(1f), if (done) c.primary else c.orange) }
                        Text("${GoalStore.periodLabel(g.period)} · ${kindLabel(g.kind)}", style = IOSType.caption, color = c.textSecondary)
                    }
                }
            }
            item { PrimaryButton("+ Buat target") { goalNew = true } }
            item { SectionTitle("Lencana 🏅 (${badges.size})") }
            if (badges.isEmpty()) item { Text("Capai targetmu untuk mendapat lencana pertama.", style = IOSType.body, color = c.textSecondary, modifier = Modifier.padding(horizontal = 4.dp)) }
            else item {
                IOSCard {
                    val df = SimpleDateFormat("d MMM yyyy", Locale("id", "ID"))
                    badges.forEach { b ->
                        Text("🏅 ${b.title}", style = IOSType.headline, color = c.textPrimary, modifier = Modifier.padding(top = 6.dp))
                        Text("${if (b.period == "week") "Mingguan" else "Bulanan"} · ${df.format(Date(b.ts))}", style = IOSType.caption, color = c.textSecondary)
                    }
                }
            }
        }
    }

    if (noteNew || noteEdit != null) NoteEditor(noteEdit, { noteNew = false; noteEdit = null; tick++ })
    if (goalNew || goalEdit != null) GoalEditor(goalEdit, { goalNew = false; goalEdit = null; tick++ })
}

@Composable
private fun NoteEditor(existing: NoteItem?, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val c = IOS.colors
    val prefill = if (existing == null) "3" else if (existing.expires == 0L) "" else (noteDiffDays(existing) + 1).coerceAtLeast(1).toString()
    var text by remember { mutableStateOf(existing?.text ?: "") }
    var days by remember { mutableStateOf(prefill) }
    var confirmDelete by remember { mutableStateOf(false) }
    IOSSheet(onClose) {
        Text(if (existing == null) "Catatan baru" else "Edit catatan", style = IOSType.title, color = c.textPrimary)
        Spacer(Modifier.height(10.dp))
        IOSField(text, { text = it }, "Apa yang harus dikerjakan atau diingat?", minLines = 3)
        FieldLabel("LAMA BERTAHAN")
        ChipRow {
            listOf("Hari ini" to "1", "3 hari" to "3", "1 minggu" to "7", "1 bulan" to "30", "Selamanya" to "").forEach { (l, v) -> ChoiceChip(l, days == v) { days = v } }
        }
        Spacer(Modifier.height(8.dp))
        IOSField(days, { days = it.filter { ch -> ch.isDigit() }.take(4) }, "Berapa hari? (kosong = tanpa batas)", singleLine = true, numeric = true)
        Spacer(Modifier.height(16.dp))
        PrimaryButton("Simpan") {
            val t = text.trim()
            if (t.isEmpty()) { Toast.makeText(ctx, "Tulis dulu isi catatannya.", Toast.LENGTH_SHORT).show(); return@PrimaryButton }
            if (SecretStore.matches(ctx, t)) { ctx.startActivity(Intent(ctx, SecretActivity::class.java)); onClose(); return@PrimaryButton }
            val n = days.toIntOrNull()
            val expires = if (n == null || n <= 0) 0L else NoteStore.endOfDay(n.coerceAtMost(3650) - 1)
            val all = NoteStore.load(ctx)
            if (existing == null) all.add(NoteItem(System.currentTimeMillis(), t, expires, false))
            else all.find { it.id == existing.id }?.let { it.text = t; if (days != prefill) it.expires = expires }
            NoteStore.save(ctx, all)
            onClose()
        }
        if (existing != null) { Spacer(Modifier.height(8.dp)); OutlineButton("Hapus catatan") { confirmDelete = true } }
    }
    if (confirmDelete && existing != null) ConfirmDialog("Hapus catatan?", "Catatan ini akan dihapus.", "Hapus", {
        NoteStore.save(ctx, NoteStore.load(ctx).filter { it.id != existing.id }); confirmDelete = false; onClose()
    }, { confirmDelete = false })
}

@Composable
private fun GoalEditor(existing: Goal?, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val c = IOS.colors
    var title by remember { mutableStateOf(existing?.title ?: "") }
    var kind by remember { mutableStateOf(existing?.kind ?: "keyword") }
    var keyword by remember { mutableStateOf(existing?.keyword ?: "") }
    var target by remember { mutableStateOf((existing?.target ?: 20).toString()) }
    var period by remember { mutableStateOf(existing?.period ?: "month") }
    var confirmDelete by remember { mutableStateOf(false) }
    IOSSheet(onClose) {
        Text(if (existing == null) "Target baru" else "Edit target", style = IOSType.title, color = c.textPrimary)
        FieldLabel("NAMA TARGET")
        IOSField(title, { title = it }, "mis. Jogging 20×", singleLine = true)
        FieldLabel("YANG DIHITUNG")
        ChipRow {
            listOf("keyword" to "Kegiatan", "workout" to "Workout", "perfect" to "Hari sempurna", "runkm" to "Jarak lari (km)").forEach { (k, l) -> ChoiceChip(l, kind == k) { kind = k } }
        }
        if (kind == "keyword") {
            Spacer(Modifier.height(8.dp))
            IOSField(keyword, { keyword = it }, "Kata kunci nama atau kategori (mis. jogging)", singleLine = true)
        }
        FieldLabel(if (kind == "runkm") "TARGET (KM)" else "JUMLAH TARGET")
        IOSField(target, { target = it.filter { ch -> ch.isDigit() }.take(3) }, "20", singleLine = true, numeric = true)
        FieldLabel("PERIODE")
        ChipRow { listOf("week" to "Minggu ini", "month" to "Bulan ini").forEach { (k, l) -> ChoiceChip(l, period == k) { period = k } } }
        Spacer(Modifier.height(16.dp))
        PrimaryButton("Simpan") {
            val tg = target.toIntOrNull() ?: 0
            val kw = keyword.trim()
            if (tg <= 0 || (kind == "keyword" && kw.isEmpty())) { Toast.makeText(ctx, "Isi jumlah target${if (kind == "keyword") " dan kata kuncinya" else ""}.", Toast.LENGTH_LONG).show(); return@PrimaryButton }
            val name = title.trim().ifBlank { when (kind) { "workout" -> "Workout $tg×"; "perfect" -> "$tg hari sempurna"; "runkm" -> "Lari $tg km"; else -> "${kw.replaceFirstChar { it.uppercase() }} $tg×" } }
            val list = GoalStore.load(ctx)
            if (existing == null) list.add(Goal(System.currentTimeMillis(), name, kind, kw, tg.coerceAtMost(999), period))
            else list.find { it.id == existing.id }?.let { it.title = name; it.kind = kind; it.keyword = kw; it.target = tg.coerceAtMost(999); it.period = period }
            GoalStore.save(ctx, list)
            onClose()
        }
        if (existing != null) { Spacer(Modifier.height(8.dp)); OutlineButton("Hapus target") { confirmDelete = true } }
    }
    if (confirmDelete && existing != null) ConfirmDialog("Hapus target?", "\"${existing.title}\" akan dihapus.", "Hapus", {
        GoalStore.save(ctx, GoalStore.load(ctx).filter { it.id != existing.id }); confirmDelete = false; onClose()
    }, { confirmDelete = false })
}
