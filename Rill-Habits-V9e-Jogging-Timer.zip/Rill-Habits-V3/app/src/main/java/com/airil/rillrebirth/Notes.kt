package com.airil.rillrebirth

import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Paint
import android.text.InputType
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.widget.CheckBox
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

/** A short note ("Catatan") that expires on its own. expires == 0 means it never expires. */
data class NoteItem(val id: Long, var text: String, var expires: Long, var done: Boolean)

object NoteStore {
    private const val KEY = "notes_json"
    private const val MIGRATED = "notes_migrated_v1"

    private fun prefs(c: Context) = c.getSharedPreferences("rill_data", Context.MODE_PRIVATE)

    /** Last millisecond of the day that is [daysFromToday] days from now (0 = today). */
    fun endOfDay(daysFromToday: Int): Long {
        val cal = Calendar.getInstance()
        cal.add(Calendar.DAY_OF_YEAR, daysFromToday)
        cal.set(Calendar.HOUR_OF_DAY, 23); cal.set(Calendar.MINUTE, 59); cal.set(Calendar.SECOND, 59); cal.set(Calendar.MILLISECOND, 999)
        return cal.timeInMillis
    }

    fun load(c: Context): MutableList<NoteItem> {
        val p = prefs(c)
        if (!p.getBoolean(MIGRATED, false)) migrateDailyNote(c)
        val arr = try { JSONArray(p.getString(KEY, "[]") ?: "[]") } catch (_: Exception) { JSONArray() }
        val now = System.currentTimeMillis()
        val list = mutableListOf<NoteItem>()
        var purged = false
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val exp = o.optLong("expires", 0L)
            if (exp > 0L && exp < now) { purged = true; continue }
            list.add(NoteItem(o.optLong("id"), o.optString("text"), exp, o.optBoolean("done", false)))
        }
        if (purged) save(c, list)
        return list
    }

    fun save(c: Context, list: List<NoteItem>) {
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("id", it.id).put("text", it.text).put("expires", it.expires).put("done", it.done)) }
        prefs(c).edit().putString(KEY, arr.toString()).apply()
    }

    fun sorted(list: List<NoteItem>): List<NoteItem> =
        list.sortedWith(compareBy<NoteItem>({ it.done }, { if (it.expires == 0L) Long.MAX_VALUE else it.expires }))

    /** One-time: today's old Daily Note becomes a note that lasts until the end of today. */
    private fun migrateDailyNote(c: Context) {
        val p = prefs(c)
        val old = (p.getString("daily_note_${TaskStore.today()}", "") ?: "").trim()
        if (old.isNotEmpty()) save(c, listOf(NoteItem(System.currentTimeMillis(), old, endOfDay(0), false)))
        p.edit().putBoolean(MIGRATED, true).apply()
    }
}

/** Whole days between today and the day the note ends (0 = ends today). */
internal fun noteDiffDays(n: NoteItem): Int {
    val a = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }
    val b = Calendar.getInstance().apply { timeInMillis = n.expires; set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }
    return Math.round((b.timeInMillis - a.timeInMillis) / 86400000.0).toInt()
}

/** Label + whether it is urgent (ends today). */
internal fun noteExpiry(n: NoteItem): Pair<String, Boolean> {
    if (n.expires == 0L) return Pair("Tanpa batas waktu", false)
    val diff = noteDiffDays(n)
    return when {
        diff <= 0 -> Pair("Berakhir hari ini", true)
        diff == 1 -> Pair("Berakhir besok", false)
        else -> Pair("Berakhir $diff hari lagi", false)
    }
}
