package com.airil.rillrebirth.ui.screens

import android.content.Context
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.annotation.DrawableRes
import com.airil.rillrebirth.R
import com.airil.rillrebirth.Smart
import com.airil.rillrebirth.TaskStore
import com.airil.rillrebirth.ui.components.EmptyState
import com.airil.rillrebirth.ui.components.IOSCard
import com.airil.rillrebirth.ui.components.IconBadge
import com.airil.rillrebirth.ui.components.IconLabel
import com.airil.rillrebirth.ui.components.MenuHeader
import com.airil.rillrebirth.ui.components.RillNav
import com.airil.rillrebirth.ui.components.SectionTitle
import com.airil.rillrebirth.ui.theme.IOS
import com.airil.rillrebirth.ui.theme.IOSType
import kotlin.math.roundToInt

private val monthShort = listOf("Jan", "Feb", "Mar", "Apr", "Mei", "Jun", "Jul", "Agu", "Sep", "Okt", "Nov", "Des")
private val dayHead = listOf("Sen", "Sel", "Rab", "Kam", "Jum", "Sab", "Min")

private data class StatsResult(
    val consistency: Int, val delta: Int, val mood: Float?, val workouts7: Int,
    val heat: List<Float?>,            // 84 cells, week rows x weekday columns (Mon..Sun), null = future
    val rowMonths: List<String>, val activeDays: Int,
    val weekly: List<Float>, val weekLabels: List<String>,
    val insights: List<String>, val hasData: Boolean
)

private fun avgRate(l: List<com.airil.rillrebirth.DayStat>): Float {
    val r = l.filter { it.total > 0 }.map { it.rate }
    return if (r.isEmpty()) 0f else r.sum() / r.size
}

private fun build(ctx: Context): StatsResult {
    val tasks = TaskStore.load(ctx)
    val stats = Smart.dayStats(ctx, tasks, 365)
    val last7 = stats.takeLast(7)
    val prev7 = stats.dropLast(7).takeLast(7)
    val c1 = avgRate(last7); val c0 = avgRate(prev7)
    val moods = Smart.moodSeries(ctx, 0).first.filterNotNull()
    // heatmap: 12 week rows ending with the current week (Monday first)
    val cal = java.util.Calendar.getInstance()
    val todayIdx = (cal.get(java.util.Calendar.DAY_OF_WEEK) + 5) % 7
    val cells = ArrayList<Float?>()
    val months = ArrayList<String>()
    var active = 0
    for (k in 0 until 84) {
        val daysAgo = (todayIdx + 77) - k
        if (daysAgo < 0) { cells.add(null); continue }
        val st = stats.getOrNull(stats.size - 1 - daysAgo)
        if (st == null) { cells.add(0f); continue }
        cells.add(if (st.total == 0) 0f else st.rate)
        if (st.done > 0) active++
    }
    var prevMonth = -1
    for (r in 0 until 12) {
        val daysAgo = (todayIdx + 77) - r * 7
        val st = stats.getOrNull(stats.size - 1 - daysAgo)
        val m = st?.date?.substring(5, 7)?.toIntOrNull() ?: -1
        months.add(if (m != -1 && m != prevMonth) monthShort[(m - 1).coerceIn(0, 11)] else "")
        if (m != -1) prevMonth = m
    }
    val chunks = stats.takeLast(56).chunked(7)
    val weekly = chunks.map { avgRate(it) }
    val labels = chunks.map { ch -> val d = ch.first().date; "${d.substring(8).toIntOrNull() ?: 0}/${d.substring(5, 7).toIntOrNull() ?: 0}" }
    return StatsResult(
        (c1 * 100).roundToInt(), ((c1 - c0) * 100).roundToInt(),
        if (moods.isEmpty()) null else moods.sum() / moods.size, last7.sumOf { it.workoutDone },
        cells, months, active, weekly, labels,
        Smart.insights(ctx, tasks, stats), stats.any { it.done > 0 }
    )
}

@Composable
fun StatistikScreen(refresh: Int, nav: RillNav) {
    val ctx = LocalContext.current
    val c = IOS.colors
    val r = remember(refresh) { build(ctx) }

    val moodSeries = remember(refresh) { Smart.moodSeries(ctx, 1) }
    val insights = remember(r) { topInsights(r.insights) }
    val head = IOSType.headline.copy(fontSize = 17.sp)
    val tiny = IOSType.caption.copy(fontSize = 9.sp)

    LazyColumn(contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 32.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { MenuHeader("Statistik", "Wawasan dari kebiasaanmu", compact = true) { nav.home() } }
        if (!r.hasData) {
            item { EmptyState(R.drawable.ic_stats, "Belum ada data", "Centang beberapa kegiatan dulu. Statistik dan wawasan akan muncul di sini.") }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TopCard(R.drawable.ic_check_circle, c.primary, "Konsistensi", "${r.consistency}%", if (r.delta >= 0) "Minggu ini naik ${r.delta}%" else "Minggu ini turun ${-r.delta}%", Modifier.weight(1f))
                TopCard(R.drawable.ic_smile, c.orange, "Mood", if (r.mood == null) "–" else String.format(java.util.Locale.US, "%.1f", r.mood), "skala 1–5 · 7 hari", Modifier.weight(1f))
                TopCard(R.drawable.ic_dumbbell, c.blue, "Workout", "${r.workouts7}x", "7 hari terakhir", Modifier.weight(1f))
            }
        }
        item { Text("Aktivitas 12 Minggu", style = head, color = c.textPrimary, modifier = Modifier.padding(start = 4.dp, top = 6.dp)) }
        item {
            IOSCard(padding = 12.dp, corner = 16.dp) {
                // columns = weeks (oldest to newest), rows = weekdays Mon..Sun
                Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                    Spacer(Modifier.width(22.dp))
                    for (week in 0 until 12) Box(Modifier.weight(1f)) { Text(r.rowMonths[week], style = tiny, color = c.textSecondary, maxLines = 1, softWrap = false, overflow = TextOverflow.Visible) }
                }
                Spacer(Modifier.height(4.dp))
                for (day in 0 until 7) {
                    Row(Modifier.padding(vertical = 1.5.dp), horizontalArrangement = Arrangement.spacedBy(3.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(if (day % 2 == 0) dayHead[day] else "", Modifier.width(22.dp), style = tiny, color = c.textSecondary, maxLines = 1, softWrap = false)
                        for (week in 0 until 12) {
                            val v = r.heat[week * 7 + day]
                            val color = when {
                                v == null -> Color.Transparent
                                v <= 0f -> c.track
                                v < 0.34f -> c.primary.copy(alpha = 0.35f)
                                v < 0.67f -> c.primary.copy(alpha = 0.6f)
                                v < 1f -> c.primary.copy(alpha = 0.85f)
                                else -> c.primary
                            }
                            Box(Modifier.weight(1f).height(14.dp).clip(RoundedCornerShape(3.dp)).background(color))
                        }
                    }
                }
                Text("Aktif ${r.activeDays} dari 84 hari", style = IOSType.caption.copy(fontSize = 11.sp), color = c.textSecondary, modifier = Modifier.padding(top = 6.dp))
            }
        }
        item { Text("Kurva Mood", style = head, color = c.textPrimary, modifier = Modifier.padding(start = 4.dp, top = 6.dp)) }
        item {
            IOSCard(padding = 12.dp, corner = 16.dp) {
                if (moodSeries.first.all { it == null }) {
                    Text("Belum ada mood tercatat. Catat mood dari Beranda setelah kegiatan selesai.", style = IOSType.caption.copy(fontSize = 12.sp), color = c.textSecondary)
                } else {
                    MoodCurve(moodSeries.first, moodSeries.second)
                    Text("30 hari terakhir · skala 1–5", style = IOSType.caption.copy(fontSize = 10.sp), color = c.textSecondary, modifier = Modifier.padding(top = 4.dp))
                }
            }
        }
        item { Text("Smart Insights", style = head, color = c.textPrimary, modifier = Modifier.padding(start = 4.dp, top = 6.dp)) }
        if (insights.isEmpty()) item { EmptyState(R.drawable.ic_bulb, "Belum ada wawasan", "Beberapa hari lagi, dan pola kebiasaanmu mulai terlihat.") }
        itemsIndexed(insights) { i, text ->
            val (lead, body) = splitLead(text)
            val icon = insightIcon(lead)
            val accent = when (icon) {
                R.drawable.ic_alert -> c.red
                R.drawable.ic_trend_down -> c.orange
                R.drawable.ic_trend_up, R.drawable.ic_mosque -> c.primary
                R.drawable.ic_bulb -> c.blue
                else -> if (i % 2 == 0) c.blue else c.orange
            }
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(accent.copy(alpha = if (c.dark) 0.22f else 0.14f)).padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconBadge(icon, accent, 30.dp)
                Text(body, style = IOSType.body.copy(fontSize = 13.sp), color = c.textPrimary, modifier = Modifier.padding(start = 10.dp))
            }
        }
    }
}

/** Keep only the 3 most important insights: problems first, then trends, then positives. */
private fun topInsights(all: List<String>): List<String> {
    val order = listOf("⚠", "🌧", "🪫", "🚀", "🕌", "💡", "📈")
    fun rank(t: String): Int { val i = order.indexOfFirst { t.contains(it) }; return if (i < 0) order.size else i }
    return all.filter { it.isNotBlank() && !it.startsWith("Catat kegiatanmu") }.sortedBy { rank(it) }.take(3)
}

/** Smooth mood line over the last days with a soft fill; days without a mood are bridged. */
@Composable
private fun MoodCurve(values: List<Float?>, labels: List<String>) {
    val c = IOS.colors
    val line = c.primary
    val dot = c.card
    Canvas(Modifier.fillMaxWidth().height(110.dp)) {
        val n = values.size
        if (n < 2) return@Canvas
        val padV = 8.dp.toPx()
        val h = size.height - 2 * padV
        fun px(i: Int) = size.width * (i + 0.5f) / n
        fun py(v: Float) = padV + h * (1f - (v - 1f) / 4f)
        for (g in 1..5 step 2) drawLine(c.track, Offset(0f, py(g.toFloat())), Offset(size.width, py(g.toFloat())), strokeWidth = 1.dp.toPx())
        val pts = values.mapIndexedNotNull { i, v -> if (v == null) null else Offset(px(i), py(v)) }
        if (pts.isEmpty()) return@Canvas
        if (pts.size >= 2) {
            val path = Path()
            path.moveTo(pts[0].x, pts[0].y)
            for (k in 1 until pts.size) {
                val a = pts[k - 1]; val b = pts[k]; val mx = (a.x + b.x) / 2f
                path.cubicTo(mx, a.y, mx, b.y, b.x, b.y)
            }
            val fill = Path()
            fill.addPath(path)
            fill.lineTo(pts.last().x, size.height)
            fill.lineTo(pts[0].x, size.height)
            fill.close()
            drawPath(fill, Brush.verticalGradient(listOf(line.copy(alpha = 0.28f), line.copy(alpha = 0f))))
            drawPath(path, line, style = Stroke(2.5.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
        }
        pts.forEach { drawCircle(dot, 4.5.dp.toPx(), it); drawCircle(line, 3.dp.toPx(), it) }
    }
    Row(Modifier.fillMaxWidth().padding(top = 4.dp)) {
        labels.forEach { Box(Modifier.weight(1f)) { Text(it, style = IOSType.caption.copy(fontSize = 9.sp), color = c.textSecondary, maxLines = 1, softWrap = false, overflow = TextOverflow.Visible) } }
    }
}

/** Insight strings from Smart.kt start with an emoji; split it off so a custom icon can be shown instead. */
private fun splitLead(text: String): Pair<String, String> {
    var i = 0
    while (i < text.length) {
        val cp = text.codePointAt(i)
        if (Character.isLetterOrDigit(cp) || cp == '"'.code) break
        i += Character.charCount(cp)
    }
    return text.substring(0, i) to text.substring(i).trim()
}

@DrawableRes
private fun insightIcon(lead: String): Int = when {
    lead.contains("⚠") -> R.drawable.ic_alert
    lead.contains("💡") -> R.drawable.ic_bulb
    lead.contains("📈") || lead.contains("🚀") -> R.drawable.ic_trend_up
    lead.contains("🪫") || lead.contains("🌧") -> R.drawable.ic_trend_down
    lead.contains("🕌") -> R.drawable.ic_mosque
    else -> R.drawable.ic_sprout
}

@Composable
private fun TopCard(@DrawableRes icon: Int, tint: Color, label: String, value: String, sub: String, modifier: Modifier) {
    val c = IOS.colors
    IOSCard(modifier, padding = 10.dp, corner = 16.dp) {
        IconLabel(icon, label, tint, textSize = 11.sp)
        Text(value, style = IOSType.title.copy(fontSize = 24.sp), color = c.textPrimary, modifier = Modifier.padding(top = 4.dp))
        Text(sub, style = IOSType.caption.copy(fontSize = 10.sp), color = c.textSecondary)
    }
}
