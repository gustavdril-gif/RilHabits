package com.airil.rillrebirth

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        // Task reminders repeat daily; skip the ones whose task does not run today.
        if (!intent.getBooleanExtra("workout_reminder", false)) {
            val id = intent.getIntExtra("task_id", -1)
            val today = java.util.Calendar.getInstance().get(java.util.Calendar.DAY_OF_WEEK)
            val task = TaskStore.load(context).find { it.id == id }
            if (task != null && !task.runsOn(today)) { if (intent.getBooleanExtra("prayer_reminder", false)) ReminderScheduler.scheduleAll(context); return }
        }
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            manager.createNotificationChannel(NotificationChannel("rill_reminders", "Pengingat RilHabit", NotificationManager.IMPORTANCE_DEFAULT))
        }
        val openApp = PendingIntent.getActivity(
            context, 1, Intent(context, ComposeActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0
        )
        val notification = if (Build.VERSION.SDK_INT >= 26) {
            android.app.Notification.Builder(context, "rill_reminders")
        } else {
            @Suppress("DEPRECATION")
            android.app.Notification.Builder(context)
        }.setSmallIcon(R.drawable.ic_checklist)
            .setContentTitle("RilHabit")
            .setContentText(intent.getStringExtra("task_name") ?: "Waktunya menjalankan rutinitasmu.")
            .setContentIntent(openApp)
            .setAutoCancel(true)
            .build()
        manager.notify(intent.getIntExtra("task_id", 1), notification)
        if (intent.getBooleanExtra("workout_reminder", false) || intent.getBooleanExtra("prayer_reminder", false)) ReminderScheduler.scheduleAll(context)
    }
}
