package com.airil.rillrebirth.ui.screens

import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.airil.rillrebirth.Smart
import com.airil.rillrebirth.TaskStore
import com.airil.rillrebirth.WorkoutStore
import com.airil.rillrebirth.ui.components.ChipRow
import com.airil.rillrebirth.ui.components.ChoiceChip
import com.airil.rillrebirth.ui.components.FieldLabel
import com.airil.rillrebirth.ui.components.IOSField
import com.airil.rillrebirth.ui.components.IOSSheet
import com.airil.rillrebirth.ui.components.PrimaryButton
import com.airil.rillrebirth.ui.components.iosPress
import com.airil.rillrebirth.ui.theme.IOS
import com.airil.rillrebirth.ui.theme.IOSType
import org.json.JSONObject

private val moodTags = listOf("Senang", "Tenang", "Semangat", "Bersyukur", "Fokus", "Capek", "Stres", "Cemas", "Sedih")

@Composable
fun MoodSheet(onClose: () -> Unit) {
    val ctx = LocalContext.current
    val c = IOS.colors
    val today = TaskStore.today()
    val prev = remember { WorkoutStore.mood(ctx, today) }
    var selected by remember { mutableIntStateOf((prev?.optInt("value", 0) ?: 0) - 1) }
    var note by remember { mutableStateOf(prev?.optString("note", "") ?: "") }
    val tags = remember {
        mutableStateOf(buildSet { val a = prev?.optJSONArray("tags"); if (a != null) for (i in 0 until a.length()) add(a.optString(i)) })
    }
    IOSSheet(onClose) {
        Text("Mood hari ini", style = IOSType.title, color = c.textPrimary)
        Text("Pilih yang paling menggambarkan perasaanmu.", style = IOSType.body, color = c.textSecondary, modifier = Modifier.padding(top = 4.dp, bottom = 10.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            for (i in 0..4) {
                val on = i == selected
                Column(
                    Modifier.weight(1f).clip(RoundedCornerShape(16.dp)).background(if (on) c.primarySoft else c.background).iosPress(Role.RadioButton) { selected = i }.padding(vertical = 10.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(Smart.moodEmojis[i], style = IOSType.title)
                    Text(Smart.moodLabels[i], style = IOSType.caption.copy(fontSize = 10.sp), color = c.textSecondary)
                }
            }
        }
        FieldLabel("PERASAAN (OPSIONAL)")
        ChipRow { moodTags.forEach { t -> ChoiceChip(t, tags.value.contains(t)) { tags.value = if (tags.value.contains(t)) tags.value - t else tags.value + t } } }
        FieldLabel("CATATAN SINGKAT")
        IOSField(note, { note = it }, "Apa yang terjadi hari ini?", minLines = 2)
        Spacer(Modifier.height(16.dp))
        PrimaryButton("Simpan") {
            if (selected < 0) { Toast.makeText(ctx, "Pilih mood dulu.", Toast.LENGTH_SHORT).show(); return@PrimaryButton }
            WorkoutStore.saveMood(ctx, today, selected + 1, note.trim(), tags.value.toList())
            Toast.makeText(ctx, "Mood tersimpan ${Smart.moodEmojis[selected]}", Toast.LENGTH_SHORT).show()
            onClose()
        }
    }
}

@Composable
fun ReviewSheet(onClose: () -> Unit) {
    val ctx = LocalContext.current
    val c = IOS.colors
    val prefs = remember { ctx.getSharedPreferences("rill_data", Context.MODE_PRIVATE) }
    val today = TaskStore.today()
    val old = remember { try { JSONObject(prefs.getString("review2_$today", "{}") ?: "{}") } catch (_: Exception) { JSONObject() } }
    var good by remember { mutableStateOf(old.optString("good", "")) }
    var improve by remember { mutableStateOf(old.optString("improve", "")) }
    var thanks by remember { mutableStateOf(old.optString("thanks", "")) }
    IOSSheet(onClose) {
        Text("Evaluasi malam", style = IOSType.title, color = c.textPrimary)
        FieldLabel("✅ APA YANG BERHASIL HARI INI?")
        IOSField(good, { good = it }, "Tulis satu atau dua hal", minLines = 2)
        FieldLabel("🔧 APA YANG MAU DIPERBAIKI BESOK?")
        IOSField(improve, { improve = it }, "Tulis rencana kecil", minLines = 2)
        FieldLabel("🙏 SATU HAL YANG KAMU SYUKURI")
        IOSField(thanks, { thanks = it }, "Apa saja", singleLine = true)
        Spacer(Modifier.height(16.dp))
        PrimaryButton("Simpan") {
            val o = JSONObject().put("good", good).put("improve", improve).put("thanks", thanks)
            prefs.edit().putString("review2_$today", o.toString()).apply()
            Toast.makeText(ctx, "Evaluasi tersimpan 🌙", Toast.LENGTH_SHORT).show()
            onClose()
        }
    }
}
