package com.airil.rillrebirth.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.airil.rillrebirth.R

/** iOS 18 style palette. Text colours are chosen to keep at least 4.5:1 contrast on their backgrounds. */
@Immutable
data class IOSColors(
    val dark: Boolean,
    val background: Color,
    val card: Color,
    val bar: Color,
    val primary: Color,
    val primaryText: Color,
    val primarySoft: Color,
    val blue: Color,
    val orange: Color,
    val purple: Color,
    val red: Color,
    val textPrimary: Color,
    val textSecondary: Color,
    val separator: Color,
    val track: Color
)

val LightIOS = IOSColors(
    dark = false,
    background = Color(0xFFF2F2F7), card = Color(0xFFFFFFFF), bar = Color(0xE6FFFFFF),
    primary = Color(0xFF6A9A7B), primaryText = Color(0xFF3F7352), primarySoft = Color(0xFFE3F1E9),
    blue = Color(0xFF5B8DEF), orange = Color(0xFFFF9F0A), purple = Color(0xFFAF7BE8), red = Color(0xFFE5483D),
    textPrimary = Color(0xFF1C1C1E), textSecondary = Color(0xFF6C6C70),
    separator = Color(0x1F3C3C43), track = Color(0xFFE5E5EA)
)

val DarkIOS = IOSColors(
    dark = true,
    background = Color(0xFF1C1C1E), card = Color(0xFF2C2C2E), bar = Color(0xE62C2C2E),
    primary = Color(0xFF7FB491), primaryText = Color(0xFF9BD0AD), primarySoft = Color(0xFF24382B),
    blue = Color(0xFF7AA5FF), orange = Color(0xFFFFB340), purple = Color(0xFFC9A0F5), red = Color(0xFFFF6961),
    textPrimary = Color(0xFFF2F2F7), textSecondary = Color(0xFFAEAEB2),
    separator = Color(0x33FFFFFF), track = Color(0xFF3A3A3C)
)

val LocalIOS = staticCompositionLocalOf { LightIOS }

object IOS {
    val colors: IOSColors
        @Composable @ReadOnlyComposable get() = LocalIOS.current
}

/** Bundled Helvetica-style sans (TeX Gyre Heros, free licence) so the look matches iOS on every phone, even with custom system fonts. */
val RillFont = FontFamily(
    Font(R.font.heros_regular, FontWeight.Normal),
    Font(R.font.heros_regular, FontWeight.Medium),
    Font(R.font.heros_bold, FontWeight.SemiBold),
    Font(R.font.heros_bold, FontWeight.Bold)
)

private fun rillTypography(): Typography {
    val d = Typography()
    return Typography(
        displayLarge = d.displayLarge.copy(fontFamily = RillFont), displayMedium = d.displayMedium.copy(fontFamily = RillFont), displaySmall = d.displaySmall.copy(fontFamily = RillFont),
        headlineLarge = d.headlineLarge.copy(fontFamily = RillFont), headlineMedium = d.headlineMedium.copy(fontFamily = RillFont), headlineSmall = d.headlineSmall.copy(fontFamily = RillFont),
        titleLarge = d.titleLarge.copy(fontFamily = RillFont), titleMedium = d.titleMedium.copy(fontFamily = RillFont), titleSmall = d.titleSmall.copy(fontFamily = RillFont),
        bodyLarge = d.bodyLarge.copy(fontFamily = RillFont), bodyMedium = d.bodyMedium.copy(fontFamily = RillFont), bodySmall = d.bodySmall.copy(fontFamily = RillFont),
        labelLarge = d.labelLarge.copy(fontFamily = RillFont), labelMedium = d.labelMedium.copy(fontFamily = RillFont), labelSmall = d.labelSmall.copy(fontFamily = RillFont)
    )
}

/** Text styles. */
object IOSType {
    val largeTitle = TextStyle(fontFamily = RillFont, fontSize = 34.sp, fontWeight = FontWeight.Bold, lineHeight = 40.sp)
    val title = TextStyle(fontFamily = RillFont, fontSize = 22.sp, fontWeight = FontWeight.Bold)
    val headline = TextStyle(fontFamily = RillFont, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
    val body = TextStyle(fontFamily = RillFont, fontSize = 15.sp, fontWeight = FontWeight.Normal)
    val caption = TextStyle(fontFamily = RillFont, fontSize = 12.sp, fontWeight = FontWeight.Normal)
    val number = TextStyle(fontFamily = RillFont, fontSize = 40.sp, fontWeight = FontWeight.Bold)
}

@Composable
fun RillTheme(dark: Boolean = isSystemInDarkTheme(), content: @Composable () -> Unit) {
    val c = if (dark) DarkIOS else LightIOS
    val scheme = if (dark) darkColorScheme(primary = c.primary, background = c.background, surface = c.card, onSurface = c.textPrimary, onBackground = c.textPrimary)
    else lightColorScheme(primary = c.primary, background = c.background, surface = c.card, onSurface = c.textPrimary, onBackground = c.textPrimary)
    CompositionLocalProvider(LocalIOS provides c) {
        MaterialTheme(colorScheme = scheme, typography = rillTypography(), content = content)
    }
}
