# Font
Aplikasi membundel **TeX Gyre Heros** (klon Helvetica, mirip SF Pro iOS) di `app/src/main/res/font/`.
Lisensi: GUST Font License (bebas dipakai & didistribusikan, termasuk dibundel di aplikasi).
Ingin hasil lebih persis iOS? Ganti `heros_regular.otf` / `heros_bold.otf` dengan Inter (nama file sama), tanpa ubah kode.
