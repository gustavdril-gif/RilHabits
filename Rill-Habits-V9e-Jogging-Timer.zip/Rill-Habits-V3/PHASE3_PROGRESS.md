# Rill Habits - Fase 3 (beta1)

Seluruh UI sekarang Jetpack Compose dengan satu Activity (`ComposeActivity`) dan Navigation Compose.
Tampilan lama berbasis View (`MainActivity` dan file pendukungnya) sudah dihapus.
`SecretActivity` (Ruang Tenang) sengaja tetap Activity terpisah dengan View sendiri.

## Rute
Tab: home, checklist, workout, stats
Sub-layar: jadwal, notes (Catatan & Target), jogging, jog_live, jog_sum/{id}, timer/{flow}, wo/{id}, builder/{id}, ritual/{kind}

## Data
Tidak ada perubahan format. Semua tetap di SharedPreferences `rill_data` lewat TaskStore, WorkoutStore, NoteStore, GoalStore, RunStore, SecretStore.

## Dihapus
MainActivity, Workout.kt, Jogging.kt (UI), Ritual.kt, Stats.kt, Sky.kt, Views.kt (kecuali TickSound yang pindah ke Engines.kt), LegacyTab.

## Belum
- Jadwal berbentuk timeline dengan blok yang bisa diseret
- Onboarding 3 halaman dan splash screen
- Ilustrasi cat air sungguhan (saat ini digambar lewat kode)
