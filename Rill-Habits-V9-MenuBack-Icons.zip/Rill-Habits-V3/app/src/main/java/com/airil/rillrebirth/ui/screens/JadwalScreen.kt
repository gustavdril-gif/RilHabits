package com.airil.rillrebirth.ui.screens

import android.app.TimePickerDialog
import android.content.Context
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp
import com.airil.rillrebirth.Backup
import com.airil.rillrebirth.PrayerTimes
import com.airil.rillrebirth.RillTask
import com.airil.rillrebirth.RillWidget
import com.airil.rillrebirth.ReminderScheduler
import com.airil.rillrebirth.TaskStore
import com.airil.rillrebirth.WorkoutStore
import com.airil.rillrebirth.autoLinkPrayerTasks
import com.airil.rillrebirth.Smart
import com.airil.rillrebirth.ui.components.ChipRow
import com.airil.rillrebirth.ui.components.ChoiceChip
import com.airil.rillrebirth.ui.components.ConfirmDialog
import com.airil.rillrebirth.ui.components.DayPicker
import com.airil.rillrebirth.ui.components.FieldLabel
import com.airil.rillrebirth.ui.components.IOSCard
import com.airil.rillrebirth.ui.components.IOSField
import com.airil.rillrebirth.ui.components.IOSSheet
import com.airil.rillrebirth.ui.components.OutlineButton
import com.airil.rillrebirth.ui.components.PrimaryButton
import com.airil.rillrebirth.ui.components.RillNav
import com.airil.rillrebirth.ui.components.RillRoutes
import com.airil.rillrebirth.ui.components.ScreenScaffold
import com.airil.rillrebirth.ui.components.SectionTitle
import com.airil.rillrebirth.ui.components.WeekOrder
import com.airil.rillrebirth.ui.components.iosPress
import com.airil.rillrebirth.ui.data.TodayData
import com.airil.rillrebirth.ui.theme.IOS
import com.airil.rillrebirth.ui.theme.IOSType
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

fun daysLabel(days: Set<Int>): String {
    if (days.isEmpty() || days.size >= 7) return "Tiap hari"
    val d = days.sortedBy { (it + 5) % 7 }
    return when {
        d == WeekOrder.take(5).sortedBy { (it + 5) % 7 } -> "Sen–Jum"
        d == WeekOrder.drop(5).sortedBy { (it + 5) % 7 } -> "Sab–Min"
        else -> d.joinToString(" · ") { Smart.weekdayLabel(it) }
    }
}

@Composable
fun JadwalScreen(nav: RillNav) {
    val ctx = LocalContext.current
    val c = IOS.colors
    var tick by remember { mutableIntStateOf(0) }
    var taskEdit by remember { mutableStateOf<RillTask?>(null) }
    var taskPrefill by remember { mutableStateOf<RillTask?>(null) }
    var taskNew by remember { mutableStateOf(false) }
    val tasks = remember(tick) { TaskStore.load(ctx).sortedBy { TodayData.minutes(ctx, it) } }
    val workouts = remember(tick) { WorkoutStore.load(ctx) }
    val prefs = remember { ctx.getSharedPreferences("rill_data", Context.MODE_PRIVATE) }
    var remindersOn by remember { mutableStateOf(prefs.getBoolean("reminders_enabled", true)) }

    ScreenScaffold(title = "Jadwal", onBack = { nav.back() }, subtitle = "Kegiatan, workout, waktu shalat, dan cadangan") {
        item { SectionTitle("Kegiatan") }
        item {
            IOSCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Pengingat tugas", style = IOSType.body, color = c.textPrimary, modifier = Modifier.weight(1f))
                    Switch(checked = remindersOn, onCheckedChange = { remindersOn = it; prefs.edit().putBoolean("reminders_enabled", it).apply(); ReminderScheduler.scheduleAll(ctx) })
                }
                Spacer(Modifier.height(8.dp))
                if (tasks.isEmpty()) Text("Belum ada kegiatan.", style = IOSType.body, color = c.textSecondary)
                tasks.forEach { t ->
                    Column(Modifier.fillMaxWidth().iosPress(Role.Button) { taskEdit = t }.padding(vertical = 8.dp)) {
                        Text(t.name, style = IOSType.headline, color = c.textPrimary)
                        Text("${TodayData.timeLabel(ctx, t)}${if (t.prayer.isNotEmpty()) " 🕌" else ""} · ${t.category} · ${daysLabel(t.days)}", style = IOSType.caption, color = c.textSecondary)
                    }
                }
                Spacer(Modifier.height(8.dp))
                PrimaryButton("+ Tambah kegiatan") { taskNew = true }
            }
        }
        item { SectionTitle("Workout") }
        item {
            IOSCard {
                if (workouts.isEmpty()) Text("Belum ada jadwal workout.", style = IOSType.body, color = c.textSecondary)
                workouts.forEach { s ->
                    Column(Modifier.fillMaxWidth().iosPress(Role.Button) { nav.go(RillRoutes.builder(s.id)) }.padding(vertical = 8.dp)) {
                        Text(s.name, style = IOSType.headline, color = c.textPrimary)
                        Text("${if (s.oneOffDate.isNotBlank()) s.oneOffDate else daysLabel(s.days)} · ${s.time} · ${if (s.active) "Aktif" else "Dijeda"}", style = IOSType.caption, color = c.textSecondary)
                    }
                }
                Spacer(Modifier.height(8.dp))
                PrimaryButton("Bikin Jadwal") { nav.go(RillRoutes.builder(0L)) }
            }
        }
        item { SectionTitle("Waktu shalat") }
        item { PrayerCard(onChanged = { tick++ }) }
        item { SectionTitle("Data & cadangan") }
        item { BackupCard(onChanged = { tick++ }) }
    }

    if (taskNew || taskEdit != null) {
        TaskEditor(
            existing = taskEdit, prefill = taskPrefill,
            onClose = { taskNew = false; taskEdit = null; taskPrefill = null; tick++ },
            onCopy = { copy -> taskEdit = null; taskPrefill = copy; taskNew = true }
        )
    }
}

// ------------------------------------------------ task editor ------------------------------------------------
@Composable
private fun TaskEditor(existing: RillTask?, prefill: RillTask?, onClose: () -> Unit, onCopy: (RillTask) -> Unit) {
    val ctx = LocalContext.current
    val c = IOS.colors
    val base = existing ?: prefill
    var name by remember(existing?.id, prefill) { mutableStateOf(base?.name ?: "") }
    var time by remember(existing?.id, prefill) { mutableStateOf(base?.time ?: "18:00") }
    var category by remember(existing?.id, prefill) { mutableStateOf(base?.category ?: "Umum") }
    var xp by remember(existing?.id, prefill) { mutableStateOf((base?.xp ?: 10).toString()) }
    var reminder by remember(existing?.id, prefill) { mutableStateOf(base?.reminderEnabled ?: false) }
    var days by remember(existing?.id, prefill) { mutableStateOf(if (base == null || base.days.isEmpty()) WeekOrder.toSet() else base.days.toSet()) }
    var prayer by remember(existing?.id, prefill) { mutableStateOf(base?.prayer ?: "") }
    var confirmDelete by remember { mutableStateOf(false) }

    IOSSheet(onClose) {
        Text(if (existing == null) "Tambah kegiatan" else "Edit kegiatan", style = IOSType.title, color = c.textPrimary)
        FieldLabel("NAMA")
        IOSField(name, { name = it }, "mis. Belajar mandiri", singleLine = true)
        FieldLabel("JAM")
        Box(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(c.primarySoft).iosPress(Role.Button) {
                val p = time.split(":")
                TimePickerDialog(ctx, { _, h, m -> time = String.format(Locale.US, "%02d:%02d", h, m) }, p.getOrNull(0)?.toIntOrNull() ?: 18, p.getOrNull(1)?.toIntOrNull() ?: 0, true).show()
            }.padding(vertical = 14.dp),
            contentAlignment = Alignment.Center
        ) { Text("🕒  $time", style = IOSType.title, color = c.primaryText) }
        FieldLabel("KATEGORI")
        IOSField(category, { category = it }, "Kategori", singleLine = true)
        Spacer(Modifier.height(8.dp))
        ChipRow { listOf("Ibadah", "Belajar", "Olahraga", "Rutinitas", "Pengembangan diri", "Refleksi").forEach { k -> ChoiceChip(k, category == k) { category = k } } }
        FieldLabel("BERLAKU DI HARI")
        DayPicker(days) { days = it }
        FieldLabel("IKUTI WAKTU SHALAT KOTAKU")
        ChipRow {
            ChoiceChip("Manual", prayer.isEmpty()) { prayer = "" }
            PrayerTimes.KEYS.forEach { k ->
                ChoiceChip(PrayerTimes.LABELS[k] ?: k, prayer == k) {
                    prayer = k
                    val m = PrayerTimes.minutes(ctx, k)
                    if (m == null) Toast.makeText(ctx, "Pilih kota dulu di menu Jadwal agar jamnya otomatis.", Toast.LENGTH_LONG).show()
                    else { time = PrayerTimes.format(m); reminder = true }
                }
            }
        }
        FieldLabel("EXP")
        IOSField(xp, { xp = it.filter { ch -> ch.isDigit() }.take(3) }, "10", singleLine = true, numeric = true)
        Row(Modifier.padding(top = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Aktifkan pengingat harian", style = IOSType.body, color = c.textPrimary, modifier = Modifier.weight(1f))
            Switch(checked = reminder, onCheckedChange = { reminder = it })
        }
        Spacer(Modifier.height(16.dp))
        PrimaryButton("Simpan") {
            if (name.isBlank() || !Regex("^([01]?[0-9]|2[0-3]):[0-5][0-9]$").matches(time.trim())) { Toast.makeText(ctx, "Isi nama dan jam yang valid.", Toast.LENGTH_LONG).show(); return@PrimaryButton }
            if (days.isEmpty()) { Toast.makeText(ctx, "Pilih minimal satu hari.", Toast.LENGTH_LONG).show(); return@PrimaryButton }
            val all = TaskStore.load(ctx)
            val hh = time.trim().substringBefore(":").toInt(); val mm = time.trim().substringAfter(":").toInt()
            val t = if (existing != null) all.find { it.id == existing.id } ?: existing else RillTask((all.maxOfOrNull { it.id } ?: 0) + 1, "", "18:00", "Umum", 10, false)
            t.name = name.trim(); t.time = String.format(Locale.US, "%02d:%02d", hh, mm); t.category = category.ifBlank { "Umum" }
            t.xp = (xp.toIntOrNull() ?: 10).coerceIn(0, 500); t.reminderEnabled = reminder
            t.days = if (days.size >= 7) mutableSetOf() else days.toMutableSet(); t.prayer = prayer
            if (existing == null) all.add(t)
            TaskStore.save(ctx, all); ReminderScheduler.scheduleAll(ctx)
            onClose()
        }
        if (existing != null) {
            Spacer(Modifier.height(8.dp))
            OutlineButton("Salin untuk hari yang tidak dipilih") {
                if (days.isEmpty()) { Toast.makeText(ctx, "Pilih minimal satu hari dulu.", Toast.LENGTH_SHORT).show(); return@OutlineButton }
                val all = TaskStore.load(ctx)
                all.find { it.id == existing.id }?.days = if (days.size >= 7) mutableSetOf() else days.toMutableSet()
                TaskStore.save(ctx, all)
                val other = WeekOrder.filter { !days.contains(it) }.ifEmpty { WeekOrder }
                onCopy(RillTask((all.maxOfOrNull { it.id } ?: 0) + 1, name.trim(), time, category.ifBlank { "Umum" }, (xp.toIntOrNull() ?: 10).coerceIn(0, 500), reminder, other.toMutableSet(), prayer))
            }
            Spacer(Modifier.height(8.dp))
            OutlineButton("Hapus kegiatan") { confirmDelete = true }
        }
    }
    if (confirmDelete && existing != null) ConfirmDialog("Hapus kegiatan?", "\"${existing.name}\" akan dihapus dari jadwalmu.", "Hapus", {
        TodayData.delete(ctx, existing.id); confirmDelete = false; onClose()
    }, { confirmDelete = false })
}

// ------------------------------------------------ prayer ------------------------------------------------
@Composable
private fun PrayerCard(onChanged: () -> Unit) {
    val ctx = LocalContext.current
    val c = IOS.colors
    var pick by remember { mutableStateOf(false) }
    var custom by remember { mutableStateOf(false) }
    var offset by remember { mutableStateOf(false) }
    val city = PrayerTimes.city(ctx)
    IOSCard {
        Text("🕌 Waktu shalat", style = IOSType.headline, color = c.textPrimary)
        if (city == null) {
            Text("Pilih kotamu, lalu kegiatan shalat dan pengingatnya otomatis mengikuti waktu setempat — tanpa internet dan tanpa izin lokasi.", style = IOSType.body, color = c.textSecondary, modifier = Modifier.padding(top = 4.dp, bottom = 12.dp))
            PrimaryButton("Pilih kota") { pick = true }
        } else {
            Text("${city.name} · perkiraan hari ini (bisa selisih beberapa menit dari jadwal resmi)", style = IOSType.caption, color = c.textSecondary, modifier = Modifier.padding(top = 4.dp, bottom = 10.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                PrayerTimes.KEYS.forEach { k ->
                    Column(Modifier.weight(1f).clip(RoundedCornerShape(12.dp)).background(c.background).padding(vertical = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(PrayerTimes.LABELS[k] ?: k, style = IOSType.caption, color = c.textSecondary)
                        Text(PrayerTimes.format(PrayerTimes.minutes(ctx, k) ?: 0), style = IOSType.headline, color = c.textPrimary)
                    }
                }
            }
            val off = PrayerTimes.offset(ctx)
            Text("Koreksi: ${if (off > 0) "+$off" else "$off"} menit", style = IOSType.caption, color = c.textSecondary, modifier = Modifier.padding(top = 8.dp, bottom = 10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlineButton("Ganti kota", Modifier.weight(1f)) { pick = true }
                OutlineButton("Koreksi menit", Modifier.weight(1f)) { offset = true }
            }
            Spacer(Modifier.height(8.dp))
            OutlineButton("Terapkan ke kegiatan shalat") {
                val n = autoLinkPrayerTasks(ctx)
                Toast.makeText(ctx, if (n > 0) "$n kegiatan shalat kini mengikuti jadwal dan pengingatnya aktif." else "Tidak ada kegiatan shalat baru yang bisa dihubungkan. Atur manual di form kegiatan.", Toast.LENGTH_LONG).show()
                onChanged()
            }
        }
    }
    if (pick) IOSSheet({ pick = false }) {
        Text("Pilih kota", style = IOSType.title, color = c.textPrimary)
        Spacer(Modifier.height(8.dp))
        PrayerTimes.cities.forEach { ct ->
            Text(ct.name, style = IOSType.body, color = c.textPrimary, modifier = Modifier.fillMaxWidth().iosPress(Role.Button) {
                PrayerTimes.setCity(ctx, ct.name)
                val n = autoLinkPrayerTasks(ctx)
                Toast.makeText(ctx, if (n > 0) "$n kegiatan shalat kini mengikuti jadwal ${ct.name}." else "Kota disimpan.", Toast.LENGTH_LONG).show()
                ReminderScheduler.scheduleAll(ctx); pick = false; onChanged()
            }.padding(vertical = 12.dp))
        }
        Text("Koordinat manual…", style = IOSType.body, color = c.primaryText, modifier = Modifier.fillMaxWidth().iosPress(Role.Button) { pick = false; custom = true }.padding(vertical = 12.dp))
    }
    if (custom) {
        var lat by remember { mutableStateOf("") }; var lng by remember { mutableStateOf("") }; var tz by remember { mutableStateOf("7") }
        IOSSheet({ custom = false }) {
            Text("Koordinat manual", style = IOSType.title, color = c.textPrimary)
            FieldLabel("LINTANG (mis. -6.2088)"); IOSField(lat, { lat = it }, "-6.2088", singleLine = true)
            FieldLabel("BUJUR (mis. 106.8456)"); IOSField(lng, { lng = it }, "106.8456", singleLine = true)
            FieldLabel("ZONA WAKTU: 7 (WIB), 8 (WITA), 9 (WIT)"); IOSField(tz, { tz = it }, "7", singleLine = true)
            Spacer(Modifier.height(16.dp))
            PrimaryButton("Simpan") {
                val la = lat.toDoubleOrNull(); val lo = lng.toDoubleOrNull(); val z = tz.toDoubleOrNull() ?: 7.0
                if (la == null || lo == null || la !in -66.0..66.0 || lo !in -180.0..180.0) { Toast.makeText(ctx, "Koordinat tidak valid.", Toast.LENGTH_LONG).show(); return@PrimaryButton }
                PrayerTimes.setCustom(ctx, la, lo, z); autoLinkPrayerTasks(ctx); ReminderScheduler.scheduleAll(ctx); custom = false; onChanged()
            }
        }
    }
    if (offset) {
        var v by remember { mutableStateOf(PrayerTimes.offset(ctx).toString()) }
        IOSSheet({ offset = false }) {
            Text("Koreksi menit", style = IOSType.title, color = c.textPrimary)
            Text("Tambah atau kurangi menit untuk semua waktu shalat agar cocok dengan jadwal masjid atau aplikasi yang kamu pakai (-30 sampai 30).", style = IOSType.body, color = c.textSecondary, modifier = Modifier.padding(top = 4.dp, bottom = 8.dp))
            IOSField(v, { v = it.filter { ch -> ch.isDigit() || ch == '-' }.take(3) }, "0", singleLine = true)
            Spacer(Modifier.height(16.dp))
            PrimaryButton("Simpan") { PrayerTimes.setOffset(ctx, v.toIntOrNull() ?: 0); ReminderScheduler.scheduleAll(ctx); offset = false; onChanged() }
        }
    }
}

// ------------------------------------------------ backup ------------------------------------------------
@Composable
private fun BackupCard(onChanged: () -> Unit) {
    val ctx = LocalContext.current
    val c = IOS.colors
    var pending by remember { mutableStateOf<JSONObject?>(null) }
    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) {
            try {
                ctx.contentResolver.openOutputStream(uri)?.use { it.write(Backup.export(ctx).toByteArray(Charsets.UTF_8)) }
                Toast.makeText(ctx, "Cadangan tersimpan ✅", Toast.LENGTH_LONG).show()
            } catch (_: Exception) { Toast.makeText(ctx, "Gagal menyimpan cadangan.", Toast.LENGTH_LONG).show() }
        }
    }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val text = try { ctx.contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } } catch (_: Exception) { null }
            val root = if (text == null) null else Backup.parse(text)
            if (root == null) Toast.makeText(ctx, "File ini bukan cadangan RilHabit yang valid.", Toast.LENGTH_LONG).show() else pending = root
        }
    }
    IOSCard {
        Text("💾 Data & cadangan", style = IOSType.headline, color = c.textPrimary)
        Text("Simpan semua kegiatan, workout, catatan, dan target ke satu file. Berguna saat ganti HP atau memasang ulang aplikasi.", style = IOSType.body, color = c.textSecondary, modifier = Modifier.padding(top = 4.dp, bottom = 12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlineButton("Cadangkan", Modifier.weight(1f)) { exportLauncher.launch("rilhabit-backup-${SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())}.json") }
            OutlineButton("Pulihkan", Modifier.weight(1f)) { importLauncher.launch(arrayOf("*/*")) }
        }
    }
    val p = pending
    if (p != null) ConfirmDialog("Pulihkan data?", "${Backup.summary(p)}\n\nSemua data di HP ini akan diganti dengan isi cadangan.", "Pulihkan", {
        if (Backup.restore(ctx, p)) {
            ReminderScheduler.scheduleAll(ctx); RillWidget.updateAll(ctx)
            Toast.makeText(ctx, "Data berhasil dipulihkan ✅", Toast.LENGTH_LONG).show()
        } else Toast.makeText(ctx, "Gagal memulihkan data.", Toast.LENGTH_LONG).show()
        pending = null; onChanged()
    }, { pending = null })
}
