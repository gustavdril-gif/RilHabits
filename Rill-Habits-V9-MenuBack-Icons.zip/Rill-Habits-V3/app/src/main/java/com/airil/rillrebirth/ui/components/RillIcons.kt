package com.airil.rillrebirth.ui.components

import androidx.annotation.DrawableRes
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.airil.rillrebirth.R
import com.airil.rillrebirth.ui.theme.IOS
import com.airil.rillrebirth.ui.theme.IOSType

/** Plain tinted icon from the app's own vector set (res/drawable/ic_*.xml). */
@Composable
fun RIcon(@DrawableRes icon: Int, tint: Color, size: Dp = 22.dp, modifier: Modifier = Modifier) {
    Icon(painterResource(icon), contentDescription = null, tint = tint, modifier = modifier.size(size))
}

/** Round badge with a custom icon: solid colour + white glyph (like the iOS reference) or a soft tint. */
@Composable
fun IconBadge(@DrawableRes icon: Int, color: Color, size: Dp = 40.dp, solid: Boolean = true) {
    Box(
        Modifier.size(size).clip(CircleShape).background(if (solid) color else color.copy(alpha = 0.16f)),
        contentAlignment = Alignment.Center
    ) {
        Icon(painterResource(icon), contentDescription = null, tint = if (solid) Color.White else color, modifier = Modifier.size(size * 0.56f))
    }
}

/** Small caption with a leading icon, e.g. "Streak workout". */
@Composable
fun IconLabel(@DrawableRes icon: Int, text: String, tint: Color, modifier: Modifier = Modifier) {
    val c = IOS.colors
    Row(modifier, verticalAlignment = Alignment.CenterVertically) {
        Icon(painterResource(icon), contentDescription = null, tint = tint, modifier = Modifier.size(14.dp))
        Spacer(Modifier.width(5.dp))
        Text(text, style = IOSType.caption, color = c.textSecondary)
    }
}

/** Top-left button that leaves a menu and returns to Beranda. */
@Composable
fun BackButton(label: String = "Beranda", onClick: () -> Unit) {
    val c = IOS.colors
    val shape = RoundedCornerShape(22.dp)
    Row(
        Modifier.height(40.dp)
            .shadow(4.dp, shape, ambientColor = Color.Black.copy(alpha = 0.08f), spotColor = Color.Black.copy(alpha = 0.08f))
            .clip(shape).background(c.card)
            .semantics { contentDescription = "Kembali ke $label" }
            .iosPress(Role.Button, onClick)
            .padding(start = 8.dp, end = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(painterResource(R.drawable.ic_back), contentDescription = null, tint = c.primaryText, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(2.dp))
        Text(label, style = IOSType.body.copy(fontWeight = FontWeight.SemiBold), color = c.primaryText)
    }
}

/** Header used by Habit, Workout and Statistik: back button on the left, then large title and subtitle. */
@Composable
fun MenuHeader(title: String, subtitle: String? = null, onBack: () -> Unit) {
    val c = IOS.colors
    Column(Modifier.fillMaxWidth()) {
        BackButton(onClick = onBack)
        Text(title, style = IOSType.largeTitle, color = c.textPrimary, modifier = Modifier.padding(start = 4.dp, top = 10.dp))
        if (subtitle != null) Text(subtitle, style = IOSType.body, color = c.textSecondary, modifier = Modifier.padding(start = 4.dp))
    }
}

/** Empty state with a custom icon instead of an emoji. */
@Composable
fun EmptyState(@DrawableRes icon: Int, title: String, body: String, action: String? = null, onAction: () -> Unit = {}) {
    val c = IOS.colors
    IOSCard {
        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            IconBadge(icon, c.primary, 56.dp, solid = false)
            Text(title, style = IOSType.headline, color = c.textPrimary, modifier = Modifier.padding(top = 10.dp))
            Text(body, style = IOSType.body, color = c.textSecondary, modifier = Modifier.padding(top = 4.dp, bottom = 8.dp))
            if (action != null) {
                Box(
                    Modifier.clip(RoundedCornerShape(50)).background(c.primarySoft).iosPress(Role.Button, onAction).padding(horizontal = 20.dp, vertical = 10.dp)
                ) { Text(action, style = IOSType.body, color = c.primaryText) }
            }
        }
    }
}
