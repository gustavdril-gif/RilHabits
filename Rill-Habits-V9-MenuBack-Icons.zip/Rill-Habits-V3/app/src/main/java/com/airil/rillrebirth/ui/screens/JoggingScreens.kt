package com.airil.rillrebirth.ui.screens

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.LocationManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.airil.rillrebirth.Fmt
import com.airil.rillrebirth.RunRecord
import com.airil.rillrebirth.RunService
import com.airil.rillrebirth.RunStore
import com.airil.rillrebirth.RunTracker
import com.airil.rillrebirth.ui.components.ConfirmDialog
import com.airil.rillrebirth.ui.components.EmptyState
import com.airil.rillrebirth.ui.components.IOSCard
import com.airil.rillrebirth.ui.components.OutlineButton
import com.airil.rillrebirth.ui.components.PrimaryButton
import com.airil.rillrebirth.ui.components.RillNav
import com.airil.rillrebirth.ui.components.RillRoutes
import com.airil.rillrebirth.ui.components.RouteView
import com.airil.rillrebirth.ui.components.ScreenScaffold
import com.airil.rillrebirth.ui.components.SectionTitle
import com.airil.rillrebirth.ui.components.ThinBar
import com.airil.rillrebirth.ui.components.iosPress
import com.airil.rillrebirth.ui.data.TodayData
import com.airil.rillrebirth.ui.theme.IOS
import com.airil.rillrebirth.ui.theme.IOSType
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.max
import kotlin.math.roundToInt

private fun dateText(ms: Long) = SimpleDateFormat("EEE, d MMM · HH:mm", Locale("id", "ID")).format(Date(ms))

private fun openAppSettings(ctx: Context) {
    try { ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}"))) } catch (_: Exception) { }
}

// ============================ HUB ============================
@Composable
fun JoggingHubScreen(nav: RillNav) {
    val ctx = LocalContext.current
    val c = IOS.colors
    var tick by remember { mutableIntStateOf(0) }
    var tips by remember { mutableStateOf(false) }
    var gpsOff by remember { mutableStateOf(false) }
    var denied by remember { mutableStateOf(false) }
    val runs = remember(tick) { RunStore.load(ctx) }
    val recovered = remember(tick) { if (RunTracker.active) emptyList() else RunStore.recoverPoints(ctx) }
    val beep = remember(tick) { ctx.getSharedPreferences("rill_data", Context.MODE_PRIVATE).getBoolean("run_beep", true) }

    fun beginRun() {
        val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        if (!lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) { gpsOff = true; return }
        RunTracker.begin(ctx)
        RunService.send(ctx, RunService.ACTION_START)
        nav.go(RillRoutes.JOG_LIVE)
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { _ ->
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) beginRun() else denied = true
    }
    fun requestStart() {
        val need = mutableListOf<String>()
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) { need.add(Manifest.permission.ACCESS_FINE_LOCATION); need.add(Manifest.permission.ACCESS_COARSE_LOCATION) }
        if (Build.VERSION.SDK_INT >= 29 && ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACTIVITY_RECOGNITION) != PackageManager.PERMISSION_GRANTED) need.add(Manifest.permission.ACTIVITY_RECOGNITION)
        if (need.isNotEmpty()) launcher.launch(need.toTypedArray()) else beginRun()
    }

    val weekStart = remember { Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0); add(Calendar.DAY_OF_YEAR, -((get(Calendar.DAY_OF_WEEK) + 5) % 7)) }.timeInMillis }
    val monthStart = remember { Calendar.getInstance().apply { set(Calendar.DAY_OF_MONTH, 1); set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }.timeInMillis }
    val w = runs.filter { it.start >= weekStart }
    val m = runs.filter { it.start >= monthStart }

    ScreenScaffold(title = "Jogging 🏃", onBack = { nav.back() }) {
        if (RunTracker.active) {
            item {
                IOSCard {
                    Text("Jogging sedang direkam", style = IOSType.headline, color = c.primaryText)
                    Text("${Fmt.km(RunTracker.distM)} km · ${Fmt.dur(RunTracker.elapsedMs())}", style = IOSType.body, color = c.textSecondary, modifier = Modifier.padding(bottom = 10.dp))
                    PrimaryButton("Buka rekaman") { nav.go(RillRoutes.JOG_LIVE) }
                }
            }
        } else {
            if (recovered.size >= 2) item {
                IOSCard {
                    Text("Rekaman terputus ditemukan", style = IOSType.headline, color = c.orange)
                    Text("${Fmt.km(recovered.last().dist)} km sempat terekam sebelum aplikasi berhenti. Simpan sebagai jogging?", style = IOSType.body, color = c.textSecondary, modifier = Modifier.padding(bottom = 10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlineButton("Buang", Modifier.weight(1f)) { RunTracker.activeFile(ctx).delete(); tick++ }
                        PrimaryButton("Simpan", Modifier.weight(1f)) {
                            val start = ctx.getSharedPreferences("rill_data", Context.MODE_PRIVATE).getLong("run_active_start", recovered.first().t)
                            val r = RunStore.recordFrom(ctx, start, recovered.last().t - start, recovered.last().mov, recovered.last().dist, recovered, 0, true)
                            RunStore.attachTrack(ctx, r.id); RunStore.add(ctx, r); tick++; nav.go(RillRoutes.jogSum(r.id))
                        }
                    }
                }
            }
            item {
                IOSCard {
                    Text("Siap lari?", style = IOSType.title, color = c.textPrimary)
                    Text("Berdiri di tempat terbuka sampai GPS terkunci (±20 detik), lalu mulai. Rekaman tetap berjalan saat layar mati.", style = IOSType.body, color = c.textSecondary, modifier = Modifier.padding(top = 4.dp, bottom = 12.dp))
                    PrimaryButton("Mulai Jogging") { requestStart() }
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlineButton("Bunyi tiap km: ${if (beep) "Aktif" else "Mati"}", Modifier.weight(1f)) {
                            ctx.getSharedPreferences("rill_data", Context.MODE_PRIVATE).edit().putBoolean("run_beep", !beep).apply(); tick++
                        }
                        OutlineButton("Tips rekaman", Modifier.weight(1f)) { tips = true }
                    }
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                IOSCard(Modifier.weight(1f)) {
                    Text("📅 minggu ini", style = IOSType.caption, color = c.textSecondary)
                    Text("${Fmt.km(w.sumOf { it.distM })} km", style = IOSType.title, color = c.textPrimary)
                    Text("${w.size} lari", style = IOSType.caption, color = c.textSecondary)
                }
                IOSCard(Modifier.weight(1f)) {
                    Text("🗓️ bulan ini", style = IOSType.caption, color = c.textSecondary)
                    Text("${Fmt.km(m.sumOf { it.distM })} km", style = IOSType.title, color = c.textPrimary)
                    Text("${m.size} lari", style = IOSType.caption, color = c.textSecondary)
                }
            }
        }
        if (runs.isNotEmpty()) {
            val best = runs.filter { it.distM >= 1000 }.minOfOrNull { it.avgPaceSec } ?: 0
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    IOSCard(Modifier.weight(1f)) {
                        Text("⚡ pace terbaik", style = IOSType.caption, color = c.textSecondary)
                        Text(Fmt.pace(best), style = IOSType.title, color = c.textPrimary)
                        Text("per km (≥ 1 km)", style = IOSType.caption, color = c.textSecondary)
                    }
                    IOSCard(Modifier.weight(1f)) {
                        Text("🏁 lari terjauh", style = IOSType.caption, color = c.textSecondary)
                        Text("${Fmt.km(runs.maxOf { it.distM })} km", style = IOSType.title, color = c.textPrimary)
                        Text("sekali lari", style = IOSType.caption, color = c.textSecondary)
                    }
                }
            }
        }
        item { SectionTitle("Riwayat") }
        if (runs.isEmpty()) item { EmptyState("👟", "Belum ada rekaman", "Lari pertamamu akan muncul di sini.") }
        else item {
            IOSCard {
                runs.take(30).forEach { r ->
                    Column(Modifier.fillMaxWidth().iosPress(Role.Button) { nav.go(RillRoutes.jogSum(r.id)) }.padding(vertical = 8.dp)) {
                        Text("${dateText(r.start)} · ${Fmt.km(r.distM)} km", style = IOSType.headline, color = c.textPrimary)
                        Text("${Fmt.dur(r.movMs)} · pace ${Fmt.pace(r.avgPaceSec)}/km", style = IOSType.caption, color = c.textSecondary)
                    }
                }
            }
        }
    }

    if (tips) AlertDialog(
        onDismissRequest = { tips = false },
        title = { Text("Agar rekaman tidak terputus") },
        text = { Text("Di HP Xiaomi/Redmi, sistem sering mematikan aplikasi di latar belakang. Cek sekali saja:\n\n1. Pengaturan → Aplikasi → Rill Habits → Penghemat baterai → Tanpa batasan.\n2. Aktifkan Mulai otomatis.\n3. Izin → Lokasi → \"Izinkan sepanjang waktu\" atau \"Saat aplikasi digunakan\".\n4. Kunci aplikasi di layar aplikasi terbaru.\n5. Nyalakan Lokasi dengan akurasi tinggi (GPS).\n\nJika sesi sempat terputus, bagian yang sudah terekam bisa dipulihkan di halaman ini.") },
        confirmButton = { TextButton(onClick = { tips = false }) { Text("Mengerti") } },
        dismissButton = { TextButton(onClick = { tips = false; openAppSettings(ctx) }) { Text("Buka pengaturan aplikasi") } }
    )
    if (gpsOff) AlertDialog(
        onDismissRequest = { gpsOff = false },
        title = { Text("GPS mati") }, text = { Text("Nyalakan Lokasi (GPS) dulu supaya jejakmu terekam.") },
        confirmButton = { TextButton(onClick = { gpsOff = false; try { ctx.startActivity(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)) } catch (_: Exception) { } }) { Text("Buka pengaturan lokasi") } },
        dismissButton = { TextButton(onClick = { gpsOff = false }) { Text("Batal") } }
    )
    if (denied) AlertDialog(
        onDismissRequest = { denied = false },
        title = { Text("Izin lokasi dibutuhkan") }, text = { Text("Tanpa izin lokasi, jejak dan pace tidak bisa direkam. Kamu bisa mengizinkannya di pengaturan aplikasi.") },
        confirmButton = { TextButton(onClick = { denied = false; openAppSettings(ctx) }) { Text("Buka pengaturan") } },
        dismissButton = { TextButton(onClick = { denied = false }) { Text("Batal") } }
    )
}

// ============================ LIVE ============================
@Composable
fun JoggingLiveScreen(nav: RillNav) {
    val ctx = LocalContext.current
    val c = IOS.colors
    val view = LocalView.current
    var clock by remember { mutableLongStateOf(0L) }
    var confirm by remember { mutableStateOf(false) }
    DisposableEffect(Unit) { view.keepScreenOn = true; onDispose { view.keepScreenOn = false } }
    LaunchedEffect(Unit) { while (true) { kotlinx.coroutines.delay(1000); clock++ } }
    LaunchedEffect(clock) { if (!RunTracker.active && clock > 1) nav.back() }

    @Suppress("UNUSED_VARIABLE") val tickRead = clock   // reading it makes this screen recompose every second
    val paused = RunTracker.paused
    val age = System.currentTimeMillis() - RunTracker.lastFixMs
    val (gpsText, gpsColor) = when {
        paused -> Pair("Dijeda", c.textSecondary)
        RunTracker.lastFixMs == 0L -> Pair("GPS: mencari sinyal…", c.orange)
        age > 15000 -> Pair("GPS: sinyal hilang", c.red)
        RunTracker.accuracy <= 12f -> Pair("GPS: sangat baik", c.primaryText)
        RunTracker.accuracy <= 22f -> Pair("GPS: baik", c.primaryText)
        else -> Pair("GPS: cukup", c.orange)
    }
    val paceNow = if (!paused && RunTracker.curSpeed > 0.8f) Fmt.pace((1000f / RunTracker.curSpeed).roundToInt()) else "--:--"
    val paceAvg = if (RunTracker.distM > 50) Fmt.pace((RunTracker.movMs / 1000.0 / (RunTracker.distM / 1000.0)).roundToInt()) else "--:--"
    val st = RunTracker.steps()
    val steps = if (st > 0) "$st" else if (RunTracker.distM > 0) "≈${(RunTracker.distM / 0.9).toInt()}" else "0"
    val step = max(1, RunTracker.pts.size / 200)
    val route = RunTracker.pts.filterIndexed { i, _ -> i % step == 0 }.map { doubleArrayOf(it.lat, it.lng, it.mov / 1000.0) }

    ScreenScaffold(title = "Merekam 🏃", onBack = { nav.back() }, subtitle = "Rekaman tetap berjalan jika kamu keluar dari layar ini") {
        item {
            Text(gpsText, style = IOSType.caption, color = gpsColor, modifier = Modifier.padding(start = 4.dp))
            Text(Fmt.dur(RunTracker.elapsedMs()), style = IOSType.number.copy(fontSize = 56.sp), color = c.textPrimary, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                BigTile("jarak (km)", Fmt.km(RunTracker.distM), Modifier.weight(1f))
                BigTile("pace sekarang /km", paceNow, Modifier.weight(1f))
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                BigTile("pace rata-rata /km", paceAvg, Modifier.weight(1f))
                BigTile("langkah", steps, Modifier.weight(1f))
            }
        }
        item {
            AndroidView(factory = { RouteView(it) }, update = { it.setRoute(route) }, modifier = Modifier.fillMaxWidth().height(220.dp))
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlineButton(if (paused) "Lanjutkan" else "Jeda", Modifier.weight(1f)) { if (paused) RunTracker.resume() else RunTracker.pause(); clock++ }
                PrimaryButton("Selesai", Modifier.weight(1f)) { confirm = true }
            }
        }
    }

    if (confirm) ConfirmDialog("Selesaikan jogging?", "Rekaman akan disimpan ke riwayatmu.", "Selesai", {
        confirm = false
        val rec = RunTracker.buildRecord(ctx)
        RunService.send(ctx, RunService.ACTION_STOP)
        RunTracker.reset()
        ctx.getSharedPreferences("rill_data", Context.MODE_PRIVATE).edit().remove("run_active_start").apply()
        if (rec.distM < 50.0) {
            RunTracker.activeFile(ctx).delete()
            Toast.makeText(ctx, "Jaraknya terlalu pendek, rekaman dibuang.", Toast.LENGTH_LONG).show()
            nav.back()
        } else {
            RunStore.attachTrack(ctx, rec.id)
            RunStore.add(ctx, rec)
            // tick today's matching habit ("jogging" / "lari") automatically
            val snap = TodayData.snapshot(ctx)
            val hits = snap.tasks.filter { !snap.done.contains(it.id) && (it.name.lowercase(Locale.ROOT).contains("jog") || it.name.lowercase(Locale.ROOT).contains("lari")) }
            hits.forEach { TodayData.setDone(ctx, it.id, true) }
            if (hits.isNotEmpty()) Toast.makeText(ctx, "Kegiatan \"${hits[0].name}\" dicentang otomatis ✅", Toast.LENGTH_LONG).show()
            nav.replace(RillRoutes.jogSum(rec.id), RillRoutes.JOG_LIVE)
        }
    }, { confirm = false })
}

@Composable
private fun BigTile(label: String, value: String, modifier: Modifier) {
    val c = IOS.colors
    IOSCard(modifier) {
        Text(value, style = IOSType.title.copy(fontSize = 28.sp), color = c.textPrimary, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
        Text(label, style = IOSType.caption, color = c.textSecondary, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
    }
}

// ============================ SUMMARY ============================
@Composable
fun JoggingSummaryScreen(nav: RillNav, id: Long) {
    val ctx = LocalContext.current
    val c = IOS.colors
    val r: RunRecord? = remember(id) { RunStore.load(ctx).find { it.id == id } }
    var confirmDelete by remember { mutableStateOf(false) }
    val gpxLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/gpx+xml")) { uri ->
        if (uri != null && r != null) {
            try {
                ctx.contentResolver.openOutputStream(uri)?.use { it.write(RunStore.gpx(ctx, r).toByteArray(Charsets.UTF_8)) }
                Toast.makeText(ctx, "GPX tersimpan ✅", Toast.LENGTH_LONG).show()
            } catch (_: Exception) { Toast.makeText(ctx, "Gagal menyimpan GPX.", Toast.LENGTH_LONG).show() }
        }
    }
    if (r == null) {
        ScreenScaffold("Rekaman tidak ditemukan", { nav.back() }) { item { EmptyState("👟", "Rekaman sudah dihapus", "Kembali ke riwayat jogging.") } }
        return
    }
    val pts = remember(id) { RunStore.parseRoute(r.route) }
    val bestKm = r.splits.filter { it > 0 }.minOrNull()
    val partialPace = if (r.partialM >= 100 && r.partialSec > 0) (r.partialSec * 1000.0 / r.partialM).roundToInt() else null
    val fastest = (r.splits + listOfNotNull(partialPace)).filter { it > 0 }.minOrNull() ?: 1

    ScreenScaffold(title = "Jogging", onBack = { nav.back() }, subtitle = dateText(r.start)) {
        item { AndroidView(factory = { RouteView(it) }, update = { it.setRoute(pts) }, modifier = Modifier.fillMaxWidth().height(260.dp)) }
        item {
            IOSCard {
                Text("${Fmt.km(r.distM)} km", style = IOSType.number.copy(fontSize = 40.sp), color = c.primaryText, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                Text("${Fmt.dur(r.durMs)} total · pace ${Fmt.pace(r.avgPaceSec)}/km", style = IOSType.body, color = c.textSecondary, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                BigTile("⏱️ waktu bergerak", Fmt.dur(r.movMs), Modifier.weight(1f))
                BigTile("⚡ ${if (bestKm != null) "pace km tercepat" else "pace rata-rata"}", Fmt.pace(bestKm ?: r.avgPaceSec), Modifier.weight(1f))
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                BigTile(if (r.stepsEst) "👟 langkah (perkiraan)" else "👟 langkah", "${if (r.stepsEst) "≈" else ""}${r.steps}", Modifier.weight(1f))
                BigTile("🥁 langkah/menit", if (r.cadence > 0) "${r.cadence}" else "--", Modifier.weight(1f))
            }
        }
        item { SectionTitle("Pace tiap kilometer") }
        if (r.splits.isEmpty() && r.partialM < 100) item { Text("Belum ada satu kilometer penuh.", style = IOSType.body, color = c.textSecondary, modifier = Modifier.padding(horizontal = 4.dp)) }
        else item {
            IOSCard {
                @Composable
                fun row(label: String, sec: Int) {
                    val pct = if (sec <= 0) 0f else (fastest.toFloat() / sec).coerceIn(0.08f, 1f)
                    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(label, style = IOSType.caption, color = c.textPrimary, modifier = Modifier.size(width = 58.dp, height = 18.dp))
                        Box(Modifier.weight(1f).padding(horizontal = 8.dp)) { ThinBar(pct, if (sec == fastest) c.primary else c.orange) }
                        Text(Fmt.pace(sec), style = IOSType.caption, color = c.textPrimary, textAlign = TextAlign.End, modifier = Modifier.size(width = 44.dp, height = 18.dp))
                    }
                }
                r.splits.forEachIndexed { i, s -> row("Km ${i + 1}", s) }
                if (partialPace != null) row(String.format(Locale.US, "%.2f km", r.partialM / 1000.0), partialPace)
                Text("Hijau = km tercepat · Pace dihitung dari waktu bergerak.", style = IOSType.caption, color = c.textSecondary, modifier = Modifier.padding(top = 6.dp))
            }
        }
        if (pts.isNotEmpty()) item {
            OutlineButton("Buka lokasi di aplikasi Peta") {
                try { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("geo:${pts[0][0]},${pts[0][1]}?z=16"))) } catch (_: Exception) { Toast.makeText(ctx, "Tidak ada aplikasi peta.", Toast.LENGTH_LONG).show() }
            }
        }
        item {
            OutlineButton("Ekspor GPX (untuk Strava dll.)") {
                try { gpxLauncher.launch("jogging-${SimpleDateFormat("yyyy-MM-dd-HHmm", Locale.US).format(Date(r.start))}.gpx") } catch (_: Exception) { Toast.makeText(ctx, "Tidak ada aplikasi file.", Toast.LENGTH_LONG).show() }
            }
        }
        item { OutlineButton("Hapus rekaman") { confirmDelete = true } }
    }
    if (confirmDelete) ConfirmDialog("Hapus rekaman ini?", "Rekaman jogging ini akan dihapus permanen.", "Hapus", { RunStore.delete(ctx, r.id); confirmDelete = false; nav.back() }, { confirmDelete = false })
}
