package com.airil.rillrebirth.ui.components

import android.content.Context
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.os.Vibrator
import android.widget.Toast
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.gestures.snapping.rememberSnapFlingBehavior
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.airil.rillrebirth.ui.theme.IOS
import kotlin.math.abs

/** Short "tek" click used while turning a wheel. */
class TickSound {
    private var track: AudioTrack? = null

    private fun build(): AudioTrack? = try {
        val sr = 22050
        val n = (sr * 0.03).toInt()
        val data = ShortArray(n)
        for (i in 0 until n) {
            val sec = i.toDouble() / sr
            val env = Math.exp(-sec * 170.0)
            val v = Math.sin(2 * Math.PI * 1500 * sec) * 0.7 + Math.sin(2 * Math.PI * 3100 * sec) * 0.3
            data[i] = (v * env * 30000).toInt().toShort()
        }
        val tr = AudioTrack(AudioManager.STREAM_MUSIC, sr, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT, n * 2, AudioTrack.MODE_STATIC)
        tr.write(data, 0, n)
        tr.setVolume(1.0f)
        tr
    } catch (_: Exception) { null }

    fun tick() {
        try {
            val tr = track ?: build().also { track = it } ?: return
            tr.stop(); tr.reloadStaticData(); tr.play()
        } catch (_: Exception) { }
    }

    fun release() { try { track?.release() } catch (_: Exception) { }; track = null }
}

object Sounds {
    /** Loud triple "TET!" on the alarm stream plus vibration. */
    fun playTet(ctx: Context) {
        Thread {
            try {
                val sr = 22050
                val toneSamples = (sr * 0.16).toInt()
                val silence = (sr * 0.09).toInt()
                val bursts = 3
                val data = ShortArray((toneSamples + silence) * bursts)
                var idx = 0
                for (b in 0 until bursts) {
                    for (i in 0 until toneSamples) {
                        val t = i.toDouble() / sr
                        val env = if (i < 200) i / 200.0 else if (i > toneSamples - 300) (toneSamples - i) / 300.0 else 1.0
                        val s = Math.sin(2 * Math.PI * 1900 * t) + 0.5 * Math.sin(2 * Math.PI * 3800 * t)
                        data[idx++] = (Math.max(-1.0, Math.min(1.0, s * 0.95)) * env * 32000).toInt().toShort()
                    }
                    for (i in 0 until silence) data[idx++] = 0
                }
                val track = AudioTrack(AudioManager.STREAM_ALARM, sr, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT, data.size * 2, AudioTrack.MODE_STATIC)
                track.write(data, 0, data.size)
                track.setVolume(1.0f)
                track.play()
                Thread.sleep((data.size * 1000L) / sr + 250)
                track.release()
            } catch (_: Exception) { }
        }.start()
        try { (ctx.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator).vibrate(longArrayOf(0, 220, 120, 220, 120, 220), -1) } catch (_: Exception) { }
    }
}

/** Rest/free timer that keeps running while you move between screens. */
object TimerEngine {
    var configured by mutableLongStateOf(60L)
    var remaining by mutableLongStateOf(60L)
    var state by mutableIntStateOf(0)            // 0 idle, 1 running, 2 paused
    var finishedCount by mutableIntStateOf(0)
    var extra by mutableLongStateOf(0L)          // seconds added with +30 while running (reset on stop / finish)
    private var endAt = 0L
    private var app: Context? = null
    private val handler = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            if (state != 1) return
            remaining = ((endAt - SystemClock.elapsedRealtime() + 999) / 1000).coerceAtLeast(0)
            if (remaining <= 0) finish() else handler.postDelayed(this, 200)
        }
    }

    fun init(c: Context) {
        app = c.applicationContext
        if (state == 0) {
            configured = c.getSharedPreferences("rill_data", Context.MODE_PRIVATE).getLong("rest_seconds", 60L).coerceIn(1L, 5999L)
            remaining = configured
        }
    }

    fun configure(sec: Long) {
        configured = sec.coerceIn(1L, 5999L)
        if (state == 0) remaining = configured
        app?.getSharedPreferences("rill_data", Context.MODE_PRIVATE)?.edit()?.putLong("rest_seconds", configured)?.apply()
    }

    fun start() {
        if (remaining <= 0) remaining = configured
        state = 1
        endAt = SystemClock.elapsedRealtime() + remaining * 1000
        handler.removeCallbacks(tick); handler.post(tick)
    }

    fun pause() { state = 2; handler.removeCallbacks(tick) }
    fun stop() { state = 0; handler.removeCallbacks(tick); extra = 0L; remaining = configured }

    /** Adds time to a running or paused timer without touching the saved duration. */
    fun extend(sec: Long) {
        if (state == 0) return
        val newRem = (remaining + sec).coerceAtMost(5999L)
        val delta = newRem - remaining
        if (delta <= 0L) return
        remaining = newRem; extra += delta
        if (state == 1) endAt += delta * 1000
    }

    private fun finish() {
        state = 0; extra = 0L; remaining = configured
        app?.let { Sounds.playTet(it); Toast.makeText(it, "⏰ Waktu timer selesai!", Toast.LENGTH_LONG).show() }
        finishedCount++
    }
}

/** Scroll-to-pick number wheel (00..count-1) with a tick sound and haptics. */
@Composable
fun WheelPicker(count: Int, value: Int, modifier: Modifier = Modifier, onValueChange: (Int) -> Unit) {
    val c = IOS.colors
    val density = LocalDensity.current
    val itemH = 52.dp
    val itemPx = with(density) { itemH.toPx() }
    val state = rememberLazyListState(initialFirstVisibleItemIndex = value.coerceIn(0, count - 1))
    val snap = rememberSnapFlingBehavior(state)
    val selected by remember {
        derivedStateOf { (state.firstVisibleItemIndex + (if (state.firstVisibleItemScrollOffset > itemPx / 2) 1 else 0)).coerceIn(0, count - 1) }
    }
    val tick = remember { TickSound() }
    val haptic = LocalHapticFeedback.current
    DisposableEffect(Unit) { onDispose { tick.release() } }
    var first by remember { mutableStateOf(true) }
    LaunchedEffect(selected) {
        if (first) first = false else { tick.tick(); haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove) }
        onValueChange(selected)
    }
    LazyColumn(
        state = state, flingBehavior = snap,
        modifier = modifier.height(itemH * 5).width(88.dp),
        contentPadding = PaddingValues(vertical = itemH * 2)
    ) {
        items(count) { i ->
            val d = abs(i - selected)
            Box(Modifier.height(itemH).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Text(
                    String.format("%02d", i),
                    color = if (d == 0) c.primaryText else c.textSecondary.copy(alpha = if (d == 1) 0.65f else 0.3f),
                    fontSize = if (d == 0) 36.sp else 24.sp,
                    fontWeight = if (d == 0) FontWeight.Bold else FontWeight.Normal
                )
            }
        }
    }
}
