package com.airil.rillrebirth.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.key
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import com.airil.rillrebirth.WorkoutExercise
import com.airil.rillrebirth.WorkoutStore
import com.airil.rillrebirth.ui.components.GuideSheet
import com.airil.rillrebirth.ui.components.IOSCard
import com.airil.rillrebirth.ui.components.iosPress
import com.airil.rillrebirth.ui.components.OutlineButton
import com.airil.rillrebirth.ui.components.PrimaryButton
import com.airil.rillrebirth.ui.components.RillNav
import com.airil.rillrebirth.ui.components.ScreenScaffold
import com.airil.rillrebirth.ui.components.SegmentRing
import com.airil.rillrebirth.ui.components.TimerEngine
import com.airil.rillrebirth.ui.components.WheelPicker
import com.airil.rillrebirth.ui.theme.IOS
import com.airil.rillrebirth.ui.theme.IOSType
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Free timer (flow = -1) or the rest timer between exercises (flow = workout id). */
@Composable
fun TimerScreen(nav: RillNav, flow: Long) {
    val ctx = LocalContext.current
    val c = IOS.colors
    val e = TimerEngine
    val view = LocalView.current
    DisposableEffect(e.state) { view.keepScreenOn = e.state == 1; onDispose { view.keepScreenOn = false } }

    var seen by remember { mutableIntStateOf(e.finishedCount) }
    LaunchedEffect(e.finishedCount) {
        if (e.finishedCount != seen) { seen = e.finishedCount; if (flow >= 0) nav.back() }
    }

    var mins by remember { mutableIntStateOf((e.configured / 60).toInt().coerceIn(0, 99)) }
    var secs by remember { mutableIntStateOf((e.configured % 60).toInt()) }
    var guide by remember { mutableStateOf<String?>(null) }
    var wheelKey by remember { mutableIntStateOf(0) }

    val next: WorkoutExercise? = remember(flow) {
        if (flow < 0) null else {
            val s = WorkoutStore.load(ctx).find { it.id == flow }
            if (s == null) null else {
                val checked = WorkoutStore.exerciseChecks(ctx, flow)
                val idx = (0 until s.exercises.size).firstOrNull { !checked.contains(it) }
                if (idx == null) null else s.exercises[idx]
            }
        }
    }

    ScreenScaffold(title = if (flow >= 0) "Istirahat" else "Timer", onBack = { nav.back() }) {
        if (next != null) {
            item {
                Text(
                    "Berikutnya: ${next.name} · ${next.sets} set × ${next.reps} — ketuk untuk panduan",
                    style = IOSType.body, color = c.textSecondary,
                    modifier = Modifier.padding(horizontal = 4.dp).fillMaxWidth().clickableNoRipple { guide = next.name }
                )
            }
        }
        item {
            IOSCard(corner = 28.dp) {
                Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                    if (e.state == 0) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
                            key(wheelKey) {
                                WheelPicker(100, mins) { mins = it; e.configure((mins * 60 + secs).toLong().coerceAtLeast(1L)) }
                                Text(":", style = IOSType.number, color = c.primaryText, modifier = Modifier.width(24.dp))
                                WheelPicker(60, secs) { secs = it; e.configure((mins * 60 + secs).toLong().coerceAtLeast(1L)) }
                            }
                        }
                        Text("menit  ·  detik", style = IOSType.caption, color = c.textSecondary)
                        val current = mins * 60 + secs
                        Row(Modifier.fillMaxWidth().padding(top = 14.dp, bottom = 16.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf(30 to "30 dtk", 60 to "1 mnt", 120 to "2 mnt", 300 to "5 mnt", 600 to "10 mnt").forEach { (sec, label) ->
                                val on = current == sec
                                Box(
                                    Modifier.weight(1f).height(36.dp).clip(RoundedCornerShape(50))
                                        .background(if (on) c.primarySoft else c.track.copy(alpha = if (c.dark) 0.6f else 0.7f))
                                        .semantics { contentDescription = "Atur $label" }
                                        .iosPress(Role.Button) {
                                            mins = sec / 60; secs = sec % 60
                                            e.configure(sec.toLong()); wheelKey++
                                        },
                                    contentAlignment = Alignment.Center
                                ) { Text(label, style = IOSType.caption.copy(fontSize = 12.sp), color = if (on) c.primaryText else c.textPrimary, maxLines = 1) }
                            }
                        }
                        PrimaryButton("Mulai") { e.configure((mins * 60 + secs).toLong().coerceAtLeast(1L)); e.start() }
                    } else {
                        val total = (e.configured + e.extra).coerceAtLeast(1L)
                        val frac = ((total - e.remaining).toFloat() / total).coerceIn(0f, 1f)
                        val urgent = e.state == 1 && e.remaining <= 10
                        val ringColor = when { urgent -> c.red; e.state == 2 -> c.textSecondary.copy(alpha = 0.7f); else -> c.orange }
                        SegmentRing(listOf(frac to ringColor), Modifier.size(250.dp), 14.dp) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    String.format(Locale.US, "%02d:%02d", e.remaining / 60, e.remaining % 60),
                                    style = IOSType.number.copy(fontSize = 54.sp), color = if (urgent) c.red else c.textPrimary
                                )
                                Text(
                                    if (e.state == 1) "berjalan" else "dijeda",
                                    style = IOSType.caption.copy(fontSize = 12.sp), color = if (e.state == 1) c.primaryText else c.textSecondary,
                                    modifier = Modifier.padding(top = 2.dp).clip(RoundedCornerShape(50))
                                        .background((if (e.state == 1) c.primarySoft else c.track.copy(alpha = 0.7f)))
                                        .padding(horizontal = 10.dp, vertical = 3.dp)
                                )
                                if (e.state == 1) Text(
                                    "Selesai pukul " + SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(System.currentTimeMillis() + e.remaining * 1000)),
                                    style = IOSType.caption, color = c.textSecondary, modifier = Modifier.padding(top = 6.dp)
                                )
                            }
                        }
                        Spacer(Modifier.height(20.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                            CircleAction("Berhenti", 72.dp, filled = false) { e.stop() }
                            CircleAction(if (e.state == 1) "Jeda" else "Lanjut", 88.dp, filled = true) { if (e.state == 1) e.pause() else e.start() }
                            CircleAction("+30 dtk", 72.dp, filled = false) { e.extend(30L) }
                        }
                        Spacer(Modifier.height(4.dp))
                    }
                }
            }
        }
    }
    guide?.let { GuideSheet(it) { guide = null } }
}

private fun Modifier.clickableNoRipple(onClick: () -> Unit): Modifier = this.then(
    Modifier.clickable(
        interactionSource = androidx.compose.foundation.interaction.MutableInteractionSource(),
        indication = null, onClick = onClick
    )
)

/** Round action button with a text label (outlined or filled). */
@Composable
private fun CircleAction(label: String, size: Dp, filled: Boolean, onClick: () -> Unit) {
    val c = IOS.colors
    val bg = if (filled) (if (c.dark) c.primary else c.primaryText) else Color.Transparent
    val fg = if (filled) (if (c.dark) Color(0xFF10261A) else Color.White) else c.primaryText
    Box(
        Modifier.size(size).clip(CircleShape).background(bg)
            .then(if (filled) Modifier else Modifier.border(1.5.dp, c.primaryText, CircleShape))
            .iosPress(Role.Button, onClick),
        contentAlignment = Alignment.Center
    ) { Text(label, style = IOSType.headline.copy(fontSize = 15.sp), color = fg) }
}
