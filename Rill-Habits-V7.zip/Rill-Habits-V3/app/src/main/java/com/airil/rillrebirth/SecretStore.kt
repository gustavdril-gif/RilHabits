package com.airil.rillrebirth

import android.content.Context
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import kotlin.math.PI
import kotlin.math.sin

data class SecStats(val total: Int, val streak: Int, val best: Int, val fails: Int, val lastStatus: String)
data class SecretTrack(val name: String, val file: String)

/** All "Ruang Tenang" data lives under keys that start with "sec_" in the app's single preferences file. */
object SecretStore {
    const val PREFIX = "sec_"
    const val DEFAULT_CODE = "AG589"
    val MILESTONES = listOf(1, 3, 7, 14, 30, 60, 90, 180, 365)

    private val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    private fun prefs(c: Context) = c.getSharedPreferences("rill_data", Context.MODE_PRIVATE)

    // ---- access ----
    fun code(c: Context): String = prefs(c).getString("sec_code", DEFAULT_CODE) ?: DEFAULT_CODE
    fun setCode(c: Context, v: String) { prefs(c).edit().putString("sec_code", v.trim()).apply() }
    fun matches(c: Context, typed: String): Boolean = typed.trim().equals(code(c), ignoreCase = true)

    // ---- journey ----
    fun introDone(c: Context) = prefs(c).getBoolean("sec_intro_done", false)
    fun markIntroDone(c: Context) {
        val e = prefs(c).edit().putBoolean("sec_intro_done", true)
        if (!prefs(c).contains("sec_first")) e.putString("sec_first", today())
        e.apply()
    }
    fun firstDate(c: Context): String = prefs(c).getString("sec_first", today()) ?: today()
    fun today(): String = fmt.format(Date())
    fun checkinHour(c: Context) = prefs(c).getInt("sec_checkin_hour", 18)
    fun setCheckinHour(c: Context, h: Int) { prefs(c).edit().putInt("sec_checkin_hour", h.coerceIn(0, 23)).apply() }
    fun reason(c: Context): String = prefs(c).getString("sec_reason", "") ?: ""
    fun setReason(c: Context, v: String) { prefs(c).edit().putString("sec_reason", v.trim()).apply() }
    fun urges(c: Context) = prefs(c).getInt("sec_urges", 0)
    fun addUrge(c: Context) { prefs(c).edit().putInt("sec_urges", urges(c) + 1).apply() }

    fun readLog(c: Context): MutableMap<String, String> {
        val out = mutableMapOf<String, String>()
        try {
            val o = JSONObject(prefs(c).getString("sec_log", "{}") ?: "{}")
            val it = o.keys()
            while (it.hasNext()) { val k = it.next(); out[k] = o.optString(k) }
        } catch (_: Exception) { }
        return out
    }

    fun setStatus(c: Context, date: String, status: String) {
        val log = readLog(c); log[date] = status
        val o = JSONObject(); log.forEach { (k, v) -> o.put(k, v) }
        prefs(c).edit().putString("sec_log", o.toString()).apply()
    }

    private fun epochDay(date: String): Long {
        val t = try { fmt.parse(date)?.time ?: 0L } catch (_: Exception) { 0L }
        return Math.floorDiv(t + TimeZone.getDefault().getOffset(t), 86400000L)
    }

    fun stats(c: Context): SecStats {
        val log = readLog(c)
        val keys = log.keys.sorted()
        val total = log.values.count { it == "s" }
        val fails = log.values.count { it == "f" }
        var best = 0; var run = 0; var prevDay = Long.MIN_VALUE
        keys.forEach { k ->
            val day = epochDay(k)
            if (log[k] == "s") {
                run = if (run > 0 && day == prevDay + 1) run + 1 else 1
                if (run > best) best = run
            } else run = 0
            prevDay = day
        }
        var streak = 0
        if (keys.isNotEmpty()) {
            var idx = keys.size - 1
            var expect = epochDay(keys[idx])
            while (idx >= 0 && log[keys[idx]] == "s" && epochDay(keys[idx]) == expect) { streak++; idx--; expect-- }
        }
        return SecStats(total, streak, best, fails, if (keys.isEmpty()) "" else (log[keys.last()] ?: ""))
    }

    /** Dates that still need an answer: every day from the start up to yesterday, plus today once the check-in hour has passed. */
    fun pendingDates(c: Context): List<String> {
        val log = readLog(c)
        val out = mutableListOf<String>()
        val cal = Calendar.getInstance()
        val start = try { fmt.parse(firstDate(c)) } catch (_: Exception) { null } ?: return out
        val cur = Calendar.getInstance().apply { time = start }
        val todayKey = today()
        val showToday = cal.get(Calendar.HOUR_OF_DAY) >= checkinHour(c)
        var guard = 0
        while (guard++ < 800) {
            val k = fmt.format(cur.time)
            if (k > todayKey) break
            if (k < todayKey || showToday) if (!log.containsKey(k)) out.add(k)
            cur.add(Calendar.DAY_OF_YEAR, 1)
        }
        return out
    }

    fun recentFails(c: Context, days: Int): Int {
        val log = readLog(c)
        val cal = Calendar.getInstance()
        var n = 0
        for (i in 0 until days) { if (log[fmt.format(cal.time)] == "f") n++; cal.add(Calendar.DAY_OF_YEAR, -1) }
        return n
    }

    /** Growth stage of the plant (0..7) from total clean days; it never goes backwards after a slip. */
    fun stageFor(total: Int): Int = when {
        total < 4 -> 0; total < 15 -> 1; total < 31 -> 2; total < 61 -> 3
        total < 91 -> 4; total < 181 -> 5; total < 366 -> 6; else -> 7
    }

    // ---- triggers (optional notes after a slip) ----
    fun addTrigger(c: Context, date: String, note: String) {
        if (note.isBlank()) return
        val a = try { JSONArray(prefs(c).getString("sec_triggers", "[]") ?: "[]") } catch (_: Exception) { JSONArray() }
        a.put(JSONObject().put("d", date).put("n", note.trim()))
        prefs(c).edit().putString("sec_triggers", a.toString()).apply()
    }
    fun triggers(c: Context, last: Int): List<Pair<String, String>> {
        val out = mutableListOf<Pair<String, String>>()
        try { val a = JSONArray(prefs(c).getString("sec_triggers", "[]") ?: "[]"); for (i in 0 until a.length()) { val o = a.optJSONObject(i) ?: continue; out.add(Pair(o.optString("d"), o.optString("n"))) } } catch (_: Exception) { }
        return out.takeLast(last).reversed()
    }

    // ---- photos ----
    fun photoDir(c: Context): File = File(c.filesDir, "secret_photos").apply { mkdirs() }
    fun photos(c: Context): MutableList<String> {
        val out = mutableListOf<String>()
        try { val a = JSONArray(prefs(c).getString("sec_photos", "[]") ?: "[]"); for (i in 0 until a.length()) out.add(a.optString(i)) } catch (_: Exception) { }
        return out.filter { File(photoDir(c), it).exists() }.toMutableList()
    }
    private fun savePhotos(c: Context, list: List<String>) { prefs(c).edit().putString("sec_photos", JSONArray(list).toString()).apply() }
    fun addPhoto(c: Context, name: String) { val l = photos(c); l.add(0, name); savePhotos(c, l) }
    fun removePhoto(c: Context, name: String) { File(photoDir(c), name).delete(); savePhotos(c, photos(c).filter { it != name }) }

    // ---- music ----
    fun audioDir(c: Context): File = File(c.filesDir, "secret_audio").apply { mkdirs() }
    fun tracks(c: Context): MutableList<SecretTrack> {
        val out = mutableListOf<SecretTrack>()
        try {
            val a = JSONArray(prefs(c).getString("sec_tracks", "[]") ?: "[]")
            for (i in 0 until a.length()) { val o = a.optJSONObject(i) ?: continue; out.add(SecretTrack(o.optString("name"), o.optString("file"))) }
        } catch (_: Exception) { }
        return out.filter { File(audioDir(c), it.file).exists() }.toMutableList()
    }
    private fun saveTracks(c: Context, list: List<SecretTrack>) {
        val a = JSONArray(); list.forEach { a.put(JSONObject().put("name", it.name).put("file", it.file)) }
        prefs(c).edit().putString("sec_tracks", a.toString()).apply()
    }
    fun addTrack(c: Context, name: String, file: String) { val l = tracks(c); l.add(SecretTrack(name, file)); saveTracks(c, l) }
    fun removeTrack(c: Context, file: String) { File(audioDir(c), file).delete(); saveTracks(c, tracks(c).filter { it.file != file }) }
    fun volume(c: Context): Float = prefs(c).getFloat("sec_music_vol", 0.6f)
    fun setVolume(c: Context, v: Float) { prefs(c).edit().putFloat("sec_music_vol", v.coerceIn(0f, 1f)).apply() }

    /** Removes every "sec_" value and the private photo/audio folders. */
    fun wipe(c: Context) {
        val p = prefs(c); val ed = p.edit()
        p.all.keys.filter { it.startsWith(PREFIX) }.forEach { ed.remove(it) }
        ed.apply()
        photoDir(c).listFiles()?.forEach { it.delete() }
        audioDir(c).listFiles()?.forEach { it.delete() }
    }
}

/** The soft "something dropped into soil" sound, synthesised so no audio file is needed. */
object SecretSound {
    fun thud() {
        Thread {
            try {
                val sr = 22050
                val n = (sr * 0.5).toInt()
                val data = ShortArray(n)
                val rnd = java.util.Random(5)
                var ph = 0.0; var ph2 = 0.0
                for (i in 0 until n) {
                    val t = i.toDouble() / sr
                    ph += 2 * PI * (95.0 - 50.0 * (t / 0.5)) / sr
                    ph2 += 2 * PI * 190.0 / sr
                    val body = sin(ph) * Math.exp(-t * 9.0) + 0.35 * sin(ph2) * Math.exp(-t * 22.0)
                    val soil = (rnd.nextDouble() * 2 - 1) * Math.exp(-t * 38.0) * 0.45
                    data[i] = ((body * 0.85 + soil) * 26000).toInt().coerceIn(-32767, 32767).toShort()
                }
                val tr = AudioTrack(AudioManager.STREAM_MUSIC, sr, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT, n * 2, AudioTrack.MODE_STATIC)
                tr.write(data, 0, n)
                tr.setVolume(1.0f)
                tr.play()
                Thread.sleep(700)
                tr.release()
            } catch (_: Exception) { }
        }.start()
    }
}
