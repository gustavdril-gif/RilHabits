package com.airil.rillrebirth

import java.util.Calendar

data class ProgSession(val name: String, val days: List<Int>, val duration: Int, val exercises: List<WorkoutExercise>)
data class ReadyProgram(val emoji: String, val name: String, val level: String, val desc: String, val time: String, val sessions: List<ProgSession>)

object Programs {
    private const val MON = Calendar.MONDAY
    private const val TUE = Calendar.TUESDAY
    private const val WED = Calendar.WEDNESDAY
    private const val THU = Calendar.THURSDAY
    private const val FRI = Calendar.FRIDAY
    private const val SAT = Calendar.SATURDAY
    private const val SUN = Calendar.SUNDAY
    private fun e(name: String, sets: Int, reps: String) = WorkoutExercise(name, sets, reps)

    /** Quick-pick exercises for the schedule builder. */
    val library: List<WorkoutExercise> = listOf(
        e("Push Up", 3, "10"), e("Squat", 3, "12"), e("Lunges", 3, "10"), e("Plank", 3, "40 detik"),
        e("Pull Up", 3, "6"), e("Dumbbell Row", 3, "10"), e("Dumbbell Biceps Curl", 3, "10"), e("Hammer Curl", 3, "12"),
        e("Reverse Fly", 3, "12"), e("Dumbbell Shoulder Press", 3, "10"), e("Triceps Dips (kursi)", 3, "10"), e("Glute Bridge", 3, "15"),
        e("Calf Raise", 3, "15"), e("Romanian Deadlift", 3, "10"), e("Sit Up", 3, "15"), e("Leg Raise", 3, "12"),
        e("Mountain Climber", 3, "30 detik"), e("Jumping Jack", 3, "40 detik"), e("Burpee", 3, "8"), e("Jogging", 1, "20 menit"),
        e("Jalan cepat", 1, "15 menit"), e("Peregangan", 2, "30 detik")
    )

    val all: List<ReadyProgram> = listOf(
        ReadyProgram("🏃", "Jogging Pemula", "Pemula", "Interval jalan-lari yang ramah untuk memulai. 3x seminggu, naik pelan-pelan.", "16:30", listOf(
            ProgSession("Jogging Interval", listOf(MON, WED, SAT), 30, listOf(
                e("Pemanasan jalan cepat", 1, "5 menit"), e("Jogging 1 mnt + jalan 2 mnt", 6, "1 putaran"),
                e("Pendinginan jalan santai", 1, "5 menit"), e("Peregangan betis & paha", 2, "30 detik")))
        )),
        ReadyProgram("🏃‍♂️", "Jogging Stamina", "Menengah", "Bangun daya tahan: easy run, interval, dan long run. 4x seminggu.", "16:30", listOf(
            ProgSession("Easy Run", listOf(MON, FRI), 30, listOf(e("Pemanasan", 1, "5 menit"), e("Jogging santai", 1, "20 menit"), e("Pendinginan", 1, "5 menit"))),
            ProgSession("Interval Run", listOf(WED), 35, listOf(e("Pemanasan", 1, "5 menit"), e("Lari cepat 3 mnt + santai 2 mnt", 5, "1 putaran"), e("Pendinginan", 1, "5 menit"))),
            ProgSession("Long Run", listOf(SUN), 45, listOf(e("Pemanasan", 1, "5 menit"), e("Jogging stabil", 1, "35 menit"), e("Peregangan", 2, "30 detik")))
        )),
        ReadyProgram("💪", "Push Pull Legs", "Menengah", "Klasik 3 sesi: dorong, tarik, kaki. Cocok dengan dumbbell dan barbel pull up.", "18:00", listOf(
            ProgSession("Push Day", listOf(MON), 45, listOf(e("Push Up", 4, "10"), e("Dumbbell Shoulder Press", 3, "10"), e("Pike Push Up", 3, "8"), e("Triceps Dips (kursi)", 3, "10"), e("Dumbbell Triceps Extension", 3, "12"))),
            ProgSession("Pull Day", listOf(WED), 45, listOf(e("Pull Up", 3, "6"), e("Dumbbell Row", 3, "10"), e("Dumbbell Biceps Curl", 3, "10"), e("Hammer Curl", 2, "12"), e("Reverse Fly", 2, "12"))),
            ProgSession("Legs Day", listOf(FRI), 45, listOf(e("Squat", 4, "12"), e("Lunges", 3, "10"), e("Romanian Deadlift", 3, "10"), e("Glute Bridge", 3, "15"), e("Calf Raise", 4, "15")))
        )),
        ReadyProgram("🏋️", "Upper / Lower Split", "Menengah", "4 hari: badan atas dan bawah bergantian. Waktu pemulihan lebih lega.", "18:00", listOf(
            ProgSession("Upper Body", listOf(MON, THU), 45, listOf(e("Push Up", 4, "10"), e("Dumbbell Row", 4, "10"), e("Dumbbell Shoulder Press", 3, "10"), e("Dumbbell Biceps Curl", 3, "12"), e("Triceps Dips (kursi)", 3, "10"))),
            ProgSession("Lower Body", listOf(TUE, FRI), 45, listOf(e("Squat", 4, "12"), e("Romanian Deadlift", 3, "10"), e("Lunges", 3, "10"), e("Glute Bridge", 3, "15"), e("Calf Raise", 4, "15")))
        )),
        ReadyProgram("🔥", "Full Body 3x", "Pemula", "Seluruh badan di setiap sesi, 3x seminggu dengan hari istirahat di antaranya.", "18:00", listOf(
            ProgSession("Full Body", listOf(MON, WED, FRI), 40, listOf(e("Squat", 3, "12"), e("Push Up", 3, "10"), e("Dumbbell Row", 3, "10"), e("Glute Bridge", 3, "12"), e("Dumbbell Shoulder Press", 2, "10"), e("Plank", 3, "30 detik")))
        )),
        ReadyProgram("🏠", "Bodyweight Rumah", "Pemula", "Tanpa alat sama sekali. Aman dilakukan di kamar.", "17:00", listOf(
            ProgSession("Bodyweight Basics", listOf(MON, WED, FRI), 30, listOf(e("Squat", 3, "12"), e("Push Up (lutut jika perlu)", 3, "8"), e("Glute Bridge", 3, "12"), e("Lunges", 3, "8"), e("Plank", 3, "20 detik")))
        )),
        ReadyProgram("🎯", "Core & Abs 15 Menit", "Semua level", "Sesi singkat untuk perut dan punggung bawah. Pas untuk hari sibuk.", "19:00", listOf(
            ProgSession("Core 15", listOf(TUE, THU, SAT), 15, listOf(e("Plank", 3, "30 detik"), e("Sit Up", 3, "15"), e("Leg Raise", 3, "12"), e("Mountain Climber", 3, "30 detik"), e("Bird Dog", 2, "10")))
        )),
        ReadyProgram("⚡", "HIIT 20 Menit", "Menengah", "Intensitas tinggi, waktu singkat. 40 detik kerja, 20 detik istirahat.", "17:00", listOf(
            ProgSession("HIIT Cardio", listOf(MON, THU, SAT), 20, listOf(e("Jumping Jack", 4, "40 detik"), e("Squat Jump", 4, "40 detik"), e("Mountain Climber", 4, "40 detik"), e("High Knees", 4, "40 detik"), e("Burpee", 3, "8")))
        )),
        ReadyProgram("🧘", "Mobility & Stretching Pagi", "Semua level", "10 menit setiap pagi untuk melemaskan badan dan memperbaiki postur.", "06:00", listOf(
            ProgSession("Mobility Pagi", listOf(MON, TUE, WED, THU, FRI, SAT, SUN), 10, listOf(e("Cat-Cow", 2, "10"), e("Peregangan hamstring", 2, "30 detik"), e("Hip opener", 2, "30 detik"), e("Peregangan bahu", 2, "30 detik"), e("Child pose", 1, "45 detik")))
        )),
        ReadyProgram("🚶", "Jalan Sehat Harian", "Pemula", "Kebiasaan paling ringan: jalan kaki 20 menit setiap hari.", "16:00", listOf(
            ProgSession("Jalan Sehat", listOf(MON, TUE, WED, THU, FRI, SAT, SUN), 20, listOf(e("Jalan santai", 1, "5 menit"), e("Jalan cepat", 1, "10 menit"), e("Pendinginan", 1, "5 menit")))
        ))
    )
}
