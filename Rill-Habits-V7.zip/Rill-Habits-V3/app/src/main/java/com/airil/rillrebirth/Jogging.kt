package com.airil.rillrebirth

import android.Manifest
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

const val REQ_RUN = 4301
const val REQ_GPX = 4103

internal object RunUi {
    var tick: Runnable? = null
    var pendingGpxId = 0L
}

/** Draws a route as a pace-coloured line on a paper-map style background (no map tiles, works offline). */
class RouteView(context: Context) : View(context) {
    private val d = context.resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var pts: List<DoubleArray> = emptyList()
    private var seg: FloatArray = FloatArray(0)     // pace colour factor per segment 0 (slow) .. 1 (fast)
    private var cum: DoubleArray = DoubleArray(0)   // cumulative metres per point

    fun setRoute(route: List<DoubleArray>) {
        pts = route
        val n = route.size
        seg = FloatArray(max(0, n - 1)); cum = DoubleArray(n)
        if (n >= 2) {
            val kx = cos(Math.toRadians((route.minOf { it[0] } + route.maxOf { it[0] }) / 2))
            val speeds = DoubleArray(n - 1)
            for (i in 1 until n) {
                val dx = (route[i][1] - route[i - 1][1]) * kx * 111320.0
                val dy = (route[i][0] - route[i - 1][0]) * 110540.0
                val dm = Math.sqrt(dx * dx + dy * dy)
                cum[i] = cum[i - 1] + dm
                val dt = route[i][2] - route[i - 1][2]
                speeds[i - 1] = if (dt > 0) dm / dt else -1.0
            }
            val valid = speeds.filter { it > 0 }.sorted()
            if (valid.size >= 2) {
                val lo = valid[(valid.size * 0.1).toInt()]; val hi = valid[min(valid.size - 1, (valid.size * 0.9).toInt())]
                for (i in speeds.indices) seg[i] = if (speeds[i] <= 0 || hi <= lo) 0.5f else ((speeds[i] - lo) / (hi - lo)).coerceIn(0.0, 1.0).toFloat()
            } else for (i in seg.indices) seg[i] = 0.5f
        }
        invalidate()
    }

    private fun mix(a: Int, b: Int, t: Float): Int {
        val r = (Color.red(a) + (Color.red(b) - Color.red(a)) * t).toInt()
        val g = (Color.green(a) + (Color.green(b) - Color.green(a)) * t).toInt()
        val bl = (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * t).toInt()
        return Color.rgb(r, g, bl)
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        p.style = Paint.Style.FILL; p.color = 0xFFEAF4E4.toInt()
        c.drawRoundRect(0f, 0f, w, h, 18 * d, 18 * d, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = 1f * d; p.color = 0xFFD5E6CF.toInt()
        var gx = 36 * d; while (gx < w) { c.drawLine(gx, 0f, gx, h, p); gx += 36 * d }
        var gy = 36 * d; while (gy < h) { c.drawLine(0f, gy, w, gy, p); gy += 36 * d }
        if (pts.size < 2) {
            p.style = Paint.Style.FILL; p.color = 0xFF7C8F7C.toInt(); p.textSize = 13 * d; p.textAlign = Paint.Align.CENTER
            c.drawText("Rute muncul saat kamu mulai bergerak", w / 2, h / 2, p)
            return
        }
        val minLat = pts.minOf { it[0] }; val maxLat = pts.maxOf { it[0] }
        val minLng = pts.minOf { it[1] }; val maxLng = pts.maxOf { it[1] }
        val kx = cos(Math.toRadians((minLat + maxLat) / 2))
        val pad = 28 * d
        val spanX = max((maxLng - minLng) * kx, 1e-6); val spanY = max(maxLat - minLat, 1e-6)
        val scale = min((w - 2 * pad) / spanX, (h - 2 * pad) / spanY)
        val offX = (w - spanX * scale) / 2; val offY = (h - spanY * scale) / 2
        fun px(lng: Double) = (offX + (lng - minLng) * kx * scale).toFloat()
        fun py(lat: Double) = (h - (offY + (lat - minLat) * scale)).toFloat()
        p.strokeCap = Paint.Cap.ROUND; p.strokeJoin = Paint.Join.ROUND
        p.color = Color.WHITE; p.strokeWidth = 9 * d
        val path = Path(); path.moveTo(px(pts[0][1]), py(pts[0][0]))
        for (i in 1 until pts.size) path.lineTo(px(pts[i][1]), py(pts[i][0]))
        c.drawPath(path, p)
        p.strokeWidth = 5 * d
        for (i in 1 until pts.size) {
            p.color = mix(0xFFFF8A3D.toInt(), 0xFF3FAF54.toInt(), seg[i - 1])
            c.drawLine(px(pts[i - 1][1]), py(pts[i - 1][0]), px(pts[i][1]), py(pts[i][0]), p)
        }
        // km markers
        p.style = Paint.Style.FILL; p.textAlign = Paint.Align.CENTER; p.textSize = 9 * d
        var nextKm = 1
        for (i in 1 until pts.size) {
            if (cum[i] >= nextKm * 1000.0) {
                val x = px(pts[i][1]); val y = py(pts[i][0])
                p.color = Color.WHITE; c.drawCircle(x, y, 9 * d, p)
                p.color = 0xFF2E7D32.toInt(); c.drawText("$nextKm", x, y + 3.2f * d, p)
                nextKm++
            }
        }
        val s = pts.first(); val e = pts.last()
        p.color = Color.WHITE; c.drawCircle(px(s[1]), py(s[0]), 8 * d, p); c.drawCircle(px(e[1]), py(e[0]), 8 * d, p)
        p.color = 0xFF2E9E4F.toInt(); c.drawCircle(px(s[1]), py(s[0]), 5.5f * d, p)
        p.color = 0xFFE53935.toInt(); c.drawCircle(px(e[1]), py(e[0]), 5.5f * d, p)
    }
}

private fun dateText(ms: Long) = SimpleDateFormat("EEE, d MMM · HH:mm", Locale("id", "ID")).format(Date(ms))

/** Small card on the Workout tab. */
internal fun MainActivity.joggingEntryCard() {
    val c = card(14)
    c.addView(text("🏃 Jogging", 16f, true))
    val last = RunStore.load(this).firstOrNull()
    if (RunTracker.active) {
        c.background = shape(greenSoft, 20)
        c.addView(text("Sedang merekam · ${Fmt.km(RunTracker.distM)} km · ${Fmt.dur(RunTracker.elapsedMs())}", 13f, true, green))
        c.addView(button("Buka rekaman", true) { showRunLive() })
    } else {
        c.addView(hint(if (last == null) "Rekam jejak, pace tiap km, waktu, dan langkahmu. Berfungsi offline." else "Terakhir: ${Fmt.km(last.distM)} km · pace ${Fmt.pace(last.avgPaceSec)}/km · ${dateText(last.start)}"))
        c.addView(button("Buka Jogging", true) { showJogging() })
    }
    content.addView(c)
}

// ---------------- hub ----------------
internal fun MainActivity.showJogging() {
    screen = "run"; onTimerScreen = false; animating = true
    applyBackdrop(false)
    content.removeAllViews(); scrollView?.scrollTo(0, 0)
    content.addView(backLink("‹ Workout") { render(true) })
    content.addView(text("Jogging 🏃", 28f, true))

    if (RunTracker.active) {
        val c = card(16); c.background = shape(greenSoft, 20)
        c.addView(text("Jogging sedang direkam", 17f, true, green))
        c.addView(text("${Fmt.km(RunTracker.distM)} km · ${Fmt.dur(RunTracker.elapsedMs())}", 14f, false, subtle))
        c.addView(button("Buka rekaman", true) { showRunLive() })
        content.addView(c)
    } else {
        val rec = RunStore.recoverPoints(this)
        if (rec.size >= 2) {
            val c = card(16)
            c.addView(text("Rekaman terputus ditemukan", 16f, true, amberDark))
            c.addView(hint("${Fmt.km(rec.last().dist)} km sempat terekam sebelum aplikasi berhenti. Simpan sebagai jogging?"))
            c.addView(pair(button("Buang") {
                RunTracker.activeFile(this).delete(); showJogging()
            }, button("Simpan", true) {
                val start = getSharedPreferences("rill_data", Context.MODE_PRIVATE).getLong("run_active_start", rec.first().t)
                val r = RunStore.recordFrom(this, start, rec.last().t - start, rec.last().mov, rec.last().dist, rec, 0, true)
                RunStore.attachTrack(this, r.id); RunStore.add(this, r); showRunSummary(r, false)
            }))
            content.addView(c)
        }
        val c = card(16)
        c.addView(text("Siap lari?", 18f, true))
        c.addView(hint("Berdiri di tempat terbuka sampai GPS terkunci (±20 detik), lalu mulai. Rekaman tetap berjalan saat layar mati."))
        c.addView(button("Mulai Jogging", true) { requestStartRun() })
        val beep = prefs().getBoolean("run_beep", true)
        c.addView(pair(button("Bunyi tiap km: ${if (beep) "Aktif" else "Mati"}") { prefs().edit().putBoolean("run_beep", !beep).apply(); showJogging() }, button("Tips rekaman") { showRunTips() }))
        content.addView(c)
    }

    val runs = RunStore.load(this)
    val weekStart = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0); add(Calendar.DAY_OF_YEAR, -((get(Calendar.DAY_OF_WEEK) + 5) % 7)) }.timeInMillis
    val monthStart = Calendar.getInstance().apply { set(Calendar.DAY_OF_MONTH, 1); set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }.timeInMillis
    val w = runs.filter { it.start >= weekStart }; val m = runs.filter { it.start >= monthStart }
    content.addView(tileRow(
        statTile("📅", Fmt.km(w.sumOf { it.distM }), "km minggu ini", "${w.size} lari"),
        statTile("🗓️", Fmt.km(m.sumOf { it.distM }), "km bulan ini", "${m.size} lari")
    ))
    val bestPace = runs.filter { it.distM >= 1000 }.minOfOrNull { it.avgPaceSec } ?: 0
    if (runs.isNotEmpty()) content.addView(tileRow(
        statTile("⚡", Fmt.pace(bestPace), "pace terbaik", "per km (≥ 1 km)"),
        statTile("🏁", Fmt.km(runs.maxOf { it.distM }), "lari terjauh", "km")
    ))
    section("Riwayat")
    if (runs.isEmpty()) content.addView(hint("Belum ada rekaman. Lari pertamamu akan muncul di sini."))
    else {
        val list = listCard()
        runs.take(30).forEachIndexed { i, r ->
            list.addView(listItem("${dateText(r.start)} · ${Fmt.km(r.distM)} km", "${Fmt.dur(r.movMs)} · pace ${Fmt.pace(r.avgPaceSec)}/km") { showRunSummary(r, false) })
            if (i < minOf(runs.size, 30) - 1) list.addView(View(this).apply { setBackgroundColor(line); layoutParams = LinearLayout.LayoutParams(-1, dp(1)) })
        }
        content.addView(list)
    }
}

private fun MainActivity.showRunTips() {
    AlertDialog.Builder(this, R.style.RillDialog).setTitle("Agar rekaman tidak terputus")
        .setMessage("Di HP Xiaomi/Redmi, sistem sering mematikan aplikasi di latar belakang. Cek ini sekali saja:\n\n1. Pengaturan → Aplikasi → Rill Habits → Penghemat baterai → Tanpa batasan.\n2. Aktifkan Mulai otomatis.\n3. Izin → Lokasi → pilih \"Izinkan sepanjang waktu\" atau \"Saat aplikasi digunakan\".\n4. Kunci aplikasi di layar aplikasi terbaru (tahan kartunya lalu ketuk gembok).\n5. Nyalakan Lokasi dengan akurasi tinggi (GPS).\n\nJika sesi sempat terputus, bagian yang sudah terekam bisa dipulihkan di halaman ini.")
        .setPositiveButton("Mengerti", null)
        .setNeutralButton("Buka pengaturan aplikasi") { _, _ ->
            try { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))) } catch (_: Exception) { }
        }.show()
}

// ---------------- start / permissions ----------------
internal fun MainActivity.requestStartRun() {
    val need = mutableListOf<String>()
    if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) { need.add(Manifest.permission.ACCESS_FINE_LOCATION); need.add(Manifest.permission.ACCESS_COARSE_LOCATION) }
    if (Build.VERSION.SDK_INT >= 29 && checkSelfPermission(Manifest.permission.ACTIVITY_RECOGNITION) != PackageManager.PERMISSION_GRANTED) need.add(Manifest.permission.ACTIVITY_RECOGNITION)
    if (need.isNotEmpty()) { requestPermissions(need.toTypedArray(), REQ_RUN); return }
    checkGpsThenStart()
}

internal fun MainActivity.checkGpsThenStart() {
    val lm = getSystemService(Context.LOCATION_SERVICE) as android.location.LocationManager
    if (!lm.isProviderEnabled(android.location.LocationManager.GPS_PROVIDER)) {
        AlertDialog.Builder(this, R.style.RillDialog).setTitle("GPS mati").setMessage("Nyalakan Lokasi (GPS) dulu supaya jejakmu terekam.")
            .setPositiveButton("Buka pengaturan lokasi") { _, _ -> try { startActivity(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)) } catch (_: Exception) { } }
            .setNegativeButton("Batal", null).show()
        return
    }
    RunTracker.begin(this)
    RunService.send(this, RunService.ACTION_START)
    showRunLive()
}

internal fun MainActivity.onRunPermissionResult(grantResults: IntArray, permissions: Array<out String>) {
    val fineIdx = permissions.indexOf(Manifest.permission.ACCESS_FINE_LOCATION)
    val fineOk = if (fineIdx >= 0) grantResults.getOrNull(fineIdx) == PackageManager.PERMISSION_GRANTED else checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
    if (fineOk) checkGpsThenStart()
    else AlertDialog.Builder(this, R.style.RillDialog).setTitle("Izin lokasi dibutuhkan").setMessage("Tanpa izin lokasi, jejak dan pace tidak bisa direkam. Kamu bisa mengizinkannya di pengaturan aplikasi.")
        .setPositiveButton("Buka pengaturan") { _, _ -> try { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))) } catch (_: Exception) { } }
        .setNegativeButton("Batal", null).show()
}

// ---------------- live ----------------
internal fun MainActivity.showRunLive() {
    screen = "run_live"; onTimerScreen = false; animating = true
    applyBackdrop(false)
    window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    content.removeAllViews(); scrollView?.scrollTo(0, 0)
    content.addView(backLink("‹ Jogging (rekaman tetap berjalan)") { showJogging() })
    content.addView(text("Merekam 🏃", 28f, true))
    val gps = text("GPS: mencari sinyal…", 12f, true, amberDark).apply { setPadding(dp(12), dp(6), dp(12), dp(6)); background = shape(amberSoft, 14) }
    content.addView(gps)
    val timer = text("00:00", 56f, true).apply { gravity = Gravity.CENTER; setPadding(0, dp(10), 0, dp(2)) }
    content.addView(timer)
    content.addView(text("waktu", 12f, false, subtle).apply { gravity = Gravity.CENTER })
    fun big(label: String): Pair<LinearLayout, TextView> {
        val v = text("--", 26f, true).apply { gravity = Gravity.CENTER }
        val box = card(12).apply { gravity = Gravity.CENTER_HORIZONTAL }
        box.addView(v); box.addView(text(label, 11f, false, subtle).apply { gravity = Gravity.CENTER })
        return Pair(box, v)
    }
    val (dBox, dTv) = big("jarak (km)"); val (pBox, pTv) = big("pace sekarang /km")
    val (aBox, aTv) = big("pace rata-rata /km"); val (sBox, sTv) = big("langkah")
    fun two(a: View, b: View) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        addView(a, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(0, 0, dp(5), 0) })
        addView(b, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(5), 0, 0, 0) })
    }
    content.addView(two(dBox, pBox)); content.addView(two(aBox, sBox))
    val route = RouteView(this)
    content.addView(route, LinearLayout.LayoutParams(-1, dp(220)).apply { setMargins(0, dp(8), 0, dp(8)) })
    val pause = button(if (RunTracker.paused) "Lanjutkan" else "Jeda") { if (RunTracker.paused) RunTracker.resume() else RunTracker.pause() }
    val finish = button("Selesai", true) {
        AlertDialog.Builder(this, R.style.RillDialog).setTitle("Selesaikan jogging?").setPositiveButton("Selesai") { _, _ -> finishRun() }.setNegativeButton("Lanjut lari", null).show()
    }
    content.addView(pair(pause, finish))

    RunUi.tick?.let { handler.removeCallbacks(it) }
    var lastCount = -1
    val act = this
    val tick = object : Runnable {
        override fun run() {
            if (act.screen != "run_live" || !RunTracker.active) { act.window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON); return }
            timer.text = Fmt.dur(RunTracker.elapsedMs())
            dTv.text = Fmt.km(RunTracker.distM)
            pTv.text = if (!RunTracker.paused && RunTracker.curSpeed > 0.8f) Fmt.pace((1000f / RunTracker.curSpeed).roundToInt()) else "--:--"
            aTv.text = if (RunTracker.distM > 50) Fmt.pace((RunTracker.movMs / 1000.0 / (RunTracker.distM / 1000.0)).roundToInt()) else "--:--"
            val st = RunTracker.steps()
            sTv.text = if (st > 0) "$st" else if (RunTracker.distM > 0) "≈${(RunTracker.distM / 0.9).toInt()}" else "0"
            pause.text = if (RunTracker.paused) "Lanjutkan" else "Jeda"
            val age = System.currentTimeMillis() - RunTracker.lastFixMs
            val (gt, gc, gb) = when {
                RunTracker.paused -> Triple("Dijeda", subtle, Color.parseColor("#F2F2F7"))
                RunTracker.lastFixMs == 0L -> Triple("GPS: mencari sinyal…", amberDark, amberSoft)
                age > 15000 -> Triple("GPS: sinyal hilang", danger, dangerSoft)
                RunTracker.accuracy <= 12f -> Triple("GPS: sangat baik", green, greenSoft)
                RunTracker.accuracy <= 22f -> Triple("GPS: baik", green, greenSoft)
                else -> Triple("GPS: cukup", amberDark, amberSoft)
            }
            gps.text = gt; gps.setTextColor(gc); gps.background = shape(gb, 14)
            if (RunTracker.pts.size != lastCount) {
                lastCount = RunTracker.pts.size
                val step = max(1, RunTracker.pts.size / 200)
                route.setRoute(RunTracker.pts.filterIndexed { i, _ -> i % step == 0 }.map { doubleArrayOf(it.lat, it.lng, it.mov / 1000.0) })
            }
            handler.postDelayed(this, 1000)
        }
    }
    RunUi.tick = tick
    tick.run()
}

internal fun MainActivity.finishRun() {
    val rec = RunTracker.buildRecord(this)
    RunService.send(this, RunService.ACTION_STOP)
    RunTracker.reset()
    getSharedPreferences("rill_data", Context.MODE_PRIVATE).edit().remove("run_active_start").apply()
    window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    if (rec.distM < 50.0) {
        RunTracker.activeFile(this).delete()
        Toast.makeText(this, "Jaraknya terlalu pendek, rekaman dibuang.", Toast.LENGTH_LONG).show()
        showJogging(); return
    }
    RunStore.attachTrack(this, rec.id)
    RunStore.add(this, rec)
    val hits = todayTasks.filter { !done.contains(it.id) && (it.name.lowercase(Locale.ROOT).contains("jog") || it.name.lowercase(Locale.ROOT).contains("lari")) }
    hits.forEach { onTaskToggled(it, true) }
    if (hits.isNotEmpty()) Toast.makeText(this, "Kegiatan \"${hits[0].name}\" dicentang otomatis ✅", Toast.LENGTH_LONG).show()
    showRunSummary(rec, true)
}

// ---------------- summary ----------------
internal fun MainActivity.showRunSummary(r: RunRecord, fresh: Boolean) {
    screen = "run_sum"; onTimerScreen = false; animating = true
    applyBackdrop(false)
    content.removeAllViews(); scrollView?.scrollTo(0, 0)
    content.addView(backLink("‹ Jogging") { showJogging() })
    content.addView(text(if (fresh) "Selesai! 🎉" else "Jogging", 28f, true))
    content.addView(hint(dateText(r.start)))
    val route = RouteView(this).apply { setRoute(RunStore.parseRoute(r.route)) }
    content.addView(route, LinearLayout.LayoutParams(-1, dp(260)).apply { setMargins(0, dp(8), 0, dp(8)) })
    val hero = card(16)
    hero.addView(text("${Fmt.km(r.distM)} km", 40f, true, green).apply { gravity = Gravity.CENTER })
    hero.addView(text("${Fmt.dur(r.durMs)} total · pace ${Fmt.pace(r.avgPaceSec)}/km", 14f, false, subtle).apply { gravity = Gravity.CENTER })
    content.addView(hero)
    val bestKm = r.splits.filter { it > 0 }.minOrNull()
    content.addView(tileRow(
        statTile("⏱️", Fmt.dur(r.movMs), "waktu bergerak", "tanpa berhenti"),
        statTile("⚡", Fmt.pace(bestKm ?: r.avgPaceSec), "pace terbaik", if (bestKm != null) "km tercepat" else "rata-rata")
    ))
    content.addView(tileRow(
        statTile("👟", "${if (r.stepsEst) "≈" else ""}${r.steps}", "langkah", if (r.stepsEst) "perkiraan dari jarak" else "dari sensor langkah"),
        statTile("🥁", if (r.cadence > 0) "${r.cadence}" else "--", "kadensi", "langkah per menit")
    ))
    section("Pace tiap kilometer")
    if (r.splits.isEmpty() && r.partialM < 100) content.addView(hint("Belum ada satu kilometer penuh."))
    else {
        val c = card(10)
        val fastest = (r.splits + listOfNotNull(if (r.partialM >= 100 && r.partialSec > 0) (r.partialSec * 1000.0 / r.partialM).roundToInt() else null)).filter { it > 0 }.minOrNull() ?: 1
        fun row(label: String, sec: Int) {
            val pct = if (sec <= 0) 0 else (fastest * 100 / sec).coerceIn(8, 100)
            val rowV = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(5), 0, dp(5)) }
            rowV.addView(text(label, 13f, true).apply { minWidth = dp(54) })
            rowV.addView(hbar(pct, if (sec == fastest) green else amber), LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(6), 0, dp(10), 0) })
            rowV.addView(text(Fmt.pace(sec), 13f, true).apply { minWidth = dp(46); gravity = Gravity.END })
            c.addView(rowV)
        }
        r.splits.forEachIndexed { i, s -> row("Km ${i + 1}", s) }
        if (r.partialM >= 100 && r.partialSec > 0) row(String.format(Locale.US, "%.2f km", r.partialM / 1000.0), (r.partialSec * 1000.0 / r.partialM).roundToInt())
        c.addView(hint("Hijau = km tercepat · Pace dihitung dari waktu bergerak."))
        content.addView(c)
    }
    val pts = RunStore.parseRoute(r.route)
    if (pts.isNotEmpty()) content.addView(button("Buka lokasi di aplikasi Peta") {
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("geo:${pts[0][0]},${pts[0][1]}?z=16"))) } catch (_: Exception) { Toast.makeText(this, "Tidak ada aplikasi peta.", Toast.LENGTH_LONG).show() }
    })
    content.addView(button("Ekspor GPX (untuk Strava dll.)") {
        RunUi.pendingGpxId = r.id
        val i = Intent(Intent.ACTION_CREATE_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "application/gpx+xml"; putExtra(Intent.EXTRA_TITLE, "jogging-${SimpleDateFormat("yyyy-MM-dd-HHmm", Locale.US).format(Date(r.start))}.gpx") }
        try { startActivityForResult(i, REQ_GPX) } catch (_: Exception) { Toast.makeText(this, "Tidak ada aplikasi file.", Toast.LENGTH_LONG).show() }
    })
    content.addView(button("Hapus rekaman") {
        AlertDialog.Builder(this, R.style.RillDialog).setTitle("Hapus rekaman ini?").setPositiveButton("Hapus") { _, _ -> RunStore.delete(this, r.id); showJogging() }.setNegativeButton("Batal", null).show()
    })
}

internal fun MainActivity.writeGpx(uri: Uri?) {
    val r = RunStore.load(this).find { it.id == RunUi.pendingGpxId }
    if (uri == null || r == null) return
    try {
        contentResolver.openOutputStream(uri)?.use { it.write(RunStore.gpx(this, r).toByteArray(Charsets.UTF_8)) }
        Toast.makeText(this, "GPX tersimpan ✅", Toast.LENGTH_LONG).show()
    } catch (_: Exception) { Toast.makeText(this, "Gagal menyimpan GPX.", Toast.LENGTH_LONG).show() }
}
