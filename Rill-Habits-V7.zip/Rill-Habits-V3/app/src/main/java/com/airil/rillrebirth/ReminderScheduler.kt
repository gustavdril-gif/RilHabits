package com.airil.rillrebirth

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import java.util.Calendar

object ReminderScheduler {
    fun scheduleAll(context: Context) {
        val prefs = context.getSharedPreferences("rill_data", Context.MODE_PRIVATE)
        val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or if (android.os.Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0
        // Existing daily checklist reminders (kept compatible with V1).
        TaskStore.load(context).forEach { task ->
            val prayerLinked = task.prayer.isNotEmpty() && PrayerTimes.city(context) != null
            val pi = PendingIntent.getBroadcast(context, task.id, Intent(context, ReminderReceiver::class.java).putExtra("task_id", task.id).putExtra("task_name", task.name).putExtra("prayer_reminder", prayerLinked), flags)
            alarm.cancel(pi)
            if (prayerLinked) {
                // Prayer times change a little every day, so use one-shot alarms for the next matching day.
                // The receiver re-runs this scheduler after delivery to queue the next one.
                if (prefs.getBoolean("reminders_enabled", true) && task.reminderEnabled) {
                    for (offset in 0..7) {
                        val day = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, offset) }
                        if (!task.runsOn(day.get(Calendar.DAY_OF_WEEK))) continue
                        val mins = PrayerTimes.minutes(context, task.prayer, day) ?: break
                        day.set(Calendar.HOUR_OF_DAY, mins / 60); day.set(Calendar.MINUTE, mins % 60); day.set(Calendar.SECOND, 0); day.set(Calendar.MILLISECOND, 0)
                        if (day.timeInMillis <= System.currentTimeMillis()) continue
                        alarm.set(AlarmManager.RTC_WAKEUP, day.timeInMillis, pi)
                        break
                    }
                }
                return@forEach
            }
            if (prefs.getBoolean("reminders_enabled", true) && task.reminderEnabled) {
                val parts = task.time.split(":")
                if (parts.size == 2) {
                    val hour = parts[0].toIntOrNull() ?: return@forEach
                    val minute = parts[1].toIntOrNull() ?: return@forEach
                    if (hour !in 0..23 || minute !in 0..59) return@forEach
                    val cal = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, hour); set(Calendar.MINUTE, minute); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0); if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1) }
                    alarm.setInexactRepeating(AlarmManager.RTC_WAKEUP, cal.timeInMillis, AlarmManager.INTERVAL_DAY, pi)
                }
            }
        }
        // Workout reminders are one-shot alarms scheduled for the next matching date.
        // The receiver re-runs this scheduler after delivery to queue the next recurrence.
        WorkoutStore.load(context).forEach { workout ->
            val requestCode = 100000 + (workout.id % 1000000000L).toInt().coerceAtLeast(0)
            val pi = PendingIntent.getBroadcast(context, requestCode, Intent(context, ReminderReceiver::class.java).putExtra("task_id", requestCode).putExtra("task_name", "Workout: ${workout.name}").putExtra("workout_reminder", true).putExtra("workout_id", workout.id), flags)
            alarm.cancel(pi)
            if (!prefs.getBoolean("reminders_enabled", true) || !workout.reminder || !workout.active) return@forEach
            val parts = workout.time.split(":"); if (parts.size != 2) return@forEach
            val hour = parts[0].toIntOrNull() ?: return@forEach; val minute = parts[1].toIntOrNull() ?: return@forEach
            if (hour !in 0..23 || minute !in 0..59) return@forEach
            val cal = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, hour); set(Calendar.MINUTE, minute); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }
            var found = false
            for (offset in 0..7) {
                val candidate = (cal.clone() as Calendar).apply { add(Calendar.DAY_OF_YEAR, offset) }
                if (candidate.timeInMillis <= System.currentTimeMillis()) continue
                val date = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(candidate.time)
                val matches = if (workout.oneOffDate.isNotBlank()) workout.oneOffDate == date else workout.days.contains(candidate.get(Calendar.DAY_OF_WEEK))
                if (matches) { cal.timeInMillis = candidate.timeInMillis; found = true; break }
            }
            if (found) alarm.set(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
        }
    }
}
