package com.airil.rillrebirth

import android.content.Context
import android.location.Location
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone
import kotlin.math.max
import kotlin.math.roundToInt

/** One accepted GPS point: absolute time, position, cumulative distance (m) and cumulative moving time (ms). */
data class RunPoint(val t: Long, val lat: Double, val lng: Double, val dist: Double, val mov: Long)

/** A finished run. Splits are seconds of moving time for each full kilometre. */
data class RunRecord(
    val id: Long, val start: Long, val durMs: Long, val movMs: Long, val distM: Double,
    val steps: Int, val stepsEst: Boolean, val splits: List<Int>, val partialM: Int, val partialSec: Int, val route: String
) {
    val avgPaceSec: Int get() = if (distM < 50) 0 else (movMs / 1000.0 / (distM / 1000.0)).roundToInt()
    val cadence: Int get() = if (movMs < 30000) 0 else (steps / (movMs / 60000.0)).roundToInt()
}

object Fmt {
    fun pace(secPerKm: Int): String = if (secPerKm <= 0 || secPerKm > 3599) "--:--" else String.format(Locale.US, "%d:%02d", secPerKm / 60, secPerKm % 60)
    fun dur(ms: Long): String {
        val s = (ms / 1000).toInt()
        return if (s >= 3600) String.format(Locale.US, "%d:%02d:%02d", s / 3600, (s % 3600) / 60, s % 60) else String.format(Locale.US, "%02d:%02d", s / 60, s % 60)
    }
    fun km(m: Double): String = String.format(Locale.US, "%.2f", m / 1000.0)
}

/** Live recording state and the filtering rules. Everything runs on the main thread. */
object RunTracker {
    @Volatile var active = false
    @Volatile var paused = false
    var startMs = 0L
    private var pausedTotalMs = 0L
    private var pauseStart = 0L
    var distM = 0.0
    var movMs = 0L
    var curSpeed = 0f
    var accuracy = 99f
    var lastFixMs = 0L
    var steps0 = -1f
    var stepsNow = 0f
    var kmDone = 0
    var onKm: ((Int) -> Unit)? = null
    val pts = ArrayList<RunPoint>()
    private var anchor: Location? = null
    private var prevFix = 0L
    private var out: java.io.FileWriter? = null

    fun activeFile(c: Context) = File(c.filesDir, "run_active.csv")

    fun reset() {
        active = false; paused = false; startMs = 0L; pausedTotalMs = 0L; pauseStart = 0L; distM = 0.0; movMs = 0L
        curSpeed = 0f; accuracy = 99f; lastFixMs = 0L; steps0 = -1f; stepsNow = 0f; kmDone = 0; pts.clear(); anchor = null; prevFix = 0L
        try { out?.close() } catch (_: Exception) { }
        out = null
    }

    fun begin(c: Context) {
        reset()
        active = true; startMs = System.currentTimeMillis()
        try { out = java.io.FileWriter(activeFile(c), false) } catch (_: Exception) { out = null }
        c.getSharedPreferences("rill_data", Context.MODE_PRIVATE).edit().putLong("run_active_start", startMs).apply()
    }

    fun elapsedMs(): Long {
        val now = if (paused) pauseStart else System.currentTimeMillis()
        return max(0L, now - startMs - pausedTotalMs)
    }

    fun pause() { if (active && !paused) { paused = true; pauseStart = System.currentTimeMillis() } }
    fun resume() {
        if (active && paused) { pausedTotalMs += System.currentTimeMillis() - pauseStart; paused = false; anchor = null; prevFix = 0L; curSpeed = 0f }
    }

    fun steps(): Int = if (steps0 < 0f) 0 else max(0f, stepsNow - steps0).toInt()

    fun onLocation(loc: Location) {
        if (!active || paused) return
        accuracy = loc.accuracy; lastFixMs = System.currentTimeMillis()
        if (loc.accuracy > 30f) return
        val now = loc.time
        val dtMs = if (prevFix > 0) (now - prevFix).coerceIn(0L, 5000L) else 0L
        prevFix = now
        val a = anchor
        if (a == null) { anchor = loc; addPoint(loc); return }
        val sinceAnchorSec = (now - a.time) / 1000.0
        if (sinceAnchorSec <= 0.0) return
        val d = a.distanceTo(loc).toDouble()
        val speed = if (loc.hasSpeed()) loc.speed else (d / sinceAnchorSec).toFloat()
        curSpeed = curSpeed * 0.7f + speed * 0.3f
        val moving = speed >= 0.8f
        if (moving) movMs += dtMs
        if (!moving) return
        val v = d / sinceAnchorSec
        if (v > 12.0) { if (sinceAnchorSec > 20.0) anchor = loc; return }   // GPS jump
        if (d < 3.0) return
        distM += d
        anchor = loc
        addPoint(loc)
        while (distM >= (kmDone + 1) * 1000.0) { kmDone++; onKm?.invoke(kmDone) }
    }

    private fun addPoint(loc: Location) {
        val p = RunPoint(loc.time, loc.latitude, loc.longitude, distM, movMs)
        pts.add(p)
        try { out?.write("${p.t},${p.lat},${p.lng},${p.dist},${p.mov}\n"); if (pts.size % 10 == 0) out?.flush() } catch (_: Exception) { }
    }

    /** Builds the final record from the current state. */
    fun buildRecord(c: Context, estimateStepsFromDistance: Boolean = true): RunRecord = RunStore.recordFrom(c, startMs, elapsedMs(), movMs, distM, pts, steps(), estimateStepsFromDistance)
}

object RunStore {
    private const val KEY = "runs_json"
    private fun prefs(c: Context) = c.getSharedPreferences("rill_data", Context.MODE_PRIVATE)
    fun routeDir(c: Context): File = File(c.filesDir, "runs").apply { mkdirs() }

    fun load(c: Context): MutableList<RunRecord> {
        val out = mutableListOf<RunRecord>()
        try {
            val a = JSONArray(prefs(c).getString(KEY, "[]") ?: "[]")
            for (i in 0 until a.length()) {
                val o = a.optJSONObject(i) ?: continue
                val sp = o.optJSONArray("splits") ?: JSONArray()
                out.add(RunRecord(o.optLong("id"), o.optLong("start"), o.optLong("dur"), o.optLong("mov"), o.optDouble("dist"), o.optInt("steps"), o.optBoolean("est"),
                    (0 until sp.length()).map { sp.optInt(it) }, o.optInt("pm"), o.optInt("ps"), o.optString("route")))
            }
        } catch (_: Exception) { }
        return out.sortedByDescending { it.start }.toMutableList()
    }

    fun save(c: Context, list: List<RunRecord>) {
        val a = JSONArray()
        list.forEach { r -> a.put(JSONObject().put("id", r.id).put("start", r.start).put("dur", r.durMs).put("mov", r.movMs).put("dist", r.distM).put("steps", r.steps).put("est", r.stepsEst)
            .put("splits", JSONArray(r.splits)).put("pm", r.partialM).put("ps", r.partialSec).put("route", r.route)) }
        prefs(c).edit().putString(KEY, a.toString()).apply()
    }

    fun add(c: Context, r: RunRecord) { val l = load(c); l.add(r); save(c, l) }

    fun delete(c: Context, id: Long) { save(c, load(c).filter { it.id != id }); File(routeDir(c), "$id.csv").delete() }

    fun recordFrom(c: Context, start: Long, durMs: Long, movMs: Long, distM: Double, pts: List<RunPoint>, sensorSteps: Int, estimate: Boolean): RunRecord {
        val splits = mutableListOf<Int>()
        var nextKm = 1000.0; var prevDist = 0.0; var prevMov = 0L; var lastAt = 0.0
        pts.forEach { p ->
            while (p.dist >= nextKm && p.dist > prevDist) {
                val frac = (nextKm - prevDist) / (p.dist - prevDist)
                val movAt = prevMov + frac * (p.mov - prevMov)
                splits.add(((movAt - lastAt) / 1000.0).roundToInt())
                lastAt = movAt; nextKm += 1000.0
            }
            prevDist = p.dist; prevMov = p.mov
        }
        val partialM = (distM - splits.size * 1000.0).toInt().coerceAtLeast(0)
        val partialSec = ((movMs - lastAt) / 1000.0).roundToInt().coerceAtLeast(0)
        val useEst = sensorSteps <= 0 && estimate
        val steps = if (sensorSteps > 0) sensorSteps else if (estimate) (distM / 0.9).toInt() else 0
        // downsample the route (about 250 points) so it stays small inside the backup
        val step = max(1, pts.size / 250)
        val sb = StringBuilder()
        var i = 0
        while (i < pts.size) {
            val p = pts[i]
            if (sb.isNotEmpty()) sb.append(';')
            sb.append(String.format(Locale.US, "%.5f,%.5f,%d", p.lat, p.lng, p.mov / 1000))
            i += step
        }
        if (pts.isNotEmpty() && (pts.size - 1) % step != 0) { val p = pts.last(); sb.append(';').append(String.format(Locale.US, "%.5f,%.5f,%d", p.lat, p.lng, p.mov / 1000)) }
        return RunRecord(System.currentTimeMillis(), start, durMs, movMs, distM, steps, useEst, splits, partialM, partialSec, sb.toString())
    }

    /** Parses "lat,lng,movSec;..." into arrays. */
    fun parseRoute(s: String): List<DoubleArray> {
        if (s.isBlank()) return emptyList()
        return s.split(';').mapNotNull { part ->
            val f = part.split(','); if (f.size < 3) null else try { doubleArrayOf(f[0].toDouble(), f[1].toDouble(), f[2].toDouble()) } catch (_: Exception) { null }
        }
    }

    /** Reads the recorded points of an interrupted run (if any) from the active file. */
    fun recoverPoints(c: Context): List<RunPoint> {
        val f = RunTracker.activeFile(c)
        if (!f.exists()) return emptyList()
        val out = mutableListOf<RunPoint>()
        try {
            f.forEachLine { line ->
                val p = line.split(','); if (p.size >= 5) out.add(RunPoint(p[0].toLong(), p[1].toDouble(), p[2].toDouble(), p[3].toDouble(), p[4].toLong()))
            }
        } catch (_: Exception) { }
        return out
    }

    /** Moves the active file next to the saved run so GPX export can use the full-resolution track. */
    fun attachTrack(c: Context, id: Long) {
        val f = RunTracker.activeFile(c)
        if (f.exists()) { if (!f.renameTo(File(routeDir(c), "$id.csv"))) f.delete() }
    }

    fun gpx(c: Context, r: RunRecord): String {
        val iso = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).apply { timeZone = TimeZone.getTimeZone("UTC") }
        val sb = StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<gpx version=\"1.1\" creator=\"RilHabit\" xmlns=\"http://www.topografix.com/GPX/1/1\">\n<trk><name>Jogging ${SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(java.util.Date(r.start))}</name><trkseg>\n")
        val f = File(routeDir(c), "${r.id}.csv")
        if (f.exists()) {
            f.forEachLine { line ->
                val p = line.split(','); if (p.size >= 3) sb.append("<trkpt lat=\"${p[1]}\" lon=\"${p[2]}\"><time>${iso.format(java.util.Date(p[0].toLong()))}</time></trkpt>\n")
            }
        } else {
            val pts = parseRoute(r.route)
            pts.forEach { sb.append("<trkpt lat=\"${it[0]}\" lon=\"${it[1]}\"><time>${iso.format(java.util.Date(r.start + (it[2] * 1000).toLong()))}</time></trkpt>\n") }
        }
        sb.append("</trkseg></trk></gpx>\n")
        return sb.toString()
    }
}
