package com.airil.rillrebirth

import android.app.AlertDialog
import android.graphics.Color
import android.view.Gravity
import android.widget.*
import org.json.JSONObject
import java.util.Locale

private fun MainActivity.catRow(parent: LinearLayout, label: String, d: Int, t: Int, color: Int) {
    if (t <= 0) return
    val pct = d * 100 / t
    val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(6), 0, 0) }
    head.addView(text(label, 13f, true), LinearLayout.LayoutParams(0, -2, 1f))
    head.addView(text("$pct% · $d/$t", 12f, false, subtle))
    parent.addView(head)
    parent.addView(hbar(pct, color))
}

internal fun MainActivity.showStats() {
    val hStreak = Smart.habitStreak(stats)
    val wStreak = Smart.workoutStreak(stats)
    val totalXp = TaskStore.totalXp(this) + WorkoutStore.totalWorkoutXp(this)
    val level = totalXp / 100 + 1
    content.addView(tileRow(
        statTile("🔥", "$hStreak", "Streak kebiasaan", "rekor ${maxOf(Smart.bestHabitStreak(stats), hStreak)} hari"),
        statTile("💪", "$wStreak", "Streak workout", "rekor ${maxOf(Smart.bestWorkoutStreak(stats), wStreak)} hari"),
        statTile("⭐", "Lv $level", Smart.levelTitle(level), "$totalXp EXP")
    ))

    // consistency
    val c1 = card()
    c1.addView(text("Konsistensi", 18f, true))
    c1.addView(segmented(listOf("7 hari", "30 hari"), statsPeriod) { statsPeriod = it; render(false) })
    val n = if (statsPeriod == 0) 7 else 30
    val slice = stats.takeLast(n)
    val chart = BarChartView(this)
    chart.values = slice.map { it.rate }
    chart.labels = slice.mapIndexed { i, s -> if (n == 7) dayShort(s.weekday) else if ((n - 1 - i) % 5 == 0) s.date.substring(8) else "" }
    c1.addView(chart, LinearLayout.LayoutParams(-1, dp(170)))
    if (animating) chart.animateIn()
    val active = slice.filter { it.total > 0 }
    if (active.isNotEmpty()) {
        val avg = (active.map { it.rate }.average() * 100).toInt()
        val bestDay = active.maxByOrNull { it.rate }
        c1.addView(text("Rata-rata $avg% · terbaik: ${if (bestDay != null) dayShort(bestDay.weekday) + " (" + (bestDay.rate * 100).toInt() + "%)" else "-"}", 13f, true, green))
    }
    c1.addView(hint("Garis putus-putus = batas 50% untuk streak kebiasaan."))
    content.addView(c1)

    // heatmap
    val c2 = card()
    c2.addView(text("Peta aktivitas · 12 minggu", 18f, true))
    val last84 = stats.takeLast(84)
    val heat = HeatmapView(this)
    heat.setData(last84.map { if (it.total == 0) -1f else it.rate }, (last84[0].weekday + 5) % 7)
    c2.addView(heat, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(10), 0, dp(6)) })
    c2.addView(hint("Makin gelap hijaunya, makin banyak yang selesai di hari itu. Baris atas = Senin."))
    content.addView(c2)

    // workout summary
    section("Workout")
    val s30 = stats.takeLast(30).sumOf { it.workoutDone }
    val avgWeek = stats.takeLast(28).sumOf { it.workoutDone } / 4.0
    val allTime = stats.sumOf { it.workoutDone }
    val favDay = stats.takeLast(84).filter { it.workoutDone > 0 }.groupBy { it.weekday }.maxByOrNull { it.value.size }?.key
    content.addView(tileRow(
        statTile("🏋️", "$s30", "Sesi 30 hari", "yang kamu selesaikan"),
        statTile("📊", String.format(Locale.US, "%.1f", avgWeek), "Rata-rata/minggu", "4 minggu terakhir")
    ))
    content.addView(tileRow(
        statTile("🎯", "$allTime", "Total sesi", "sejak awal"),
        statTile("📅", if (favDay != null) dayShort(favDay) else "-", "Hari favorit", "paling sering workout")
    ))

    // categories
    val last30 = stats.takeLast(30)
    val c3 = card()
    c3.addView(text("Per kategori · 30 hari", 18f, true))
    catRow(c3, "Ibadah", last30.sumOf { it.prayerDone }, last30.sumOf { it.prayerTotal }, green)
    catRow(c3, "Workout", last30.sumOf { it.workoutDone }, last30.sumOf { it.workoutTotal }, amber)
    catRow(c3, "Lainnya", last30.sumOf { it.tasksDone - it.prayerDone }, last30.sumOf { it.tasksTotal - it.prayerTotal }, blue)
    content.addView(c3)

    // mood curve
    section("Mood")
    val c4 = card()
    c4.addView(text("Kurva Mood", 18f, true))
    c4.addView(segmented(listOf("Minggu", "Bulan", "Tahun"), moodPeriod) { moodPeriod = it; render(false) })
    val (values, labels, details) = Smart.moodSeries(this, moodPeriod)
    val line = LineChartView(this)
    line.setData(values, labels, details)
    c4.addView(line, LinearLayout.LayoutParams(-1, dp(210)))
    if (animating) line.animateIn()
    val valid = values.filterNotNull()
    if (valid.isEmpty()) {
        c4.addView(hint("Mood dicatat saat semua checklist hari itu selesai."))
    } else {
        val avg = valid.average()
        val rounded = Math.round(avg).toInt().coerceIn(1, 5)
        var trend = ""
        if (valid.size >= 4) {
            val third = valid.size / 3
            val diff = valid.takeLast(third).average() - valid.take(third).average()
            trend = if (diff >= 0.3) " · tren naik 📈" else if (diff <= -0.3) " · tren turun 📉" else " · stabil"
        }
        c4.addView(text("Rata-rata ${String.format(Locale.US, "%.1f", avg)}/5 ${Smart.moodEmojis[rounded - 1]}$trend", 13f, true, green))
        val counts = Smart.moodCounts(this, if (moodPeriod == 0) 7 else if (moodPeriod == 1) 30 else 365)
        val dist = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(8), 0, 0) }
        for (i in 0..4) {
            val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
            col.addView(text(Smart.moodEmojis[i], 20f).apply { gravity = Gravity.CENTER })
            col.addView(text("${counts[i]}×", 12f, true, if (counts[i] > 0) ink else subtle).apply { gravity = Gravity.CENTER })
            dist.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
        }
        c4.addView(dist)
    }
    c4.addView(button("Riwayat mood & catatan") { showMoodHistory() })
    content.addView(c4)

    // insights
    section("Wawasan pintar")
    val c5 = card()
    Smart.insights(this, tasks, stats).forEach { line2 -> c5.addView(text(line2, 13f, false, ink).apply { setPadding(dp(2), dp(6), dp(2), dp(6)) }) }
    content.addView(c5)
}

internal fun MainActivity.showMoodHistory() {
    val root = WorkoutStore.moods(this)
    val keys = mutableListOf<String>()
    val it = root.keys()
    while (it.hasNext()) keys.add(it.next())
    keys.sortDescending()
    val msg = if (keys.isEmpty()) "Belum ada catatan mood." else keys.take(30).joinToString("\n\n") { d ->
        val o = root.optJSONObject(d)
        val v = o?.optInt("value", 0) ?: 0
        val tagArr = o?.optJSONArray("tags")
        val tagText = if (tagArr == null || tagArr.length() == 0) "" else (0 until tagArr.length()).joinToString(", ") { tagArr.optString(it) }
        "$d · ${if (v in 1..5) Smart.moodEmojis[v - 1] + " " + Smart.moodLabels[v - 1] else "-"}" + (if (tagText.isNotEmpty()) "\n#$tagText" else "") + (if (o?.optString("note").orEmpty().isNotEmpty()) "\n${o?.optString("note")}" else "")
    }
    AlertDialog.Builder(this, R.style.RillDialog).setTitle("Riwayat Mood").setMessage(msg).setPositiveButton("Tutup", null).show()
}

internal fun MainActivity.showMoodSheet(preselect: Int) {
    val today = TaskStore.today()
    val prev = WorkoutStore.mood(this, today)
    var selected = if (preselect >= 0) preselect else (prev?.optInt("value", 0) ?: 0) - 1
    val tags = mutableSetOf<String>()
    val pt = prev?.optJSONArray("tags")
    if (pt != null) for (i in 0 until pt.length()) tags.add(pt.optString(i))
    val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(4), dp(18), dp(4)) }
    box.addView(text("Pilih yang paling menggambarkan perasaanmu.", 13f, false, subtle))

    val tileViews = ArrayList<LinearLayout>()
    fun paintTiles() {
        tileViews.forEachIndexed { i, v ->
            v.background = shape(if (i == selected) greenSoft else bg, 16)
            val s = if (i == selected) 1.1f else 1f
            v.animate().scaleX(s).scaleY(s).setDuration(200).start()
        }
    }
    val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(10), 0, dp(6)) }
    for (i in 0..4) {
        val tile = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(0, dp(10), 0, dp(8)) }
        tile.addView(text(Smart.moodEmojis[i], 28f).apply { gravity = Gravity.CENTER })
        tile.addView(text(Smart.moodLabels[i], 9f, false, subtle).apply { gravity = Gravity.CENTER })
        tile.setOnClickListener { selected = i; paintTiles() }
        tileViews.add(tile)
        row.addView(tile, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(2), 0, dp(2), 0) })
    }
    box.addView(row)
    paintTiles()

    val allTags = listOf("Senang", "Tenang", "Semangat", "Bersyukur", "Fokus", "Capek", "Stres", "Cemas", "Sedih")
    val chipRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(4), 0, dp(4)) }
    fun buildChips() {
        chipRow.removeAllViews()
        allTags.forEach { t ->
            chipRow.addView(chip(t, tags.contains(t)) { if (tags.contains(t)) tags.remove(t) else tags.add(t); buildChips() }, LinearLayout.LayoutParams(-2, -2).apply { setMargins(0, 0, dp(6), 0) })
        }
    }
    buildChips()
    box.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(chipRow) })
    val note = EditText(this).apply { hint = "Catatan opsional"; minLines = 2; setText(prev?.optString("note", "") ?: "") }
    box.addView(note)

    AlertDialog.Builder(this, R.style.RillDialog).setTitle("Mood Harian").setView(ScrollView(this).apply { addView(box) }).setPositiveButton("Simpan") { _, _ ->
        if (selected < 0) { Toast.makeText(this, "Pilih emoji mood dulu.", Toast.LENGTH_SHORT).show(); return@setPositiveButton }
        WorkoutStore.saveMood(this, today, selected + 1, note.text.toString(), tags.toList())
        Toast.makeText(this, "Mood tersimpan ${Smart.moodEmojis[selected]}", Toast.LENGTH_SHORT).show()
        render(false)
    }.setNegativeButton("Batal", null).show()
}

internal fun MainActivity.showReviewDialog() {
    val today = TaskStore.today()
    val old = try { JSONObject(prefs().getString("review2_$today", "{}") ?: "{}") } catch (_: Exception) { JSONObject() }
    val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(4), dp(20), dp(4)) }
    val good = EditText(this).apply { hint = "✅ Apa yang berhasil hari ini?"; minLines = 2; setText(old.optString("good", "")) }
    val improve = EditText(this).apply { hint = "🔧 Apa yang mau diperbaiki besok?"; minLines = 2; setText(old.optString("improve", "")) }
    val thanks = EditText(this).apply { hint = "🙏 Satu hal yang kamu syukuri"; setText(old.optString("thanks", "")) }
    box.addView(good); box.addView(improve); box.addView(thanks)
    AlertDialog.Builder(this, R.style.RillDialog).setTitle("Evaluasi malam").setView(ScrollView(this).apply { addView(box) }).setPositiveButton("Simpan") { _, _ ->
        val o = JSONObject().put("good", good.text.toString()).put("improve", improve.text.toString()).put("thanks", thanks.text.toString())
        prefs().edit().putString("review2_$today", o.toString()).apply()
        Toast.makeText(this, "Evaluasi tersimpan 🌙", Toast.LENGTH_SHORT).show()
        render(false)
    }.setNegativeButton("Batal", null).show()
}
