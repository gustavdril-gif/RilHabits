package com.airil.rillrebirth

import android.app.AlertDialog
import android.content.Context
import android.graphics.Color
import android.text.InputType
import android.view.Gravity
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.util.Calendar
import java.util.Locale
import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.asin
import kotlin.math.atan
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.sin
import kotlin.math.tan

data class City(val name: String, val lat: Double, val lng: Double, val tz: Double)

/**
 * Offline prayer times (no internet, no location permission): the user picks a city and the times are
 * calculated astronomically (Fajr 20°, Isha 18°, Asr Shafi'i, +2 min ihtiyath like the Indonesian Kemenag tables).
 * Results are an estimate and can differ from the official table by a few minutes; a correction can be set.
 */
object PrayerTimes {
    val KEYS = listOf("subuh", "dzuhur", "ashar", "maghrib", "isya")
    val LABELS = mapOf("subuh" to "Subuh", "dzuhur" to "Dzuhur", "ashar" to "Ashar", "maghrib" to "Maghrib", "isya" to "Isya")
    const val CUSTOM = "Kustom"

    val cities = listOf(
        City("Jakarta", -6.2088, 106.8456, 7.0), City("Bandung", -6.9175, 107.6191, 7.0), City("Bogor", -6.5971, 106.8060, 7.0),
        City("Depok", -6.4025, 106.7942, 7.0), City("Tangerang", -6.1783, 106.6319, 7.0), City("Bekasi", -6.2383, 106.9756, 7.0),
        City("Serang", -6.1200, 106.1503, 7.0), City("Cirebon", -6.7063, 108.5570, 7.0), City("Semarang", -6.9667, 110.4167, 7.0),
        City("Yogyakarta", -7.7956, 110.3695, 7.0), City("Surakarta (Solo)", -7.5666, 110.8167, 7.0), City("Surabaya", -7.2575, 112.7521, 7.0),
        City("Malang", -7.9666, 112.6326, 7.0), City("Medan", 3.5952, 98.6722, 7.0), City("Banda Aceh", 5.5483, 95.3238, 7.0),
        City("Pekanbaru", 0.5071, 101.4478, 7.0), City("Padang", -0.9471, 100.4172, 7.0), City("Jambi", -1.6101, 103.6131, 7.0),
        City("Palembang", -2.9761, 104.7754, 7.0), City("Bengkulu", -3.8004, 102.2655, 7.0), City("Bandar Lampung", -5.4500, 105.2667, 7.0),
        City("Batam", 1.0456, 104.0305, 7.0), City("Pangkalpinang", -2.1316, 106.1169, 7.0), City("Pontianak", -0.0263, 109.3425, 7.0),
        City("Palangkaraya", -2.2161, 113.9135, 7.0), City("Banjarmasin", -3.3186, 114.5944, 8.0), City("Balikpapan", -1.2379, 116.8529, 8.0),
        City("Samarinda", -0.5022, 117.1536, 8.0), City("Tarakan", 3.3000, 117.6333, 8.0), City("Denpasar", -8.6705, 115.2126, 8.0),
        City("Mataram", -8.5833, 116.1167, 8.0), City("Kupang", -10.1772, 123.6070, 8.0), City("Makassar", -5.1477, 119.4327, 8.0),
        City("Manado", 1.4748, 124.8421, 8.0), City("Palu", -0.9003, 119.8780, 8.0), City("Kendari", -3.9985, 122.5129, 8.0),
        City("Gorontalo", 0.5435, 123.0568, 8.0), City("Ambon", -3.6954, 128.1814, 9.0), City("Ternate", 0.7833, 127.3667, 9.0),
        City("Jayapura", -2.5337, 140.7181, 9.0), City("Manokwari", -0.8615, 134.0620, 9.0), City("Sorong", -0.8762, 131.2558, 9.0)
    )

    private fun prefs(c: Context) = c.getSharedPreferences("rill_data", Context.MODE_PRIVATE)

    fun city(c: Context): City? {
        val p = prefs(c)
        val name = p.getString("prayer_city", null) ?: return null
        if (name == CUSTOM) {
            if (!p.contains("prayer_lat") || !p.contains("prayer_lng")) return null
            return City(CUSTOM, java.lang.Double.longBitsToDouble(p.getLong("prayer_lat", 0L)), java.lang.Double.longBitsToDouble(p.getLong("prayer_lng", 0L)), p.getFloat("prayer_tz", 7f).toDouble())
        }
        return cities.find { it.name == name }
    }

    fun setCity(c: Context, name: String) { prefs(c).edit().putString("prayer_city", name).apply() }

    fun setCustom(c: Context, lat: Double, lng: Double, tz: Double) {
        prefs(c).edit().putString("prayer_city", CUSTOM).putLong("prayer_lat", java.lang.Double.doubleToLongBits(lat))
            .putLong("prayer_lng", java.lang.Double.doubleToLongBits(lng)).putFloat("prayer_tz", tz.toFloat()).apply()
    }

    fun clearCity(c: Context) { prefs(c).edit().remove("prayer_city").apply() }
    fun offset(c: Context): Int = prefs(c).getInt("prayer_offset", 0).coerceIn(-30, 30)
    fun setOffset(c: Context, minutes: Int) { prefs(c).edit().putInt("prayer_offset", minutes.coerceIn(-30, 30)).apply() }

    /** Which prayer a task name refers to (only for names that clearly describe a prayer), or "". */
    fun keyFor(name: String, category: String): String {
        val n = name.lowercase(Locale.ROOT)
        val isPrayerWord = listOf("shalat", "sholat", "salat", "solat").any { n.contains(it) } || category.lowercase(Locale.ROOT).contains("ibadah")
        if (!isPrayerWord) return ""
        return when {
            n.contains("subuh") || n.contains("shubuh") -> "subuh"
            n.contains("dzuhur") || n.contains("zuhur") || n.contains("dhuhur") || n.contains("duhur") -> "dzuhur"
            n.contains("ashar") || n.contains("asar") -> "ashar"
            n.contains("maghrib") || n.contains("magrib") -> "maghrib"
            n.contains("isya") || n.contains("isyak") || n.contains("isha") -> "isya"
            else -> ""
        }
    }

    /** Minutes after midnight for a prayer key ("subuh", "terbit", ...) on [cal]'s date; null if no city is set. */
    fun minutes(c: Context, key: String, cal: Calendar = Calendar.getInstance()): Int? {
        if (key.isEmpty()) return null
        val city = city(c) ?: return null
        val t = compute(city, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1, cal.get(Calendar.DAY_OF_MONTH))
        val idx = when (key) { "subuh" -> 0; "terbit" -> 1; "dzuhur" -> 2; "ashar" -> 3; "maghrib" -> 4; "isya" -> 5; else -> return null }
        val extra = if (key == "terbit" || key == "subuh") 0.0 else 2.0 / 60.0
        val h = t[idx] + extra + offset(c) / 60.0
        return floor(h * 60.0 + 0.5).toInt().coerceIn(0, 1439)
    }

    fun format(minutes: Int): String = String.format(Locale.US, "%02d:%02d", minutes / 60, minutes % 60)

    // ---- astronomy (PrayTimes-style) ----
    private fun rad(x: Double) = Math.toRadians(x)
    private fun deg(x: Double) = Math.toDegrees(x)
    private fun fixAngle(a: Double) = a - 360.0 * floor(a / 360.0)
    private fun fixHour(a: Double) = a - 24.0 * floor(a / 24.0)

    private fun julian(year: Int, month: Int, day: Int): Double {
        var y = year; var m = month
        if (m <= 2) { y -= 1; m += 12 }
        val a = floor(y / 100.0)
        val b = 2 - a + floor(a / 4.0)
        return floor(365.25 * (y + 4716)) + floor(30.6001 * (m + 1)) + day + b - 1524.5
    }

    /** Returns declination (degrees) and equation of time (hours). */
    private fun sunPos(jd: Double): Pair<Double, Double> {
        val dd = jd - 2451545.0
        val g = fixAngle(357.529 + 0.98560028 * dd)
        val q = fixAngle(280.459 + 0.98564736 * dd)
        val l = fixAngle(q + 1.915 * sin(rad(g)) + 0.020 * sin(rad(2 * g)))
        val e = 23.439 - 0.00000036 * dd
        val ra = deg(atan2(cos(rad(e)) * sin(rad(l)), cos(rad(l)))) / 15.0
        val eqt = q / 15.0 - fixHour(ra)
        val decl = deg(asin(sin(rad(e)) * sin(rad(l))))
        return Pair(decl, eqt)
    }

    private fun midDay(jd: Double, t: Double): Double = fixHour(12 - sunPos(jd + t).second)

    private fun angleTime(jd: Double, lat: Double, angle: Double, t: Double, ccw: Boolean): Double {
        val decl = sunPos(jd + t).first
        val noon = midDay(jd, t)
        val x = (-sin(rad(angle)) - sin(rad(decl)) * sin(rad(lat))) / (cos(rad(decl)) * cos(rad(lat)))
        val dt = 1.0 / 15.0 * deg(acos(x.coerceIn(-1.0, 1.0)))
        return noon + (if (ccw) -dt else dt)
    }

    private fun asrTime(jd: Double, lat: Double, factor: Double, t: Double): Double {
        val decl = sunPos(jd + t).first
        val angle = -deg(atan(1.0 / (factor + tan(rad(abs(lat - decl))))))
        return angleTime(jd, lat, angle, t, false)
    }

    /** [fajr, sunrise, dhuhr, asr, maghrib, isha] in local clock hours of the city's time zone. */
    private fun compute(city: City, year: Int, month: Int, day: Int): DoubleArray {
        val jd = julian(year, month, day) - city.lng / 360.0
        var g = doubleArrayOf(5.0, 6.0, 12.0, 13.0, 18.0, 18.0)
        for (iter in 0 until 2) {
            g = doubleArrayOf(
                angleTime(jd, city.lat, 20.0, g[0] / 24.0, true),
                angleTime(jd, city.lat, 0.833, g[1] / 24.0, true),
                midDay(jd, g[2] / 24.0),
                asrTime(jd, city.lat, 1.0, g[3] / 24.0),
                angleTime(jd, city.lat, 0.833, g[4] / 24.0, false),
                angleTime(jd, city.lat, 18.0, g[5] / 24.0, false)
            )
        }
        val shift = city.tz - city.lng / 15.0
        return DoubleArray(6) { g[it] + shift }
    }
}

/** Tasks that name a prayer follow that prayer's time. Returns how many tasks were linked. */
internal fun MainActivity.autoLinkPrayerTasks(): Int {
    var n = 0
    val list = TaskStore.load(this)
    list.forEach { t ->
        val key = PrayerTimes.keyFor(t.name, t.category)
        if (key.isNotEmpty() && t.prayer != key) { t.prayer = key; t.reminderEnabled = true; n++ }
    }
    if (n > 0) { TaskStore.save(this, list); ReminderScheduler.scheduleAll(this) }
    return n
}

/** Card in the Jadwal tab: city, today's times and settings. */
internal fun MainActivity.prayerCard() {
    val c = card(14)
    c.addView(text("🕌 Waktu shalat", 16f, true))
    val city = PrayerTimes.city(this)
    if (city == null) {
        c.addView(hint("Pilih kotamu, lalu kegiatan shalat dan pengingatnya otomatis mengikuti waktu setempat — tanpa internet dan tanpa izin lokasi."))
        c.addView(button("Pilih kota", true) { showCityPicker() })
    } else {
        c.addView(hint("${city.name} · perkiraan hari ini (bisa selisih beberapa menit dari jadwal resmi)"))
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(6), 0, dp(6)) }
        PrayerTimes.KEYS.forEach { k ->
            val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(0, dp(8), 0, dp(8)); background = shape(Color.parseColor("#F5F5F9"), 12) }
            col.addView(text(PrayerTimes.LABELS[k] ?: k, 11f, false, subtle).apply { gravity = Gravity.CENTER })
            col.addView(text(PrayerTimes.format(PrayerTimes.minutes(this, k) ?: 0), 14f, true).apply { gravity = Gravity.CENTER })
            row.addView(col, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(2), 0, dp(2), 0) })
        }
        c.addView(row)
        val off = PrayerTimes.offset(this)
        c.addView(hint("Koreksi: ${if (off > 0) "+$off" else "$off"} menit"))
        c.addView(pair(button("Ganti kota") { showCityPicker() }, button("Koreksi menit") { showOffsetDialog() }))
        c.addView(button("Terapkan ke kegiatan shalat") {
            val n = autoLinkPrayerTasks()
            Toast.makeText(this, if (n > 0) "$n kegiatan shalat kini mengikuti jadwal dan pengingatnya aktif." else "Tidak ada kegiatan shalat baru yang bisa dihubungkan. Atur manual di form kegiatan.", Toast.LENGTH_LONG).show()
            render(false)
        })
    }
    content.addView(c)
}

internal fun MainActivity.showCityPicker() {
    val names = PrayerTimes.cities.map { it.name } + "Koordinat manual…"
    AlertDialog.Builder(this, R.style.RillDialog).setTitle("Pilih kota").setItems(names.toTypedArray()) { _, which ->
        if (which < PrayerTimes.cities.size) {
            PrayerTimes.setCity(this, PrayerTimes.cities[which].name)
            val n = autoLinkPrayerTasks()
            Toast.makeText(this, if (n > 0) "$n kegiatan shalat kini mengikuti jadwal ${PrayerTimes.cities[which].name}." else "Kota disimpan.", Toast.LENGTH_LONG).show()
            ReminderScheduler.scheduleAll(this)
            render(false)
        } else showCustomCity()
    }.setNegativeButton("Batal", null).show()
}

private fun MainActivity.showCustomCity() {
    val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(4), dp(20), dp(4)) }
    val signed = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL or InputType.TYPE_NUMBER_FLAG_SIGNED
    val lat = EditText(this).apply { hint = "Lintang (mis. -6.2088)"; inputType = signed }
    val lng = EditText(this).apply { hint = "Bujur (mis. 106.8456)"; inputType = signed }
    val tz = EditText(this).apply { hint = "Zona waktu: 7 (WIB), 8 (WITA), 9 (WIT)"; inputType = signed; setText("7") }
    box.addView(lat); box.addView(lng); box.addView(tz)
    AlertDialog.Builder(this, R.style.RillDialog).setTitle("Koordinat manual").setView(box).setPositiveButton("Simpan") { _, _ ->
        val la = lat.text.toString().toDoubleOrNull(); val lo = lng.text.toString().toDoubleOrNull(); val z = tz.text.toString().toDoubleOrNull() ?: 7.0
        if (la == null || lo == null || la !in -66.0..66.0 || lo !in -180.0..180.0) { Toast.makeText(this, "Koordinat tidak valid.", Toast.LENGTH_LONG).show(); return@setPositiveButton }
        PrayerTimes.setCustom(this, la, lo, z)
        autoLinkPrayerTasks()
        ReminderScheduler.scheduleAll(this)
        render(false)
    }.setNegativeButton("Batal", null).show()
}

private fun MainActivity.showOffsetDialog() {
    val e = EditText(this).apply { hint = "Menit (-30 sampai 30)"; inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_SIGNED; setText(PrayerTimes.offset(this@showOffsetDialog).toString()) }
    AlertDialog.Builder(this, R.style.RillDialog).setTitle("Koreksi menit").setMessage("Tambah atau kurangi menit untuk semua waktu shalat agar cocok dengan jadwal masjid atau aplikasi yang kamu pakai.").setView(e)
        .setPositiveButton("Simpan") { _, _ ->
            PrayerTimes.setOffset(this, e.text.toString().toIntOrNull() ?: 0)
            ReminderScheduler.scheduleAll(this)
            render(false)
        }.setNegativeButton("Batal", null).show()
}
