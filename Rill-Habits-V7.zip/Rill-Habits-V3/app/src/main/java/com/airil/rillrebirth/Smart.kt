package com.airil.rillrebirth

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

data class DayStat(
    val date: String,
    val weekday: Int,
    val tasksDone: Int,
    val tasksTotal: Int,
    val prayerDone: Int,
    val prayerTotal: Int,
    val workoutDone: Int,
    val workoutTotal: Int
) {
    val done: Int get() = tasksDone + workoutDone
    val total: Int get() = tasksTotal + workoutTotal
    val rate: Float get() = if (total == 0) 0f else done.toFloat() / total
}

object Smart {
    /** Prayer-type tasks lapse ("gugur") once this many minutes have passed since their scheduled time. */
    const val PRAYER_GRACE_MIN = 120

    /** Time-of-day phase for the Home scene: 0 pagi, 1 siang, 2 sore, 3 malam (same boundaries as the greeting). */
    fun phaseOf(hour: Int): Int = when { hour < 4 -> 3; hour < 11 -> 0; hour < 15 -> 1; hour < 18 -> 2; else -> 3 }
    val moodEmojis = arrayOf("😣", "😕", "😐", "🙂", "🤩")
    val moodLabels = arrayOf("Buruk", "Kurang baik", "Biasa", "Baik", "Hebat")
    val monthShort = arrayOf("Jan", "Feb", "Mar", "Apr", "Mei", "Jun", "Jul", "Agu", "Sep", "Okt", "Nov", "Des")
    private val levelTitles = arrayOf("Novice", "Rookie", "Steady", "Consistent", "Disciplined", "Elite", "Master", "Legend")
    private val prayerWords = listOf("shalat", "sholat", "salat", "ibadah", "subuh", "dzuhur", "zuhur", "ashar", "maghrib", "isya")

    fun levelTitle(level: Int): String = levelTitles[(level - 1).coerceIn(0, levelTitles.size - 1)]

    fun isPrayer(t: RillTask): Boolean {
        val s = (t.category + " " + t.name).lowercase(Locale.ROOT)
        return prayerWords.any { s.contains(it) }
    }

    fun weekdayLabel(weekday: Int): String = when (weekday) {
        Calendar.SUNDAY -> "Min"
        Calendar.MONDAY -> "Sen"
        Calendar.TUESDAY -> "Sel"
        Calendar.WEDNESDAY -> "Rab"
        Calendar.THURSDAY -> "Kam"
        Calendar.FRIDAY -> "Jum"
        else -> "Sab"
    }

    /** Per-day statistics for the last n days, oldest first (last item = today). */
    fun dayStats(context: Context, tasks: List<RillTask>, n: Int): List<DayStat> {
        val doneRoot = TaskStore.allDone(context)
        val wRoot = WorkoutStore.workoutDoneRoot(context)
        val workouts = WorkoutStore.load(context)
        val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val out = ArrayList<DayStat>()
        for (off in -(n - 1)..0) {
            val cal = Calendar.getInstance()
            cal.add(Calendar.DAY_OF_YEAR, off)
            val d = fmt.format(cal.time)
            val wd = cal.get(Calendar.DAY_OF_WEEK)
            val arr = doneRoot.optJSONArray(d)
            val daySched = tasks.filter { it.runsOn(wd) }
            val taskIds = daySched.map { it.id }.toSet()
            val prayerIds = daySched.filter { isPrayer(it) }.map { it.id }.toSet()
            var tasksDone = 0
            var prayerDone = 0
            if (arr != null) {
                for (i in 0 until arr.length()) {
                    val id = arr.optInt(i)
                    if (taskIds.contains(id)) {
                        tasksDone++
                        if (prayerIds.contains(id)) prayerDone++
                    }
                }
            }
            val sched = workouts.count { it.active && (if (it.oneOffDate.isNotBlank()) it.oneOffDate == d else it.days.contains(wd)) }
            val dayObj = wRoot.optJSONObject(d)
            var wDone = 0
            if (dayObj != null) {
                val keys = dayObj.keys()
                while (keys.hasNext()) if (dayObj.optBoolean(keys.next(), false)) wDone++
            }
            out.add(DayStat(d, wd, tasksDone, daySched.size, prayerDone, prayerIds.size, wDone, if (sched > wDone) sched else wDone))
        }
        return out
    }

    private fun habitOk(s: DayStat): Boolean = s.total > 0 && s.rate >= 0.5f

    /** Habit streak: consecutive days with at least 50% of the day's items done. Today is pending, never breaks it. */
    fun habitStreak(stats: List<DayStat>): Int {
        var i = stats.size - 1
        if (i >= 0 && !habitOk(stats[i])) i--
        var n = 0
        while (i >= 0 && habitOk(stats[i])) { n++; i-- }
        return n
    }

    fun bestHabitStreak(stats: List<DayStat>): Int {
        var best = 0
        var run = 0
        for (s in stats) {
            if (habitOk(s)) { run++; if (run > best) best = run } else run = 0
        }
        return best
    }

    /** Workout streak that understands rest days: only a missed scheduled day breaks it. */
    fun workoutStreak(stats: List<DayStat>): Int {
        var n = 0
        for (i in stats.indices.reversed()) {
            val s = stats[i]
            if (s.workoutDone > 0) {
                n++
            } else if (s.workoutTotal == 0) {
                continue
            } else if (i == stats.size - 1) {
                continue
            } else {
                break
            }
        }
        return n
    }

    fun bestWorkoutStreak(stats: List<DayStat>): Int {
        var best = 0
        var run = 0
        for (i in stats.indices) {
            val s = stats[i]
            if (s.workoutDone > 0) {
                run++
                if (run > best) best = run
            } else if (s.workoutTotal > 0 && i != stats.size - 1) {
                run = 0
            }
        }
        return best
    }

    /** mode 0 = 7 days, 1 = 30 days, 2 = 12 months. Returns values, x labels, tooltip details. */
    fun moodSeries(context: Context, mode: Int): Triple<List<Float?>, List<String>, List<String>> {
        val moods = WorkoutStore.moods(context)
        val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val values = ArrayList<Float?>()
        val labels = ArrayList<String>()
        val details = ArrayList<String>()
        if (mode == 2) {
            for (off in -11..0) {
                val cal = Calendar.getInstance()
                cal.set(Calendar.DAY_OF_MONTH, 1)
                cal.add(Calendar.MONTH, off)
                val prefix = SimpleDateFormat("yyyy-MM", Locale.US).format(cal.time)
                var sum = 0f
                var cnt = 0
                val it = moods.keys()
                while (it.hasNext()) {
                    val k = it.next()
                    if (k.startsWith(prefix)) {
                        sum += moods.optJSONObject(k)?.optInt("value", 0)?.toFloat() ?: 0f
                        cnt++
                    }
                }
                val avg: Float? = if (cnt == 0) null else sum / cnt
                values.add(avg)
                labels.add(monthShort[cal.get(Calendar.MONTH)])
                details.add(if (avg == null) monthShort[cal.get(Calendar.MONTH)] else "${monthShort[cal.get(Calendar.MONTH)]} · ${String.format(Locale.US, "%.1f", avg)}")
            }
        } else {
            val n = if (mode == 0) 7 else 30
            for (off in -(n - 1)..0) {
                val cal = Calendar.getInstance()
                cal.add(Calendar.DAY_OF_YEAR, off)
                val d = fmt.format(cal.time)
                val v = moods.optJSONObject(d)?.optInt("value", 0) ?: 0
                values.add(if (v in 1..5) v.toFloat() else null)
                val dom = cal.get(Calendar.DAY_OF_MONTH)
                labels.add(if (mode == 0) weekdayLabel(cal.get(Calendar.DAY_OF_WEEK)) else if ((n - 1 + off) % 5 == 0) "$dom" else "")
                details.add("$dom ${monthShort[cal.get(Calendar.MONTH)]}" + if (v in 1..5) " · ${moodEmojis[v - 1]} ${moodLabels[v - 1]}" else "")
            }
        }
        return Triple(values, labels, details)
    }

    fun moodCounts(context: Context, days: Int): IntArray {
        val moods = WorkoutStore.moods(context)
        val out = IntArray(5)
        val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        for (off in -(days - 1)..0) {
            val cal = Calendar.getInstance()
            cal.add(Calendar.DAY_OF_YEAR, off)
            val v = moods.optJSONObject(fmt.format(cal.time))?.optInt("value", 0) ?: 0
            if (v in 1..5) out[v - 1]++
        }
        return out
    }

    fun insights(context: Context, tasks: List<RillTask>, stats: List<DayStat>): List<String> {
        val out = ArrayList<String>()
        val last84 = stats.takeLast(84).filter { it.total > 0 }
        // 1. Best / hardest weekday
        val byDay = last84.groupBy { it.weekday }.mapValues { e -> e.value.map { it.rate }.average() }
        if (last84.size >= 7 && byDay.size >= 4) {
            val best = byDay.maxByOrNull { it.value }
            val worst = byDay.minByOrNull { it.value }
            if (best != null) out.add("📈 Hari paling konsisten: ${weekdayLabel(best.key)} (${(best.value * 100).toInt()}%)")
            if (best != null && worst != null && worst.key != best.key && best.value - worst.value >= 0.15) {
                out.add("🪫 Hari tersulit: ${weekdayLabel(worst.key)} (${(worst.value * 100).toInt()}%). Pilih target lebih ringan di hari ini.")
            }
        }
        // 2. Week-over-week trend
        val thisWeek = stats.takeLast(7).filter { it.total > 0 }
        val prevWeek = stats.takeLast(14).take(7).filter { it.total > 0 }
        if (thisWeek.isNotEmpty() && prevWeek.isNotEmpty()) {
            val diff = (thisWeek.map { it.rate }.average() - prevWeek.map { it.rate }.average()) * 100
            if (diff >= 5) out.add("🚀 Minggu ini naik ${diff.toInt()}% dibanding minggu lalu. Pertahankan!")
            else if (diff <= -5) out.add("🌧️ Minggu ini turun ${(-diff).toInt()}% dibanding minggu lalu. Tidak apa-apa, mulai lagi pelan-pelan.")
        }
        // 3. Weakest category (last 30 days, only days with some activity)
        val doneRoot = TaskStore.allDone(context)
        val possible = HashMap<String, Int>()
        val got = HashMap<String, Int>()
        for (s in stats.takeLast(30)) {
            if (s.tasksDone == 0) continue
            val arr = doneRoot.optJSONArray(s.date)
            val ids = HashSet<Int>()
            if (arr != null) for (i in 0 until arr.length()) ids.add(arr.optInt(i))
            for (t in tasks) {
                if (!t.runsOn(s.weekday)) continue
                possible[t.category] = (possible[t.category] ?: 0) + 1
                if (ids.contains(t.id)) got[t.category] = (got[t.category] ?: 0) + 1
            }
        }
        val weak = possible.filter { it.value >= 5 }.map { Pair(it.key, (got[it.key] ?: 0).toDouble() / it.value) }.minByOrNull { it.second }
        if (weak != null && weak.second < 0.7) out.add("⚠️ Kategori \"${weak.first}\" paling sering terlewat (${(weak.second * 100).toInt()}%).")
        // 4. Mood vs workout
        val moods = WorkoutStore.moods(context)
        val withW = ArrayList<Int>()
        val withoutW = ArrayList<Int>()
        for (s in stats.takeLast(90)) {
            val v = moods.optJSONObject(s.date)?.optInt("value", 0) ?: 0
            if (v !in 1..5) continue
            if (s.workoutDone > 0) withW.add(v) else withoutW.add(v)
        }
        if (withW.size >= 2 && withoutW.size >= 2) {
            val a = withW.average()
            val b = withoutW.average()
            if (a - b >= 0.3) out.add("💡 Moodmu lebih tinggi di hari kamu workout (${String.format(Locale.US, "%.1f", a)} vs ${String.format(Locale.US, "%.1f", b)}).")
        }
        // 5. Prayer consistency
        val pr = stats.takeLast(14)
        val pTotal = pr.sumOf { it.prayerTotal }
        if (pTotal > 0 && pr.any { it.tasksDone > 0 }) {
            out.add("🕌 Konsistensi ibadah 14 hari terakhir: ${pr.sumOf { it.prayerDone } * 100 / pTotal}%")
        }
        if (out.isEmpty()) out.add("Catat kegiatanmu beberapa hari — wawasan pintar akan muncul di sini.")
        return out
    }
}
