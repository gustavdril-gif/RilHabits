package com.airil.rillrebirth

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.os.SystemClock
import android.view.View
import kotlin.math.cos
import kotlin.math.sin

/** The seed on a black screen (intro). seedY is a fraction of the height; it can be animated to make the seed fall. */
class SeedView(context: Context) : View(context) {
    private val d = context.resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    var seedY = 0.42f
        set(v) { field = v; invalidate() }
    var glow = true

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val cx = w / 2f; val cy = h * seedY
        val t = SystemClock.uptimeMillis() / 1000f
        if (glow) {
            val pulse = 0.75f + 0.25f * sin(t * 1.8f)
            val r = 64f * d * pulse
            p.shader = RadialGradient(cx, cy, r, 0x553E8E5A, 0x003E8E5A, Shader.TileMode.CLAMP)
            c.drawCircle(cx, cy, r, p); p.shader = null
        }
        // seed body
        p.color = 0xFF7A4A24.toInt()
        c.drawOval(RectF(cx - 11 * d, cy - 15 * d, cx + 11 * d, cy + 15 * d), p)
        p.color = 0xFF9A6234.toInt()
        c.drawOval(RectF(cx - 7 * d, cy - 11 * d, cx + 2 * d, cy + 2 * d), p)
        // tiny green tip
        p.color = 0xFF7BC96F.toInt()
        c.drawOval(RectF(cx - 2.5f * d, cy - 19 * d, cx + 2.5f * d, cy - 12 * d), p)
        postInvalidateDelayed(50)
    }
}

/** Three rounded bars: a drawn "hamburger" icon (no font dependency). */
class MenuIconView(context: Context) : View(context) {
    private val d = context.resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val bw = 20 * d; val bh = 2.6f * d; val gap = 5.5f * d
        val left = (w - bw) / 2f; val top = (h - (3 * bh + 2 * gap)) / 2f
        for (i in 0 until 3) {
            val y = top + i * (bh + gap)
            c.drawRoundRect(left, y, left + bw, y + bh, bh, bh, p)
        }
    }
}

/** Soft breathing circle for the "Dorongan datang" screen. scale 0..1. */
class BreathView(context: Context) : View(context) {
    private val d = context.resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    var scale = 0.5f
        set(v) { field = v; invalidate() }
    override fun onDraw(c: Canvas) {
        val cx = width / 2f; val cy = height / 2f
        val max = minOf(width, height) / 2f - 6 * d
        val r = max * (0.45f + 0.55f * scale)
        p.shader = RadialGradient(cx, cy, r, intArrayOf(0x887BC96F.toInt(), 0x443E8E5A, 0x003E8E5A), floatArrayOf(0f, 0.7f, 1f), Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, r, p); p.shader = null
        p.color = 0xCCB7F0B0.toInt(); p.style = Paint.Style.STROKE; p.strokeWidth = 2 * d
        c.drawCircle(cx, cy, r * 0.62f, p); p.style = Paint.Style.FILL
    }
}

/**
 * Nostalgic meadow: bright blue sky, drifting clouds, green hills and a plant that grows through eight stages.
 * stage 0 is a sprout that has not opened yet.
 */
class MeadowView(context: Context) : View(context) {
    private val d = context.resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stem = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val path = Path()
    private val far = Path()
    private val near = Path()
    private var sky: Shader? = null
    private var ground: Shader? = null
    private val tufts = FloatArray(70 * 3)

    var stage = 0
        set(v) { field = v.coerceIn(0, 7); invalidate() }
    var recentSlip = false

    private val stemH = floatArrayOf(26f, 46f, 74f, 108f, 140f, 168f, 190f, 205f)
    private val trunkW = floatArrayOf(3f, 3.5f, 4.5f, 6f, 9f, 12f, 14f, 16f)

    init {
        val r = java.util.Random(21)
        for (i in 0 until 70) { tufts[i * 3] = r.nextFloat(); tufts[i * 3 + 1] = 0.54f + r.nextFloat() * 0.44f; tufts[i * 3 + 2] = 0.7f + r.nextFloat() * 0.8f }
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        val wf = w.toFloat(); val hf = h.toFloat()
        sky = LinearGradient(0f, 0f, 0f, hf * 0.5f, intArrayOf(0xFF3F9FEA.toInt(), 0xFF8FD0FA.toInt(), 0xFFD6F0FF.toInt()), floatArrayOf(0f, 0.6f, 1f), Shader.TileMode.CLAMP)
        ground = LinearGradient(0f, hf * 0.44f, 0f, hf, 0xFF72C84E.toInt(), 0xFF3E9A36.toInt(), Shader.TileMode.CLAMP)
        far.reset(); far.moveTo(0f, hf * 0.40f)
        far.quadTo(wf * 0.25f, hf * 0.30f, wf * 0.55f, hf * 0.40f)
        far.quadTo(wf * 0.80f, hf * 0.48f, wf, hf * 0.36f)
        far.lineTo(wf, hf); far.lineTo(0f, hf); far.close()
        near.reset(); near.moveTo(0f, hf * 0.47f)
        near.quadTo(wf * 0.30f, hf * 0.40f, wf * 0.50f, hf * 0.46f)
        near.quadTo(wf * 0.75f, hf * 0.53f, wf, hf * 0.44f)
        near.lineTo(wf, hf); near.lineTo(0f, hf); near.close()
    }

    private fun cloud(c: Canvas, x: Float, y: Float, s: Float) {
        p.color = 0xF2FFFFFF.toInt()
        c.drawCircle(x + s * 0.30f, y, s * 0.34f, p)
        c.drawCircle(x + s * 0.64f, y - s * 0.20f, s * 0.44f, p)
        c.drawCircle(x + s * 1.02f, y, s * 0.34f, p)
        c.drawRoundRect(x, y - s * 0.02f, x + s * 1.34f, y + s * 0.32f, s * 0.16f, s * 0.16f, p)
    }

    private fun leaf(c: Canvas, x: Float, y: Float, angle: Float, len: Float, color: Int) {
        p.color = color
        c.save(); c.rotate(angle, x, y)
        c.drawOval(RectF(x, y - len * 0.26f, x + len, y + len * 0.26f), p)
        c.restore()
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        if (w <= 0f) return
        val t = SystemClock.uptimeMillis() / 1000f
        p.shader = sky; c.drawRect(0f, 0f, w, h * 0.5f, p); p.shader = null
        // sun
        p.shader = RadialGradient(w * 0.82f, h * 0.10f, 90 * d, 0xAAFFF3B0.toInt(), 0x00FFF3B0, Shader.TileMode.CLAMP)
        c.drawCircle(w * 0.82f, h * 0.10f, 90 * d, p); p.shader = null
        p.color = 0xFFFFF0A0.toInt(); c.drawCircle(w * 0.82f, h * 0.10f, 20 * d, p)
        // clouds
        for (i in 0 until 4) {
            val x = ((0.1f + i * 0.27f + t * (0.004f + i * 0.0012f)) % 1.4f) * (w + 140 * d) - 110 * d
            cloud(c, x, h * (0.08f + 0.055f * ((i * 3) % 4)), (46 + i * 8) * d)
        }
        p.color = 0xFF9BDB78.toInt(); c.drawPath(far, p)
        p.shader = ground; c.drawPath(near, p); p.shader = null
        // grass tufts
        p.style = Paint.Style.STROKE; p.strokeCap = Paint.Cap.ROUND; p.strokeWidth = 1.6f * d; p.color = 0x992F7F2C.toInt()
        for (i in 0 until 70) {
            val x = tufts[i * 3] * w; val y = tufts[i * 3 + 1] * h; val s = tufts[i * 3 + 2] * 7 * d
            val sw = sin(t * 1.4f + i) * 1.2f * d
            c.drawLine(x, y, x - 3 * d + sw, y - s, p); c.drawLine(x, y, x + sw, y - s * 1.2f, p); c.drawLine(x, y, x + 3 * d + sw, y - s, p)
        }
        p.style = Paint.Style.FILL
        drawPlant(c, w * 0.5f, h * 0.46f, t)
        postInvalidateDelayed(66)
    }

    private fun drawPlant(c: Canvas, cx: Float, base: Float, t: Float) {
        // soil mound
        p.color = 0xFF6B4A2B.toInt(); c.drawOval(RectF(cx - 24 * d, base - 5 * d, cx + 24 * d, base + 7 * d), p)
        p.color = 0xFF84603A.toInt(); c.drawOval(RectF(cx - 16 * d, base - 5 * d, cx + 12 * d, base + 1 * d), p)
        if (recentSlip) { p.color = 0xFFB08A4A.toInt(); c.drawOval(RectF(cx + 26 * d, base + 2 * d, cx + 38 * d, base + 7 * d), p); c.drawOval(RectF(cx - 40 * d, base + 4 * d, cx - 28 * d, base + 9 * d), p) }
        val sh = stemH[stage] * d
        val sway = sin(t * 1.3f) * (1.6f + stage * 0.5f) * d
        val topX = cx + sway; val topY = base - sh
        val green = 0xFF4CAF50.toInt(); val brown = 0xFF7A5230.toInt()
        stem.strokeWidth = trunkW[stage] * d
        stem.color = if (stage >= 3) brown else green
        path.reset(); path.moveTo(cx, base); path.quadTo(cx + sway * 0.25f, base - sh * 0.5f, topX, topY)
        c.drawPath(path, stem)
        if (stage <= 3) {
            val g1 = 0xFF66BB6A.toInt(); val g2 = 0xFF43A047.toInt()
            when (stage) {
                0 -> { leaf(c, topX, topY, -78f, 13 * d, g1); leaf(c, topX, topY, -102f, 13 * d, g2) }   // closed bud
                1 -> { leaf(c, topX, topY, -42f, 18 * d, g1); leaf(c, topX, topY, -138f, 18 * d, g2) }
                2 -> {
                    leaf(c, topX, topY, -40f, 22 * d, g1); leaf(c, topX, topY, -140f, 22 * d, g2)
                    leaf(c, cx + sway * 0.4f, base - sh * 0.55f, -30f, 20 * d, g2); leaf(c, cx + sway * 0.4f, base - sh * 0.55f, -150f, 20 * d, g1)
                }
                else -> {
                    leaf(c, topX, topY, -38f, 26 * d, g1); leaf(c, topX, topY, -142f, 26 * d, g2)
                    leaf(c, cx + sway * 0.6f, base - sh * 0.62f, -28f, 24 * d, g2); leaf(c, cx + sway * 0.6f, base - sh * 0.62f, -152f, 24 * d, g1)
                    leaf(c, cx + sway * 0.25f, base - sh * 0.34f, -22f, 22 * d, g1); leaf(c, cx + sway * 0.25f, base - sh * 0.34f, -158f, 22 * d, g2)
                }
            }
        } else {
            val idx = stage - 4
            val n = intArrayOf(5, 7, 9, 12)[idx]
            val big = floatArrayOf(30f, 38f, 46f, 54f)[idx] * d
            val shades = intArrayOf(0xFF2E7D32.toInt(), 0xFF43A047.toInt(), 0xFF66BB6A.toInt())
            for (k in 0 until n) {
                val a = k * 2.399f
                val dist = big * 0.55f * ((k % 4) + 1) / 4f
                val x = topX + cos(a) * dist
                val y = topY - big * 0.25f + sin(a) * dist * 0.7f
                p.color = shades[k % 3]
                c.drawCircle(x, y, big * (0.55f + 0.15f * ((k * 7) % 4) / 3f), p)
            }
            if (stage >= 6) {
                p.color = 0xFFE53935.toInt()
                for (k in 0 until 6) c.drawCircle(topX + cos(k * 1.05f + 0.4f) * big * 0.7f, topY - big * 0.15f + sin(k * 1.05f + 0.4f) * big * 0.5f, 3.4f * d, p)
            }
            if (stage >= 7) {
                p.color = 0xFFFF8FB1.toInt()
                for (k in 0 until 8) c.drawCircle(topX + cos(k * 0.8f + 1f) * big * 0.85f, topY - big * 0.3f + sin(k * 0.8f + 1f) * big * 0.55f, 3f * d, p)
            }
        }
    }
}
