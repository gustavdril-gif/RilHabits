package com.airil.rillrebirth

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.app.Activity
import android.app.AlertDialog
import android.app.TimePickerDialog
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.media.ExifInterface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.CountDownTimer
import android.os.Handler
import android.os.Looper
import android.os.Vibrator
import android.provider.OpenableColumns
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.view.animation.AccelerateInterpolator
import android.view.animation.LinearInterpolator
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import kotlin.math.max

/**
 * "Ruang Tenang": a private recovery space with its own look. It is opened by saving the secret code as a note,
 * is hidden from screenshots, and closes itself as soon as the app is left.
 */
class SecretActivity : Activity() {
    companion object { const val REQ_PHOTO = 5101; const val REQ_AUDIO = 5102 }

    private val d by lazy { resources.displayMetrics.density }
    private fun dp(v: Int) = (v * d).toInt()
    private val sw by lazy { resources.displayMetrics.widthPixels }
    private val sh by lazy { resources.displayMetrics.heightPixels }
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var root: FrameLayout

    private val ink = 0xFF1F2D1F.toInt()
    private val muted = 0xFF66786A.toInt()
    private val leaf = 0xFF3E8E5A.toInt()
    private val leafSoft = 0xFFE3F3E6.toInt()
    private val warm = 0xFFEF9A3C.toInt()

    private var picking = false
    private var overlay: View? = null
    private var overlayKind = ""
    private var overlayCleanup: (() -> Unit)? = null
    private var meadow: MeadowView? = null
    private var roomCol: LinearLayout? = null
    private val floaters = mutableListOf<ObjectAnimator>()

    // intro state
    private val phrases = listOf(
        "Ini adalah harapan kamu untuk berubah",
        "Harapanmu akan terus tumbuh bila kamu dapat konsisten",
        "Aku paham, kamu pasti ingin sembuh, kan?",
        "Apakah kamu siap untuk bertumbuh?"
    )
    private var introStep = -1
    private var introBusy = false
    private var seedView: SeedView? = null
    private var msgView: TextView? = null
    private var hintView: TextView? = null
    private var buttonsView: LinearLayout? = null

    // ---------- helpers ----------
    private fun rounded(color: Int, r: Int) = GradientDrawable().apply { setColor(color); cornerRadius = dp(r).toFloat() }
    private fun tv(s: String, size: Float, color: Int = ink, bold: Boolean = false) = TextView(this).apply {
        text = s; textSize = size; setTextColor(color); if (bold) setTypeface(typeface, Typeface.BOLD); setPadding(dp(2), dp(3), dp(2), dp(3))
    }
    private fun btn(label: String, primary: Boolean, onClick: () -> Unit) = TextView(this).apply {
        text = label; gravity = Gravity.CENTER; textSize = 15f; setTypeface(typeface, Typeface.BOLD)
        setTextColor(if (primary) Color.WHITE else leaf); background = rounded(if (primary) leaf else leafSoft, 16)
        setPadding(dp(16), dp(13), dp(16), dp(13)); setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(6), 0, dp(6)) }
    }
    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(14), dp(16), dp(14)); background = rounded(0xF5FFFFFF.toInt(), 22)
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(6), 0, dp(6)) }
    }
    private fun vibrate(ms: Long) { try { val v = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator; v.vibrate(ms) } catch (_: Exception) { } }

    // ---------- lifecycle ----------
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        window.setBackgroundDrawable(ColorDrawable(Color.BLACK))
        window.statusBarColor = Color.BLACK; window.navigationBarColor = Color.BLACK
        root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        setContentView(root)
        if (SecretStore.introDone(this)) showWelcomeBack() else showIntro()
    }

    override fun onResume() { super.onResume(); picking = false }

    override fun onStop() {
        super.onStop()
        if (!picking && !isChangingConfigurations) finish()
    }

    override fun onDestroy() {
        floaters.forEach { it.cancel() }
        overlayCleanup?.invoke()
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    @Deprecated("Back handling")
    override fun onBackPressed() { if (overlay != null) dismissOverlay() else finish() }

    // ---------- intro ----------
    private fun buildIntroBase(): Triple<SeedView, TextView, TextView> {
        root.removeAllViews(); root.setBackgroundColor(Color.BLACK)
        val seed = SeedView(this); root.addView(seed, FrameLayout.LayoutParams(-1, -1))
        val msg = TextView(this).apply {
            gravity = Gravity.CENTER; textSize = 20f; setTextColor(0xFFEAF7EA.toInt()); typeface = Typeface.SERIF
            setPadding(dp(36), 0, dp(36), 0); alpha = 0f; setLineSpacing(0f, 1.2f)
        }
        root.addView(msg, FrameLayout.LayoutParams(-1, -2, Gravity.TOP).apply { topMargin = (sh * 0.55f).toInt() })
        val hint = TextView(this).apply { text = "ketuk untuk melanjutkan"; textSize = 13f; setTextColor(0xFF7E9A82.toInt()); gravity = Gravity.CENTER; alpha = 0f }
        root.addView(hint, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM).apply { bottomMargin = dp(56) })
        hint.animate().alpha(0.9f).setStartDelay(900).setDuration(900).start()
        seedView = seed; msgView = msg; hintView = hint
        return Triple(seed, msg, hint)
    }

    private fun showIntro() {
        buildIntroBase()
        val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; alpha = 0f; visibility = View.GONE }
        val yes = TextView(this).apply {
            text = "Ya"; gravity = Gravity.CENTER; textSize = 17f; setTypeface(typeface, Typeface.BOLD); setTextColor(Color.WHITE)
            background = rounded(0xFF3E8E5A.toInt(), 28); setPadding(dp(44), dp(14), dp(44), dp(14)); setOnClickListener { onYes() }
        }
        val no = TextView(this).apply {
            text = "Belum"; gravity = Gravity.CENTER; textSize = 17f; setTextColor(0xFFB7CDB9.toInt())
            background = GradientDrawable().apply { setColor(Color.TRANSPARENT); setStroke(dp(1), 0xFF58705C.toInt()); cornerRadius = dp(28).toFloat() }
            setPadding(dp(36), dp(14), dp(36), dp(14)); setOnClickListener { onNotYet() }
        }
        buttons.addView(yes, LinearLayout.LayoutParams(-2, -2).apply { setMargins(dp(8), 0, dp(8), 0) })
        buttons.addView(no, LinearLayout.LayoutParams(-2, -2).apply { setMargins(dp(8), 0, dp(8), 0) })
        root.addView(buttons, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM).apply { bottomMargin = dp(96) })
        buttonsView = buttons
        root.setOnClickListener { onIntroTap() }
    }

    private fun showPhrase(s: String, after: () -> Unit = {}) {
        val m = msgView ?: return
        introBusy = true
        val fadeIn = { m.text = s; m.animate().alpha(1f).setDuration(800).withEndAction { introBusy = false; after() }.start() }
        if (m.alpha > 0.01f) m.animate().alpha(0f).setDuration(450).withEndAction { fadeIn() }.start() else fadeIn()
    }

    private fun onIntroTap() {
        if (introBusy || introStep >= phrases.size - 1) return
        introStep++
        val last = introStep == phrases.size - 1
        showPhrase(phrases[introStep]) {
            if (last) {
                val b = buttonsView ?: return@showPhrase
                b.visibility = View.VISIBLE; b.animate().alpha(1f).setDuration(700).start()
            }
        }
        if (last) hintView?.animate()?.alpha(0f)?.setDuration(400)?.start()
    }

    private fun onNotYet() {
        if (introBusy) return
        introBusy = true
        buttonsView?.animate()?.alpha(0f)?.setDuration(300)?.start()
        showPhrase("Tidak apa-apa. Tunasmu akan menunggu sampai kamu siap.") { introBusy = true }
        handler.postDelayed({ finish() }, 3200)
    }

    private fun onYes() {
        if (introBusy && introStep < phrases.size - 1) return
        introBusy = true
        SecretStore.markIntroDone(this)
        buttonsView?.animate()?.alpha(0f)?.setDuration(300)?.start()
        msgView?.animate()?.alpha(0f)?.setDuration(500)?.start()
        val seed = seedView ?: return
        handler.postDelayed({
            ValueAnimator.ofFloat(0.42f, 0.9f).apply {
                duration = 850; interpolator = AccelerateInterpolator(1.7f)
                addUpdateListener { seed.seedY = it.animatedValue as Float }
                addListener(object : AnimatorListenerAdapter() {
                    override fun onAnimationEnd(animation: Animator) {
                        seed.glow = false
                        SecretSound.thud(); vibrate(45)
                        handler.postDelayed({ enterRoom() }, 1100)
                    }
                })
                start()
            }
        }, 650)
    }

    private fun showWelcomeBack() {
        buildIntroBase()
        hintView?.text = "ketuk untuk masuk"
        handler.postDelayed({ msgView?.text = "Selamat datang kembali"; msgView?.animate()?.alpha(1f)?.setDuration(900)?.start() }, 500)
        root.setOnClickListener { root.setOnClickListener(null); enterRoom() }
    }

    // ---------- room ----------
    private fun enterRoom() {
        val old = (0 until root.childCount).map { root.getChildAt(it) }
        val room = buildRoom()
        room.alpha = 0f
        root.addView(room, FrameLayout.LayoutParams(-1, -1))
        root.setOnClickListener(null)
        window.statusBarColor = 0xFF3F9FEA.toInt(); window.navigationBarColor = 0xFF3E9A36.toInt()
        room.animate().alpha(1f).setDuration(1100).withEndAction { old.forEach { root.removeView(it) }; root.setBackgroundColor(Color.TRANSPARENT) }.start()
    }

    private fun buildRoom(): FrameLayout {
        val room = FrameLayout(this)
        val m = MeadowView(this); meadow = m
        room.addView(m, FrameLayout.LayoutParams(-1, -1))
        val scroll = ScrollView(this).apply { isVerticalScrollBarEnabled = false; overScrollMode = View.OVER_SCROLL_NEVER }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), 0, dp(16), dp(36)) }
        roomCol = col
        scroll.addView(col, FrameLayout.LayoutParams(-1, -2))
        room.addView(scroll, FrameLayout.LayoutParams(-1, -1))
        // top bar
        val menu = FrameLayout(this).apply { background = rounded(0x66000000, 22); setOnClickListener { showSettings() } }
        menu.addView(MenuIconView(this), FrameLayout.LayoutParams(-1, -1))
        room.addView(menu, FrameLayout.LayoutParams(dp(44), dp(44), Gravity.TOP or Gravity.START).apply { setMargins(dp(14), dp(12), 0, 0) })
        val exit = tv("Keluar", 13f, Color.WHITE, true).apply { background = rounded(0x66000000, 20); setPadding(dp(16), dp(10), dp(16), dp(10)); setOnClickListener { finish() } }
        room.addView(exit, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.END).apply { setMargins(0, dp(14), dp(14), 0) })
        populate()
        return room
    }

    private fun refreshRoom() { populate() }

    private fun dateLabel(date: String): String {
        val today = SecretStore.today()
        val y = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -1) }.let { SimpleDateFormat("yyyy-MM-dd", Locale.US).format(it.time) }
        return when (date) { today -> "hari ini"; y -> "kemarin"; else -> try { SimpleDateFormat("d MMMM", Locale("id", "ID")).format(SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(date)!!) } catch (_: Exception) { date } }
    }

    private fun phaseFor(streak: Int): Pair<String, String> = when {
        streak <= 0 -> Pair("Mulai lagi hari ini", "Setiap hari baru adalah kesempatan baru. Pilih satu hal kecil untuk dilakukan hari ini.")
        streak <= 3 -> Pair("Tunas kecil", "Awal sering menjadi bagian paling sulit. Dorongan yang kuat dan rasa gelisah itu wajar.")
        streak <= 14 -> Pair("Akar mencari tanah", "Banyak orang merasa gelisah, sulit fokus, dan mood naik turun di fase ini. Biasanya sementara. Jaga tidur, makan, dan geraklah.")
        streak <= 30 -> Pair("Tunas menembus tanah", "Mulai terasa lebih stabil. Sebagian orang merasa datar atau kurang semangat, itu umum dan akan berlalu.")
        streak <= 60 -> Pair("Batang menguat", "Kebiasaan barumu mulai kokoh. Jaga rutinitas tidur, olahraga, dan kegiatan yang bermakna.")
        streak <= 90 -> Pair("Daun pertama", "Kamu mendekati 90 hari, angka yang dipakai banyak komunitas sebagai penyemangat, bukan garis akhir ilmiah.")
        streak <= 180 -> Pair("Pohon muda", "Kamu sudah jauh. Fokuskan energi ke hal-hal yang kamu cita-citakan.")
        streak <= 365 -> Pair("Pohon berbuah", "Hasil dari konsistensimu mulai terasa. Tetap rendah hati dan waspada pada pemicu lama.")
        else -> Pair("Pohon rimbun", "Kamu sudah menjadi tempat berteduh bagi dirimu sendiri.")
    }

    private fun populate() {
        val col = roomCol ?: return
        floaters.forEach { it.cancel() }; floaters.clear()
        col.removeAllViews()
        val st = SecretStore.stats(this)
        meadow?.stage = SecretStore.stageFor(st.total)
        meadow?.recentSlip = st.lastStatus == "f"
        col.addView(View(this), LinearLayout.LayoutParams(-1, (sh * 0.47f).toInt()))

        // check-in
        val pending = SecretStore.pendingDates(this)
        val ci = card()
        if (pending.isNotEmpty()) {
            val date = pending.first()
            ci.addView(tv("Check-in ${dateLabel(date)}", 17f, ink, true))
            ci.addView(tv("Jujur pada dirimu sendiri adalah langkah pertama. Apakah kamu berhasil bertahan ${dateLabel(date)}?", 13f, muted))
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            val ok = btn("Berhasil 🌱", true) { answer(date, true) }
            val no = btn("Gagal", false) { answer(date, false) }
            row.addView(ok, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(0, dp(6), dp(5), dp(6)) })
            row.addView(no, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(5), dp(6), 0, dp(6)) })
            ci.addView(row)
            if (pending.size > 1) ci.addView(tv("+${pending.size - 1} hari lain menunggu jawabanmu", 12f, muted))
        } else {
            val hr = SecretStore.checkinHour(this)
            ci.addView(tv(if (SecretStore.readLog(this).containsKey(SecretStore.today())) "Check-in hari ini sudah tercatat ✅" else "Check-in hari ini terbuka pukul ${String.format(Locale.US, "%02d:00", hr)}", 15f, ink, true))
            ci.addView(tv("Kamu bisa mengubah jamnya di Pengaturan (ikon garis tiga).", 12f, muted))
        }
        col.addView(ci)

        // journey
        val jc = card()
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.BOTTOM }
        head.addView(tv("${st.streak}", 46f, leaf, true))
        head.addView(tv("hari bertahan", 15f, muted).apply { setPadding(dp(8), 0, 0, dp(10)) })
        jc.addView(head)
        val (pt, pd) = phaseFor(st.streak)
        jc.addView(tv(pt, 16f, ink, true)); jc.addView(tv(pd, 13f, muted))
        val next = SecretStore.MILESTONES.firstOrNull { it > st.streak }
        if (next != null) jc.addView(tv("Tinggal ${next - st.streak} hari menuju $next hari", 12f, leaf, true).apply { setPadding(dp(2), dp(8), dp(2), dp(2)) })
        val tiles = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(10), 0, 0) }
        fun tile(v: String, l: String) = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(0, dp(10), 0, dp(10)); background = rounded(leafSoft, 14)
            addView(tv(v, 18f, ink, true).apply { gravity = Gravity.CENTER }); addView(tv(l, 11f, muted).apply { gravity = Gravity.CENTER })
        }
        tiles.addView(tile("${st.best}", "rekor"), LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(0, 0, dp(4), 0) })
        tiles.addView(tile("${st.total}", "total hari bersih"), LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(4), 0, dp(4), 0) })
        tiles.addView(tile("${SecretStore.urges(this)}", "dorongan terlewati"), LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(4), 0, 0, 0) })
        jc.addView(tiles)
        jc.addView(tv("Tahapan ini gambaran umum dari pengalaman banyak orang, bukan diagnosis medis dan tiap orang berbeda.", 11f, muted).apply { setPadding(dp(2), dp(10), dp(2), 0) })
        col.addView(jc)

        // urge
        val sos = btn("Dorongan datang? Ketuk di sini", true) { showSos() }
        sos.background = rounded(warm, 18)
        col.addView(sos)

        // reason
        val rc = card()
        rc.addView(tv("Alasanku", 16f, ink, true))
        val reason = SecretStore.reason(this)
        rc.addView(tv(if (reason.isBlank()) "Tulis alasanmu berhenti. Kamu akan melihatnya saat dorongan datang." else reason, 14f, if (reason.isBlank()) muted else ink).apply { if (reason.isNotBlank()) typeface = Typeface.SERIF })
        rc.addView(btn(if (reason.isBlank()) "Tulis alasan" else "Ubah alasan", false) { editReason() })
        col.addView(rc)

        // gallery
        col.addView(buildGallery())

        // history
        col.addView(buildHistory())

        // badges
        val bc = card()
        bc.addView(tv("Lencana 🏅", 16f, ink, true))
        val brow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(6), 0, dp(2)) }
        SecretStore.MILESTONES.forEach { n ->
            val got = st.best >= n
            brow.addView(tv(if (got) "🏅 $n" else "$n", 13f, if (got) Color.WHITE else muted, got).apply {
                gravity = Gravity.CENTER; background = rounded(if (got) leaf else 0xFFEAF0EA.toInt(), 14); setPadding(dp(12), dp(8), dp(12), dp(8))
            }, LinearLayout.LayoutParams(-2, -2).apply { setMargins(0, 0, dp(6), 0) })
        }
        bc.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(brow) })
        bc.addView(tv("Lencana dihitung dari rekor streak terbaikmu (hari).", 11f, muted))
        col.addView(bc)
    }

    // ---------- check-in ----------
    private fun answer(date: String, ok: Boolean) {
        SecretStore.setStatus(this, date, if (ok) "s" else "f")
        val st = SecretStore.stats(this)
        if (ok) {
            if (st.streak > 0 && SecretStore.MILESTONES.contains(st.streak)) {
                AlertDialog.Builder(this, R.style.RillDialog).setTitle("🏅 ${st.streak} hari!")
                    .setMessage("Kamu bertahan ${st.streak} hari berturut-turut. Tunasmu terus bertumbuh, aku bangga padamu.").setPositiveButton("Lanjut", null).show()
            } else Toast.makeText(this, "Tercatat 🌱 Hari ke-${st.streak}", Toast.LENGTH_SHORT).show()
            vibrate(30)
        } else showSlipSheet(date)
        refreshRoom()
    }

    private val affirmations = listOf(
        "Satu hari yang jatuh bukan akhir ceritamu. Pohon yang kuat pun pernah dihantam angin.",
        "Kamu tidak mulai dari nol. Semua hari bersihmu tetap tersimpan dan tetap berarti.",
        "Mengakui dengan jujur itu keberanian. Itu langkah pertama untuk bangkit lagi.",
        "Yang menentukan dirimu bukan kapan kamu jatuh, tapi kapan kamu memutuskan berdiri lagi.",
        "Rasa kecewa itu tanda kamu peduli pada dirimu. Peluk dulu dirimu, lalu lanjutkan.",
        "Tunas yang patah daunnya masih punya akar. Akarmu masih di sana.",
        "Hari ini boleh berat. Besok kamu punya kesempatan baru, dan itu gratis.",
        "Kamu sudah sejauh ini. Satu langkah mundur tidak menghapus semua langkah maju."
    )
    private val tips = listOf(
        "Cari tahu pemicunya: jam, tempat, atau perasaan. Pola yang terlihat bisa kamu putus.",
        "Jauhkan HP dari tempat tidur dan jangan memakainya sendirian di kamar tertutup saat malam.",
        "Saat dorongan datang, bergeraklah 10 menit (jalan, push-up, jogging). Dorongan biasanya naik lalu turun sendiri.",
        "Ceritakan ke orang yang kamu percaya. Beban yang dibagi terasa lebih ringan.",
        "Tidur lebih awal. Lelah dan begadang membuat dorongan lebih sulit dilawan.",
        "Siapkan rencana 'kalau-maka': kalau dorongan datang, maka aku keluar kamar dan minum air.",
        "Blokir atau hapus akses ke hal yang menjadi pemicu utamamu."
    )

    private fun showSlipSheet(date: String) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(4), dp(20), dp(4)) }
        box.addView(tv(affirmations.random(), 16f, ink, true).apply { typeface = Typeface.SERIF })
        box.addView(tv("Beberapa saran untuk langkah berikutnya", 12f, muted, true).apply { setPadding(dp(2), dp(14), dp(2), dp(4)) })
        tips.shuffled().take(3).forEach { box.addView(tv("• $it", 14f, ink)) }
        if (SecretStore.recentFails(this, 7) >= 3) box.addView(tv("Kalau terasa sulit dikendalikan meski sudah berusaha, bicara dengan psikolog atau konselor bisa sangat membantu. Itu bukan tanda lemah.", 13f, leaf, true).apply { setPadding(dp(2), dp(12), dp(2), dp(2)) })
        val note = EditText(this).apply { hint = "Apa yang terjadi sebelumnya? (opsional, hanya untukmu)"; minLines = 2; gravity = Gravity.TOP; inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE }
        box.addView(note, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })
        AlertDialog.Builder(this, R.style.RillDialog).setTitle("Tidak apa-apa 💚").setView(ScrollView(this).apply { addView(box) })
            .setPositiveButton("Bangkit lagi 🌱") { _, _ -> SecretStore.addTrigger(this, date, note.text.toString()); refreshRoom() }.show()
    }

    // ---------- reason ----------
    private fun editReason() {
        val e = EditText(this).apply { hint = "Kenapa kamu ingin berubah?"; minLines = 3; gravity = Gravity.TOP; inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES; setText(SecretStore.reason(this@SecretActivity)) }
        AlertDialog.Builder(this, R.style.RillDialog).setTitle("Alasanku").setView(e)
            .setPositiveButton("Simpan") { _, _ -> SecretStore.setReason(this, e.text.toString()); refreshRoom() }.setNegativeButton("Batal", null).show()
    }

    // ---------- overlays ----------
    private fun showOverlay(view: View, kind: String, cleanup: (() -> Unit)? = null) {
        dismissOverlay()
        overlay = view; overlayKind = kind; overlayCleanup = cleanup
        view.alpha = 0f
        root.addView(view, FrameLayout.LayoutParams(-1, -1))
        view.animate().alpha(1f).setDuration(250).start()
    }

    private fun dismissOverlay() {
        overlayCleanup?.invoke(); overlayCleanup = null
        overlay?.let { root.removeView(it) }
        overlay = null; overlayKind = ""
    }

    // ---------- urge ("Dorongan datang") ----------
    private fun showSos() {
        val panel = FrameLayout(this).apply { setBackgroundColor(0xF2081410.toInt()); isClickable = true }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; setPadding(dp(24), dp(40), dp(24), dp(24)) }
        col.addView(tv("Dorongan datang? Tidak apa-apa.", 22f, Color.WHITE, true).apply { gravity = Gravity.CENTER })
        col.addView(tv("Dorongan itu naik lalu turun sendiri. Ikuti napasmu.", 14f, 0xFFB7CDB9.toInt()).apply { gravity = Gravity.CENTER })
        val breath = BreathView(this)
        col.addView(breath, LinearLayout.LayoutParams(dp(230), dp(230)).apply { topMargin = dp(16) })
        val phase = tv("Tarik napas…", 18f, 0xFFD6F5D0.toInt(), true).apply { gravity = Gravity.CENTER }
        col.addView(phase)
        val clock = tv("10:00", 28f, Color.WHITE, true).apply { gravity = Gravity.CENTER; setPadding(0, dp(8), 0, dp(4)) }
        col.addView(clock)
        val reason = SecretStore.reason(this)
        if (reason.isNotBlank()) col.addView(tv("“$reason”", 14f, 0xFFEAF7EA.toInt()).apply { gravity = Gravity.CENTER; typeface = Typeface.SERIF; setPadding(dp(8), dp(10), dp(8), dp(4)) })
        col.addView(tv("Sambil menunggu: pindah ruangan, minum air, atau push-up 20 kali.", 13f, 0xFF93AD97.toInt()).apply { gravity = Gravity.CENTER; setPadding(dp(8), dp(8), dp(8), dp(8)) })
        val calm = btn("Aku sudah tenang 🌿", true) { SecretStore.addUrge(this); Toast.makeText(this, "Hebat. Kamu melewati satu dorongan.", Toast.LENGTH_LONG).show(); dismissOverlay(); refreshRoom() }
        val close = btn("Tutup", false) { dismissOverlay() }
        col.addView(calm); col.addView(close)
        panel.addView(ScrollView(this).apply { addView(col) }, FrameLayout.LayoutParams(-1, -1))
        val anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 10000; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
            addUpdateListener {
                val f = it.animatedFraction
                val s = if (f < 0.4f) f / 0.4f else 1f - (f - 0.4f) / 0.6f
                breath.scale = s * s * (3 - 2 * s)
                val txt = if (f < 0.4f) "Tarik napas…" else "Hembuskan perlahan…"
                if (phase.text.toString() != txt) phase.text = txt
            }
        }
        val timer = object : CountDownTimer(600_000, 1000) {
            override fun onTick(ms: Long) { val s = (ms / 1000).toInt(); clock.text = String.format(Locale.US, "%02d:%02d", s / 60, s % 60) }
            override fun onFinish() { clock.text = "Selesai" }
        }
        anim.start(); timer.start()
        showOverlay(panel, "sos") { anim.cancel(); timer.cancel() }
    }

    // ---------- gallery ----------
    private fun thumb(file: File, sample: Int): Bitmap? = try { BitmapFactory.decodeFile(file.absolutePath, BitmapFactory.Options().apply { inSampleSize = sample }) } catch (_: Exception) { null }

    private fun bubble(size: Int, content: View, onClick: () -> Unit): View {
        content.layoutParams = FrameLayout.LayoutParams(size, size)
        content.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: android.graphics.Outline) { outline.setRoundRect(0, 0, view.width, view.height, dp(20).toFloat()) }
        }
        content.clipToOutline = true
        content.setOnClickListener { onClick() }
        return content
    }

    private fun buildGallery(): View {
        val c = card()
        c.addView(tv("Galeri motivasi 📷", 16f, ink, true))
        c.addView(tv("Foto yang mengingatkanmu pada alasan dan tujuanmu. Disimpan di dalam aplikasi, tidak muncul di galeri HP.", 12f, muted))
        val photos = SecretStore.photos(this)
        val size = (sw - dp(32) - dp(32) - dp(20)) / 3
        val cells = mutableListOf<View>()
        val add = TextView(this).apply { text = "+"; gravity = Gravity.CENTER; textSize = 34f; setTextColor(leaf); setBackgroundColor(leafSoft) }
        cells.add(bubble(size, add) { pickPhoto() })
        photos.take(11).forEach { name ->
            val iv = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP; setImageBitmap(thumb(File(SecretStore.photoDir(this@SecretActivity), name), 4)) }
            cells.add(bubble(size, iv) { showPhoto(name) })
        }
        var row: LinearLayout? = null
        cells.forEachIndexed { i, cell ->
            if (i % 3 == 0) { row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(6), 0, 0) }; c.addView(row) }
            val holder = FrameLayout(this)
            holder.addView(cell)
            row!!.addView(holder, LinearLayout.LayoutParams(size, size + dp(6)).apply { setMargins(0, 0, if (i % 3 == 2) 0 else dp(10), 0) })
            ObjectAnimator.ofFloat(cell, "translationY", 0f, -dp(4).toFloat(), 0f).apply {
                duration = 2400L + (i * 330L) % 1400L; repeatCount = ValueAnimator.INFINITE; startDelay = (i * 170L) % 900L; interpolator = LinearInterpolator(); start(); floaters.add(this)
            }
        }
        return c
    }

    private fun pickPhoto() {
        picking = true
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "image/*" }
        try { startActivityForResult(i, REQ_PHOTO) } catch (_: Exception) { picking = false; Toast.makeText(this, "Tidak ada aplikasi galeri.", Toast.LENGTH_LONG).show() }
    }

    private fun showPhoto(name: String) {
        val panel = FrameLayout(this).apply { setBackgroundColor(0xF0000000.toInt()); isClickable = true }
        val iv = ImageView(this).apply { scaleType = ImageView.ScaleType.FIT_CENTER; setImageBitmap(thumb(File(SecretStore.photoDir(this@SecretActivity), name), 1)) }
        panel.addView(iv, FrameLayout.LayoutParams(-1, -1).apply { setMargins(dp(8), dp(70), dp(8), dp(90)) })
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(dp(16), 0, dp(16), dp(24)) }
        row.addView(btn("Hapus foto", false) {
            AlertDialog.Builder(this, R.style.RillDialog).setTitle("Hapus foto ini?").setPositiveButton("Hapus") { _, _ -> SecretStore.removePhoto(this, name); dismissOverlay(); refreshRoom() }.setNegativeButton("Batal", null).show()
        }, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(0, 0, dp(6), 0) })
        row.addView(btn("Tutup", true) { dismissOverlay() }, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(6), 0, 0, 0) })
        panel.addView(row, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
        showOverlay(panel, "photo")
    }

    private fun importPhoto(uri: Uri) {
        Thread {
            try {
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
                var sample = 1
                while (max(bounds.outWidth, bounds.outHeight) / sample > 1280) sample *= 2
                var bmp = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample }) } ?: throw IllegalStateException()
                if (Build.VERSION.SDK_INT >= 24) {
                    contentResolver.openInputStream(uri)?.use { s ->
                        val deg = when (ExifInterface(s).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1)) { 6 -> 90f; 3 -> 180f; 8 -> 270f; else -> 0f }
                        if (deg != 0f) bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, Matrix().apply { postRotate(deg) }, true)
                    }
                }
                val name = "p${System.currentTimeMillis()}.jpg"
                File(SecretStore.photoDir(this), name).outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 85, it) }
                SecretStore.addPhoto(this, name)
                runOnUiThread { refreshRoom() }
            } catch (_: Exception) { runOnUiThread { Toast.makeText(this, "Gagal menambahkan foto.", Toast.LENGTH_LONG).show() } }
        }.start()
    }

    // ---------- history ----------
    private fun buildHistory(): View {
        val c = card()
        c.addView(tv("Riwayat 5 minggu terakhir", 16f, ink, true))
        val log = SecretStore.readLog(this)
        val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val cal = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -34) }
        val cell = (sw - dp(32) - dp(32) - dp(6) * 6) / 7
        for (r in 0 until 5) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(6), 0, 0) }
            for (k in 0 until 7) {
                val key = fmt.format(cal.time)
                val color = when (log[key]) { "s" -> 0xFF66BB6A.toInt(); "f" -> 0xFFEF9A9A.toInt(); else -> 0xFFE8EFE8.toInt() }
                val v = View(this).apply { background = GradientDrawable().apply { setColor(color); cornerRadius = dp(8).toFloat(); if (key == SecretStore.today()) setStroke(dp(2), leaf) } }
                row.addView(v, LinearLayout.LayoutParams(cell, cell).apply { setMargins(0, 0, if (k < 6) dp(6) else 0, 0) })
                cal.add(Calendar.DAY_OF_YEAR, 1)
            }
            c.addView(row)
        }
        c.addView(tv("Hijau = berhasil · merah muda = gagal · abu = belum dicatat", 11f, muted).apply { setPadding(dp(2), dp(8), dp(2), 0) })
        val tr = SecretStore.triggers(this, 3)
        if (tr.isNotEmpty()) {
            c.addView(tv("Catatan pemicu terakhir", 12f, muted, true).apply { setPadding(dp(2), dp(10), dp(2), dp(2)) })
            tr.forEach { c.addView(tv("${dateLabel(it.first)}: ${it.second}", 13f, ink)) }
        }
        return c
    }

    // ---------- settings (hamburger) ----------
    private fun showSettings() {
        val panel = FrameLayout(this).apply { setBackgroundColor(0xEE0E2216.toInt()); isClickable = true }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(22), dp(70), dp(22), dp(24)) }
        col.addView(tv("Pengaturan", 26f, Color.WHITE, true))
        fun item(label: String, onClick: () -> Unit) = col.addView(TextView(this).apply {
            text = label; textSize = 16f; setTextColor(Color.WHITE); background = rounded(0x22FFFFFF, 16); setPadding(dp(18), dp(16), dp(18), dp(16)); setOnClickListener { onClick() }
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(6), 0, dp(6)) }
        })
        item("🎧  Musik latar (binaural)") { showMusic() }
        item("⏰  Jam check-in: ${String.format(Locale.US, "%02d:00", SecretStore.checkinHour(this))}") {
            TimePickerDialog(this, { _, h, _ -> SecretStore.setCheckinHour(this, h); dismissOverlay(); refreshRoom() }, SecretStore.checkinHour(this), 0, true).show()
        }
        item("🔑  Ganti kode rahasia") { changeCode() }
        item("🗑️  Hapus semua data Ruang Tenang") {
            AlertDialog.Builder(this, R.style.RillDialog).setTitle("Hapus semua?").setMessage("Riwayat, foto, musik, dan alasanmu akan dihapus permanen dari HP ini.")
                .setPositiveButton("Hapus semuanya") { _, _ ->
                    MusicService.send(this, MusicService.ACTION_STOP); SecretStore.wipe(this); Toast.makeText(this, "Data Ruang Tenang dihapus.", Toast.LENGTH_LONG).show(); finish()
                }.setNegativeButton("Batal", null).show()
        }
        col.addView(btn("Tutup", false) { dismissOverlay() }.apply { setTextColor(Color.WHITE); background = rounded(0x33FFFFFF, 16) })
        panel.addView(ScrollView(this).apply { addView(col) }, FrameLayout.LayoutParams(-1, -1))
        showOverlay(panel, "settings")
    }

    private fun changeCode() {
        val e = EditText(this).apply { hint = "Kode baru (minimal 4 karakter)"; setText("") }
        AlertDialog.Builder(this, R.style.RillDialog).setTitle("Ganti kode rahasia").setMessage("Kode ini diketik di menu Catatan lalu disimpan untuk membuka Ruang Tenang.").setView(e)
            .setPositiveButton("Simpan") { _, _ ->
                val v = e.text.toString().trim()
                if (v.length < 4) Toast.makeText(this, "Kode minimal 4 karakter.", Toast.LENGTH_LONG).show()
                else { SecretStore.setCode(this, v); Toast.makeText(this, "Kode diganti.", Toast.LENGTH_LONG).show() }
            }.setNegativeButton("Batal", null).show()
    }

    // ---------- music ----------
    private fun showMusic() {
        val panel = FrameLayout(this).apply { setBackgroundColor(0xF00E2216.toInt()); isClickable = true }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(22), dp(70), dp(22), dp(24)) }
        col.addView(tv("Musik latar 🎧", 26f, Color.WHITE, true))
        col.addView(tv("Tambahkan file suara milikmu (misalnya binaural beats). Efek binaural paling terasa dengan headphone stereo.", 13f, 0xFFB7CDB9.toInt()))
        val tracks = SecretStore.tracks(this)
        if (tracks.isEmpty()) col.addView(tv("Belum ada musik. Ketuk “Tambah musik”.", 14f, 0xFF93AD97.toInt()).apply { setPadding(dp(2), dp(14), dp(2), dp(6)) })
        tracks.forEach { t ->
            val isCur = MusicService.playing && MusicService.currentFile == t.file
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; background = rounded(0x22FFFFFF, 16); setPadding(dp(16), dp(10), dp(10), dp(10)) }
            row.addView(tv(t.name, 14f, Color.WHITE, isCur), LinearLayout.LayoutParams(0, -2, 1f))
            val play = tv(if (isCur) "Jeda" else "Putar", 13f, Color.WHITE, true).apply { background = rounded(leaf, 14); setPadding(dp(14), dp(8), dp(14), dp(8)) }
            play.setOnClickListener {
                if (isCur) MusicService.send(this, MusicService.ACTION_TOGGLE) else MusicService.send(this, MusicService.ACTION_PLAY) { putExtra("file", t.file) }
                handler.postDelayed({ if (overlayKind == "music") showMusic() }, 450)
            }
            val del = tv("Hapus", 13f, 0xFFFFB4B4.toInt(), true).apply { setPadding(dp(12), dp(8), dp(12), dp(8)) }
            del.setOnClickListener {
                if (isCur) MusicService.send(this, MusicService.ACTION_STOP)
                SecretStore.removeTrack(this, t.file); showMusic()
            }
            row.addView(play); row.addView(del)
            col.addView(row, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(6), 0, dp(6)) })
        }
        col.addView(btn("+ Tambah musik", true) { pickAudio() })
        col.addView(tv("Volume", 12f, 0xFFB7CDB9.toInt(), true).apply { setPadding(dp(2), dp(14), dp(2), dp(2)) })
        val seek = SeekBar(this).apply {
            max = 100; progress = (SecretStore.volume(this@SecretActivity) * 100).toInt()
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) { if (fromUser) SecretStore.setVolume(this@SecretActivity, p / 100f) }
                override fun onStartTrackingTouch(s: SeekBar) {}
                override fun onStopTrackingTouch(s: SeekBar) { if (MusicService.playing) MusicService.send(this@SecretActivity, MusicService.ACTION_VOLUME) { putExtra("vol", s.progress / 100f) } }
            })
        }
        col.addView(seek)
        col.addView(tv("Timer tidur (berlaku saat musik diputar)", 12f, 0xFFB7CDB9.toInt(), true).apply { setPadding(dp(2), dp(14), dp(2), dp(4)) })
        val chips = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf(15 to "15 mnt", 30 to "30 mnt", 60 to "60 mnt", 90 to "90 mnt", 0 to "Mati").forEach { (min, label) ->
            val on = MusicService.sleepMinutes == min && MusicService.playing
            chips.addView(tv(label, 13f, if (on) Color.WHITE else 0xFFD6F5D0.toInt(), true).apply {
                gravity = Gravity.CENTER; background = rounded(if (on) leaf else 0x33FFFFFF, 14); setPadding(dp(8), dp(10), dp(8), dp(10))
                setOnClickListener { if (MusicService.playing) { MusicService.send(this@SecretActivity, MusicService.ACTION_SLEEP) { putExtra("min", min) }; Toast.makeText(this@SecretActivity, if (min == 0) "Timer tidur dimatikan." else "Musik berhenti dalam $min menit.", Toast.LENGTH_SHORT).show(); handler.postDelayed({ if (overlayKind == "music") showMusic() }, 400) } else Toast.makeText(this@SecretActivity, "Putar musik dulu.", Toast.LENGTH_SHORT).show() }
            }, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(3), 0, dp(3), 0) })
        }
        col.addView(chips)
        col.addView(btn("Hentikan musik", false) { MusicService.send(this, MusicService.ACTION_STOP); handler.postDelayed({ if (overlayKind == "music") showMusic() }, 400) }.apply { setTextColor(Color.WHITE); background = rounded(0x33FFFFFF, 16) })
        col.addView(btn("Kembali", false) { showSettings() })
        panel.addView(ScrollView(this).apply { addView(col) }, FrameLayout.LayoutParams(-1, -1))
        showOverlay(panel, "music")
    }

    private fun pickAudio() {
        picking = true
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "audio/*" }
        try { startActivityForResult(i, REQ_AUDIO) } catch (_: Exception) { picking = false; Toast.makeText(this, "Tidak ada aplikasi file.", Toast.LENGTH_LONG).show() }
    }

    private fun importAudio(uri: Uri) {
        Toast.makeText(this, "Menambahkan musik…", Toast.LENGTH_SHORT).show()
        Thread {
            try {
                var display = "Musik ${System.currentTimeMillis() % 10000}"
                contentResolver.query(uri, null, null, null, null)?.use { c -> if (c.moveToFirst()) { val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME); if (i >= 0) display = c.getString(i) ?: display } }
                val file = "t${System.currentTimeMillis()}"
                contentResolver.openInputStream(uri)?.use { input -> File(SecretStore.audioDir(this), file).outputStream().use { out -> input.copyTo(out) } } ?: throw IllegalStateException()
                SecretStore.addTrack(this, display.substringBeforeLast('.'), file)
                runOnUiThread { if (overlayKind == "music") showMusic() }
            } catch (_: Exception) { runOnUiThread { Toast.makeText(this, "Gagal menambahkan musik.", Toast.LENGTH_LONG).show() } }
        }.start()
    }

    @Deprecated("Result handling")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data
        if (resultCode != RESULT_OK || uri == null) return
        if (requestCode == REQ_PHOTO) importPhoto(uri) else if (requestCode == REQ_AUDIO) importAudio(uri)
    }
}
