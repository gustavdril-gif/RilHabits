package com.airil.rillrebirth

import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.View
import android.widget.LinearLayout

/** Morning ritual = pending tasks before 11:00, evening ritual = pending tasks from 18:00. One tap walks through them in order. */
private const val MORNING_END = 11 * 60
private const val EVENING_START = 18 * 60

internal fun MainActivity.ritualTasks(kind: String): List<RillTask> =
    todayTasks.filter { !done.contains(it.id) && !isLapsed(it) && (if (kind == "pagi") taskMinutes(it) < MORNING_END else taskMinutes(it) >= EVENING_START) }
        .sortedBy { taskMinutes(it) }

/** Which ritual to offer right now ("pagi", "malam" or ""). */
internal fun MainActivity.ritualOffer(): String {
    val h = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
    val kind = when { h in 4..10 -> "pagi"; h >= 17 -> "malam"; else -> "" }
    return if (kind.isNotEmpty() && ritualTasks(kind).isNotEmpty()) kind else ""
}

/** Home card with a one-tap start button. */
internal fun MainActivity.ritualCard() {
    val kind = ritualOffer()
    if (kind.isEmpty()) return
    val list = ritualTasks(kind)
    val c = card(14)
    c.background = shape(greenSoft, 20)
    c.addView(text(if (kind == "pagi") "🌅 Ritual Pagi" else "🌙 Ritual Malam", 16f, true))
    c.addView(text("${list.size} tugas berurutan · ${list.take(3).joinToString(", ") { it.name }}${if (list.size > 3) "…" else ""}", 12f, false, subtle))
    c.addView(button(if (kind == "pagi") "Mulai Ritual Pagi" else "Mulai Ritual Malam", true) { startRitual(kind) })
    content.addView(c)
}

internal fun MainActivity.startRitual(kind: String) {
    ritualKind = kind
    ritualIds = ritualTasks(kind).map { it.id }
    ritualIdx = 0; ritualDone = 0; ritualSkipped = 0
    showRitualStep()
}

private fun MainActivity.dot(state: Int): View = View(this).apply {
    // 0 = upcoming, 1 = current, 2 = done, 3 = skipped
    background = GradientDrawable().apply {
        setShape(GradientDrawable.OVAL)
        setColor(when (state) { 2 -> green; 1 -> Color.parseColor("#9AD0B2"); 3 -> Color.parseColor("#D8D8DE"); else -> Color.parseColor("#E5E5EA") })
    }
    layoutParams = LinearLayout.LayoutParams(dp(if (state == 1) 12 else 9), dp(if (state == 1) 12 else 9)).apply { setMargins(dp(4), 0, dp(4), 0) }
}

internal fun MainActivity.showRitualStep() {
    screen = "ritual"; onTimerScreen = false; animating = true
    applyBackdrop(false)
    content.removeAllViews(); scrollView?.scrollTo(0, 0)
    // skip tasks that disappeared or were finished meanwhile
    while (ritualIdx < ritualIds.size) {
        val t = tasks.find { it.id == ritualIds[ritualIdx] }
        if (t == null || done.contains(t.id)) ritualIdx++ else break
    }
    if (ritualIdx >= ritualIds.size) { showRitualEnd(); return }
    val task = tasks.first { it.id == ritualIds[ritualIdx] }
    val title = if (ritualKind == "pagi") "Ritual Pagi 🌅" else "Ritual Malam 🌙"
    content.addView(backLink("‹ Keluar") { render(true) })
    content.addView(text(title, 28f, true))
    val dots = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(0, dp(12), 0, dp(4)) }
    ritualIds.forEachIndexed { i, id ->
        val st = when { i == ritualIdx -> 1; done.contains(id) -> 2; i < ritualIdx -> 3; else -> 0 }
        dots.addView(dot(st))
    }
    content.addView(dots)
    content.addView(hint("Langkah ${ritualIdx + 1} dari ${ritualIds.size}").apply { gravity = Gravity.CENTER })
    val c = card(22)
    c.addView(text("${timeOf(task)} · ${task.category}", 13f, true, green))
    c.addView(text(task.name, 26f, true).apply { setPadding(dp(2), dp(8), dp(2), dp(8)) })
    c.addView(text("+${task.xp} EXP", 13f, false, subtle))
    content.addView(c)
    content.addView(button("Selesai ✓", true) {
        onTaskToggled(task, true)
        ritualDone++; ritualIdx++
        root.performHapticFeedback(if (android.os.Build.VERSION.SDK_INT >= 30) HapticFeedbackConstants.CONFIRM else HapticFeedbackConstants.VIRTUAL_KEY)
        showRitualStep()
    })
    content.addView(button("Lewati dulu") { ritualSkipped++; ritualIdx++; showRitualStep() })
    if (animating) animateChildren()
}

private fun MainActivity.showRitualEnd() {
    screen = "ritual"
    content.removeAllViews(); scrollView?.scrollTo(0, 0)
    content.addView(text(if (ritualDone > 0) "Ritual selesai 🎉" else "Ritual ditutup", 28f, true))
    val c = card(20)
    c.addView(text("$ritualDone tugas selesai", 18f, true, green))
    if (ritualSkipped > 0) c.addView(text("$ritualSkipped dilewati — tetap ada di Checklist kalau mau dikerjakan nanti.", 13f, false, subtle))
    if (allDoneToday()) c.addView(text("Semua kegiatan hari ini sudah beres. Luar biasa!", 13f, false, subtle))
    content.addView(c)
    content.addView(button("Kembali ke Beranda", true) { selectedTab = "Home"; render(true) })
    if (animating) animateChildren()
}
