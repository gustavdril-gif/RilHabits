package com.airil.rillrebirth

import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Toast
import java.util.Locale

data class ExerciseInfo(val muscle: String, val steps: List<String>, val tip: String)

/** Short how-to guides so every exercise in the app can be explained in plain Indonesian. */
object Guide {
    private fun i(muscle: String, tip: String, vararg steps: String) = ExerciseInfo(muscle, steps.toList(), tip)

    private val data: Map<String, ExerciseInfo> = mapOf(
        "push up" to i("Dada, bahu, trisep", "Terlalu berat? Turunkan lutut ke lantai, tubuh tetap lurus dari kepala ke lutut.",
            "Tumpu kedua tangan selebar bahu, tubuh lurus dari kepala sampai tumit.",
            "Turunkan dada sampai hampir menyentuh lantai, siku sekitar 45° dari badan.",
            "Dorong badan naik sampai lengan lurus. Kencangkan perut agar pinggang tidak turun."),
        "pike push up" to i("Bahu, trisep", "Makin dekat kaki ke tangan, makin berat gerakannya.",
            "Mulai dari posisi push up, lalu angkat pinggul tinggi sampai badan membentuk huruf V terbalik.",
            "Tekuk siku dan turunkan kepala ke lantai, di antara kedua tangan.",
            "Dorong kembali ke atas sampai lengan lurus."),
        "squat jump" to i("Paha, bokong, kardio", "Mendarat pelan dan tanpa suara supaya lutut aman.",
            "Berdiri selebar bahu lalu turun ke posisi squat.",
            "Dorong kuat lewat tumit dan melompat setinggi yang kamu bisa.",
            "Mendarat dengan lutut menekuk, langsung turun ke squat berikutnya."),
        "squat" to i("Paha depan, bokong", "Lutut searah ujung kaki, jangan menekuk ke dalam. Tumit tetap menempel lantai.",
            "Berdiri selebar bahu, ujung kaki sedikit mengarah keluar.",
            "Dorong pinggul ke belakang seperti mau duduk di kursi, dada tetap tegak.",
            "Turun sampai paha hampir sejajar lantai, lalu dorong naik lewat tumit."),
        "lunges" to i("Paha, bokong", "Badan tetap tegak. Kalau goyah, pegang dinding atau sandaran kursi.",
            "Berdiri tegak, lalu melangkah satu kaki ke depan.",
            "Turunkan badan sampai kedua lutut menekuk sekitar 90°, lutut belakang hampir menyentuh lantai.",
            "Dorong lewat tumit kaki depan untuk kembali berdiri, lalu ganti kaki."),
        "plank" to i("Perut, punggung bawah, bahu", "Jangan biarkan pinggang turun atau pantat terlalu naik. Napas tetap normal.",
            "Tumpu kedua siku tepat di bawah bahu, kaki lurus ke belakang bertumpu pada ujung kaki.",
            "Luruskan badan dari kepala sampai tumit, kencangkan perut dan bokong.",
            "Tahan sesuai waktu yang ditentukan."),
        "pull up" to i("Punggung, bisep", "Belum kuat? Mulai dari posisi atas lalu turun pelan 3–5 detik. Latihan ini membangun kekuatan tarik.",
            "Pegang palang selebar bahu atau sedikit lebih lebar, telapak menghadap ke depan.",
            "Tarik badan naik dengan menarik siku ke bawah sampai dagu melewati palang.",
            "Turun pelan sampai lengan lurus kembali."),
        "dumbbell row" to i("Punggung, bisep", "Jangan memutar badan; tarik dengan siku, bukan dengan tangan.",
            "Satu lutut dan satu tangan bertumpu di bangku atau kursi kokoh, punggung lurus sejajar lantai.",
            "Tangan satunya memegang dumbbell, tarik ke arah pinggul sambil menarik siku ke belakang.",
            "Turunkan pelan. Selesaikan semua repetisi, lalu ganti sisi."),
        "dumbbell biceps curl" to i("Bisep", "Jangan mengayun badan. Kalau perlu mengayun, bebannya terlalu berat.",
            "Berdiri tegak, dumbbell di tiap tangan, telapak menghadap ke depan.",
            "Tekuk siku dan angkat dumbbell ke arah bahu, siku tetap menempel di samping badan.",
            "Turunkan pelan sampai lengan lurus."),
        "hammer curl" to i("Bisep dan lengan bawah", "Pegang dumbbell seperti memegang palu, telapak saling berhadapan sepanjang gerakan.",
            "Berdiri tegak, dumbbell di tiap tangan, telapak saling berhadapan.",
            "Tekuk siku dan angkat dumbbell ke arah bahu tanpa memutar pergelangan.",
            "Turunkan pelan sampai lengan lurus."),
        "reverse fly" to i("Bahu belakang, punggung atas", "Pakai beban ringan dan fokus menjepit tulang belikat.",
            "Membungkuk dari pinggang dengan punggung lurus, dumbbell menggantung di bawah dada, siku sedikit tertekuk.",
            "Angkat kedua lengan ke samping sampai sejajar bahu sambil menjepit tulang belikat.",
            "Turunkan pelan ke posisi awal."),
        "dumbbell shoulder press" to i("Bahu, trisep", "Kencangkan perut dan jaga punggung tidak melengkung berlebihan.",
            "Berdiri atau duduk tegak, dumbbell setinggi bahu, telapak menghadap ke depan.",
            "Dorong ke atas sampai lengan hampir lurus.",
            "Turunkan pelan kembali ke tinggi bahu."),
        "triceps dips" to i("Trisep, dada bawah", "Pastikan kursi kokoh dan tidak bergeser. Siku mengarah ke belakang, bukan ke samping.",
            "Duduk di tepi kursi, kedua tangan memegang tepi kursi di samping pinggul, lalu geser pinggul ke depan.",
            "Tekuk siku ke belakang dan turunkan badan sampai siku sekitar 90°.",
            "Dorong naik sampai lengan lurus."),
        "dumbbell triceps extension" to i("Trisep", "Jaga siku tetap menghadap ke depan dan tidak melebar.",
            "Pegang satu dumbbell dengan kedua tangan, angkat lurus di atas kepala.",
            "Tekuk siku dan turunkan dumbbell ke belakang kepala.",
            "Luruskan lengan kembali ke atas."),
        "glute bridge" to i("Bokong, paha belakang", "Jepit bokong di atas, jangan melengkungkan punggung bawah.",
            "Telentang, lutut ditekuk, telapak kaki rata di lantai selebar pinggul.",
            "Dorong pinggul ke atas lewat tumit sampai badan lurus dari bahu ke lutut.",
            "Tahan 1 detik, lalu turun pelan."),
        "calf raise" to i("Betis", "Boleh berpegangan dinding untuk keseimbangan. Berdiri di ujung anak tangga untuk jangkauan lebih besar.",
            "Berdiri tegak, kaki selebar pinggul.",
            "Naik berjinjit setinggi mungkin.",
            "Tahan sebentar, lalu turun pelan."),
        "romanian deadlift" to i("Paha belakang, bokong, punggung bawah", "Jangan membungkukkan punggung. Berhenti turun saat paha belakang terasa tertarik.",
            "Berdiri dengan dumbbell di depan paha, lutut sedikit menekuk.",
            "Dorong pinggul ke belakang sambil menurunkan dumbbell menyusuri kaki, punggung tetap lurus.",
            "Dorong pinggul ke depan untuk berdiri tegak kembali."),
        "sit up" to i("Perut", "Jangan menarik leher dengan tangan. Naik dengan tenaga perut.",
            "Telentang, lutut ditekuk, telapak kaki di lantai, tangan menyilang di dada.",
            "Angkat badan bagian atas sampai duduk sambil mengencangkan perut.",
            "Turun pelan ke lantai."),
        "leg raise" to i("Perut bawah", "Punggung bawah tetap menempel lantai. Tekuk lutut sedikit kalau terlalu berat.",
            "Telentang, tangan di samping badan, kaki lurus.",
            "Angkat kedua kaki sampai tegak lurus ke atas.",
            "Turunkan pelan sampai hampir menyentuh lantai, lalu ulangi."),
        "mountain climber" to i("Perut, bahu, kardio", "Pinggul tetap rendah dan sejajar punggung.",
            "Mulai dari posisi plank dengan tangan lurus.",
            "Tarik satu lutut ke arah dada, lalu cepat ganti ke kaki satunya seperti berlari di tempat.",
            "Pertahankan tempo sesuai waktu yang ditentukan."),
        "jumping jack" to i("Seluruh badan, kardio", "Pertahankan ritme stabil dan mendarat dengan lembut.",
            "Berdiri tegak, tangan di samping badan.",
            "Lompat sambil membuka kaki selebar bahu dan mengangkat kedua tangan ke atas kepala.",
            "Lompat kembali ke posisi awal."),
        "burpee" to i("Seluruh badan, kardio", "Pemula boleh tanpa lompat dan tanpa push up, pelan tapi rapi.",
            "Berdiri, lalu jongkok dan letakkan kedua tangan di lantai.",
            "Lempar kedua kaki ke belakang sampai posisi plank.",
            "Tarik kaki kembali ke dada, lalu lompat ke atas dengan tangan di atas kepala."),
        "high knees" to i("Paha, betis, kardio", "Tetap ringan di ujung kaki dan jaga dada tegak.",
            "Berdiri tegak.",
            "Lari di tempat sambil mengangkat lutut setinggi pinggul, lengan ikut mengayun.",
            "Pertahankan tempo cepat sesuai waktu."),
        "bird dog" to i("Punggung bawah, perut, bokong", "Pinggul tetap rata, jangan goyang ke samping.",
            "Posisi merangkak, tangan di bawah bahu, lutut di bawah pinggul.",
            "Luruskan tangan kanan ke depan dan kaki kiri ke belakang bersamaan.",
            "Tahan 1–2 detik, kembali, lalu ganti sisi."),
        "cat-cow" to i("Tulang belakang", "Gerakan mengalir mengikuti napas, tidak perlu dipaksa.",
            "Posisi merangkak, tangan di bawah bahu.",
            "Tarik napas: turunkan perut, angkat kepala dan tulang ekor (cow).",
            "Hembuskan napas: bulatkan punggung ke atas dan dagu ke dada (cat). Ulangi."),
        "hip opener" to i("Pinggul, paha depan", "Jangan memaksa sampai nyeri. Tarikan ringan sudah cukup.",
            "Dari berdiri, melangkah jauh ke depan dengan satu kaki, lutut belakang turun ke lantai.",
            "Dorong pinggul pelan ke depan dan ke bawah sampai terasa tarikan di pangkal paha kaki belakang.",
            "Tahan sesuai waktu, lalu ganti sisi."),
        "child pose" to i("Punggung, pinggul", "Napas dalam dan rileks. Bantal di bawah dahi boleh dipakai.",
            "Berlutut dan duduk di atas tumit.",
            "Condongkan badan ke depan, kedua tangan menjulur ke depan, dahi menyentuh lantai.",
            "Tahan sambil bernapas dalam."),
        "peregangan hamstring" to i("Paha belakang", "Jangan memantul. Tarik pelan sampai terasa tegang, bukan sakit.",
            "Duduk, satu kaki lurus ke depan, kaki lain ditekuk ke dalam.",
            "Condongkan badan dari pinggul ke arah ujung kaki, punggung tetap lurus.",
            "Tahan sesuai waktu, lalu ganti sisi."),
        "peregangan bahu" to i("Bahu", "Bahu tetap rileks, jangan terangkat ke telinga.",
            "Silangkan satu lengan di depan dada.",
            "Tarik lengan itu mendekat ke dada dengan tangan satunya.",
            "Tahan sesuai waktu, lalu ganti sisi."),
        "peregangan betis" to i("Betis, paha depan", "Untuk paha depan: berdiri, tekuk satu lutut dan tarik tumit ke arah bokong.",
            "Berdiri menghadap dinding, satu kaki di belakang dengan lutut lurus dan tumit menempel lantai.",
            "Condongkan badan ke depan sampai betis terasa tertarik.",
            "Tahan sesuai waktu, lalu ganti sisi."),
        "peregangan" to i("Otot yang baru dipakai", "Tahan 20–30 detik tanpa memantul dan bernapas pelan.",
            "Pilih otot yang tadi dipakai paling banyak.",
            "Regangkan pelan sampai terasa tegang, bukan sakit.",
            "Tahan sambil bernapas pelan, lalu ganti sisi."),
        "pemanasan" to i("Seluruh badan", "Pemanasan menurunkan risiko cedera, jangan dilewatkan.",
            "Jalan cepat atau jalan di tempat sambil mengayun lengan.",
            "Putar bahu, pinggul, dan pergelangan kaki masing-masing beberapa kali.",
            "Naikkan tempo pelan-pelan sampai badan terasa hangat."),
        "pendinginan" to i("Seluruh badan", "Setelah itu lanjutkan dengan peregangan ringan.",
            "Turunkan tempo menjadi jalan santai.",
            "Atur napas sampai terasa normal dan detak jantung menurun."),
        "jogging" to i("Kaki, kardio", "Pelan lebih baik daripada berhenti total. Interval jalan-lari sangat boleh untuk pemula.",
            "Lari dengan tempo yang masih memungkinkan kamu mengobrol.",
            "Mendarat di tengah telapak kaki, badan sedikit condong ke depan, bahu rileks.",
            "Atur napas teratur, misalnya tarik 3 langkah dan buang 2 langkah."),
        "lari cepat" to i("Kaki, kardio", "Pakai usaha sekitar 7–8 dari 10, lalu pulih penuh di fase santai.",
            "Lari dengan tempo cepat tapi masih terkendali sesuai waktu yang tertulis.",
            "Setelah itu turunkan ke jalan santai atau jogging pelan untuk pulih.",
            "Ulangi sesuai jumlah putaran."),
        "jalan cepat" to i("Kaki, kardio ringan", "Cek tempo: napas lebih cepat tapi kamu masih bisa bicara.",
            "Jalan dengan langkah sedikit lebih panjang dari biasa.",
            "Ayunkan lengan dan jaga badan tegak.",
            "Pertahankan tempo stabil sesuai waktu."),
        "jalan santai" to i("Kaki", "Santai saja, yang penting konsisten.",
            "Jalan dengan tempo nyaman.",
            "Bahu rileks dan napas normal.")
    )

    private val keys: List<String> = data.keys.sortedByDescending { it.length }

    private fun normalize(name: String): String =
        name.lowercase(Locale.ROOT).replace(Regex("\\(.*?\\)"), "").replace(Regex("\\s+"), " ").trim()

    fun find(name: String): ExerciseInfo? {
        val n = normalize(name)
        if (n.isEmpty()) return null
        data[n]?.let { return it }
        val k = keys.firstOrNull { n.contains(it) } ?: return null
        return data[k]
    }
}

/** Shows how-to steps for an exercise; falls back to a video search when there is no built-in guide. */
internal fun MainActivity.showGuide(name: String) {
    val info = Guide.find(name)
    val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(4), dp(20), dp(4)) }
    if (info != null) {
        box.addView(text("Otot yang bekerja", 12f, true, subtle))
        box.addView(text(info.muscle, 14f, false, ink))
        box.addView(text("Langkah", 12f, true, subtle).apply { setPadding(dp(2), dp(12), dp(2), dp(3)) })
        info.steps.forEachIndexed { idx, step -> box.addView(text("${idx + 1}. $step", 14f, false, ink)) }
        box.addView(text("Tips", 12f, true, subtle).apply { setPadding(dp(2), dp(12), dp(2), dp(3)) })
        box.addView(text(info.tip, 14f, false, ink))
    } else {
        box.addView(text("Belum ada panduan tertulis untuk gerakan ini. Kamu bisa mencari video contoh supaya gerakannya benar.", 14f, false, ink))
    }
    AlertDialog.Builder(this, R.style.RillDialog).setTitle(name).setView(ScrollView(this).apply { addView(box) })
        .setPositiveButton("Mengerti", null)
        .setNeutralButton("Cari video contoh") { _, _ ->
            try {
                val q = Uri.encode("cara $name")
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=$q")))
            } catch (_: Exception) {
                Toast.makeText(this, "Tidak ada aplikasi untuk membuka video.", Toast.LENGTH_SHORT).show()
            }
        }.show()
}
