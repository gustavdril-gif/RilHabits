package com.airil.rillrebirth

import android.app.AlertDialog
import android.content.Context
import android.graphics.Color
import android.text.InputType
import android.view.Gravity
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

/** kind: "keyword" (count finished tasks whose name/category contains keyword), "workout", or "perfect" (days at 100%). period: "week" | "month". */
data class Goal(val id: Long, var title: String, var kind: String, var keyword: String, var target: Int, var period: String)
data class Badge(val goalId: Long, val title: String, val periodStart: String, val period: String, val ts: Long)

object GoalStore {
    private const val GOALS = "goals_json"
    private const val BADGES = "badges_json"
    private val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)

    private fun prefs(c: Context) = c.getSharedPreferences("rill_data", Context.MODE_PRIVATE)

    fun load(c: Context): MutableList<Goal> {
        val arr = try { JSONArray(prefs(c).getString(GOALS, "[]") ?: "[]") } catch (_: Exception) { JSONArray() }
        val out = mutableListOf<Goal>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            out.add(Goal(o.optLong("id"), o.optString("title"), o.optString("kind", "keyword"), o.optString("keyword"), o.optInt("target", 1).coerceAtLeast(1), o.optString("period", "month")))
        }
        return out
    }

    fun save(c: Context, list: List<Goal>) {
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("id", it.id).put("title", it.title).put("kind", it.kind).put("keyword", it.keyword).put("target", it.target).put("period", it.period)) }
        prefs(c).edit().putString(GOALS, arr.toString()).apply()
    }

    fun loadBadges(c: Context): MutableList<Badge> {
        val arr = try { JSONArray(prefs(c).getString(BADGES, "[]") ?: "[]") } catch (_: Exception) { JSONArray() }
        val out = mutableListOf<Badge>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            out.add(Badge(o.optLong("goalId"), o.optString("title"), o.optString("start"), o.optString("period", "month"), o.optLong("ts")))
        }
        return out
    }

    private fun saveBadges(c: Context, list: List<Badge>) {
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("goalId", it.goalId).put("title", it.title).put("start", it.periodStart).put("period", it.period).put("ts", it.ts)) }
        prefs(c).edit().putString(BADGES, arr.toString()).apply()
    }

    /** First day of the current week (Monday) or month. */
    fun periodStart(period: String): Calendar {
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0); cal.set(Calendar.SECOND, 0); cal.set(Calendar.MILLISECOND, 0)
        if (period == "week") {
            val back = (cal.get(Calendar.DAY_OF_WEEK) + 5) % 7   // Monday -> 0
            cal.add(Calendar.DAY_OF_YEAR, -back)
        } else cal.set(Calendar.DAY_OF_MONTH, 1)
        return cal
    }

    fun periodKey(period: String): String = fmt.format(periodStart(period).time)

    fun periodLabel(period: String): String = if (period == "week") "minggu ini" else "bulan ini"

    fun progress(c: Context, g: Goal, tasks: List<RillTask>, stats: List<DayStat>): Int {
        val start = periodStart(g.period)
        val startKey = fmt.format(start.time)
        val todayKey = fmt.format(Calendar.getInstance().time)
        val dates = ArrayList<String>()
        val cal = start.clone() as Calendar
        while (fmt.format(cal.time) <= todayKey && dates.size < 40) { dates.add(fmt.format(cal.time)); cal.add(Calendar.DAY_OF_YEAR, 1) }
        return when (g.kind) {
            "workout" -> {
                val root = WorkoutStore.workoutDoneRoot(c)
                var n = 0
                dates.forEach { d ->
                    val o = root.optJSONObject(d) ?: return@forEach
                    val keys = o.keys()
                    while (keys.hasNext()) if (o.optBoolean(keys.next(), false)) n++
                }
                n
            }
            "runkm" -> {
                val startMs = start.timeInMillis
                (RunStore.load(c).filter { it.start >= startMs }.sumOf { it.distM } / 1000.0).toInt()
            }
            "perfect" -> stats.count { it.date >= startKey && it.date <= todayKey && it.total > 0 && it.rate >= 0.999f }
            else -> {
                val kw = g.keyword.trim().lowercase(Locale.ROOT)
                if (kw.isEmpty()) 0 else {
                    val root = TaskStore.allDone(c)
                    val byId = tasks.associateBy { it.id }
                    var n = 0
                    dates.forEach { d ->
                        val arr = root.optJSONArray(d) ?: return@forEach
                        for (i in 0 until arr.length()) {
                            val t = byId[arr.optInt(i)] ?: continue
                            if (t.name.lowercase(Locale.ROOT).contains(kw) || t.category.lowercase(Locale.ROOT).contains(kw)) n++
                        }
                    }
                    n
                }
            }
        }
    }

    /** Awards a badge once per goal per period when the target is reached. Returns the new badges. */
    fun checkAwards(c: Context, tasks: List<RillTask>, stats: List<DayStat>): List<Badge> {
        val goals = load(c)
        if (goals.isEmpty()) return emptyList()
        val badges = loadBadges(c)
        val fresh = mutableListOf<Badge>()
        goals.forEach { g ->
            val key = periodKey(g.period)
            if (badges.any { it.goalId == g.id && it.periodStart == key }) return@forEach
            if (progress(c, g, tasks, stats) >= g.target) {
                val b = Badge(g.id, g.title, key, g.period, System.currentTimeMillis())
                badges.add(b); fresh.add(b)
            }
        }
        if (fresh.isNotEmpty()) saveBadges(c, badges)
        return fresh
    }
}

private fun kindLabel(kind: String) = when (kind) { "workout" -> "sesi workout selesai"; "perfect" -> "hari sempurna"; "runkm" -> "km lari"; else -> "kali selesai" }

/** Small single-select row of options (selected = green). */
internal fun MainActivity.choiceRow(options: List<Pair<String, String>>, initial: String, onChange: (String) -> Unit): LinearLayout {
    val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(4), 0, dp(4)) }
    val views = mutableListOf<Pair<String, TextView>>()
    var current = initial
    fun paint() {
        views.forEach { (k, v) ->
            val on = k == current
            v.setTextColor(if (on) Color.WHITE else ink)
            v.background = shape(if (on) green else Color.parseColor("#EFEFF4"), 14)
        }
    }
    options.forEach { (key, label) ->
        val v = TextView(this).apply { text = label; gravity = Gravity.CENTER; textSize = 11.5f; maxLines = 1; setPadding(dp(2), dp(10), dp(2), dp(10)) }
        v.setOnClickListener { current = key; paint(); onChange(key) }
        views.add(Pair(key, v))
        row.addView(v, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(2), 0, dp(2), 0) })
    }
    paint()
    return row
}

private fun MainActivity.goalRow(g: Goal, onClick: () -> Unit): LinearLayout {
    val p = GoalStore.progress(this, g, tasks, stats)
    val pct = (p * 100 / g.target).coerceAtMost(100)
    val r = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(4), dp(10), dp(4), dp(10)) }
    val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
    head.addView(text(g.title, 15f, true), LinearLayout.LayoutParams(0, -2, 1f))
    head.addView(text(if (p >= g.target) "✅ Tercapai" else "$p/${g.target}", 13f, true, if (p >= g.target) green else subtle))
    r.addView(head)
    r.addView(hbar(pct, if (p >= g.target) green else amber))
    r.addView(text("${GoalStore.periodLabel(g.period)} · ${kindLabel(g.kind)}", 11f, false, subtle))
    r.setOnClickListener { onClick() }
    return r
}

/** Home card: the two goals closest to completion. */
internal fun MainActivity.goalsCard() {
    val goals = GoalStore.load(this)
    val c = card(12)
    val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
    head.addView(text("🎯 Target", 16f, true), LinearLayout.LayoutParams(0, -2, 1f))
    head.addView(text(if (goals.isEmpty()) "+ Buat" else "Kelola", 13f, true, green).apply {
        setPadding(dp(12), dp(6), dp(12), dp(6)); background = shape(greenSoft, 14)
        setOnClickListener { if (goals.isEmpty()) editGoal(null) else showGoals() }
    })
    c.addView(head)
    if (goals.isEmpty()) {
        c.addView(hint("Pasang target jangka panjang, mis. “jogging 20 kali bulan ini”, dan dapatkan lencana saat tercapai."))
    } else {
        val ranked = goals.sortedByDescending { val p = GoalStore.progress(this, it, tasks, stats); if (p >= it.target) -1.0 else p.toDouble() / it.target }
        ranked.take(2).forEach { c.addView(goalRow(it) { showGoals() }) }
    }
    content.addView(c)
}

internal fun MainActivity.showGoals() {
    screen = "goals"; onTimerScreen = false; animating = true
    applyBackdrop(false)
    content.removeAllViews(); scrollView?.scrollTo(0, 0)
    content.addView(backLink("‹ Beranda") { render(true) })
    content.addView(text("Target", 28f, true))
    content.addView(hint("Progres dihitung otomatis dari kegiatan dan workout yang kamu selesaikan. Target mingguan dan bulanan mulai dari nol di periode baru."))
    val goals = GoalStore.load(this)
    if (goals.isEmpty()) content.addView(hint("Belum ada target."))
    else {
        val card = listCard()
        goals.forEachIndexed { i, g ->
            card.addView(goalRow(g) { editGoal(g) })
            if (i < goals.size - 1) card.addView(android.view.View(this).apply { setBackgroundColor(line); layoutParams = LinearLayout.LayoutParams(-1, dp(1)) })
        }
        content.addView(card)
    }
    content.addView(button("+ Buat target", true) { editGoal(null) })
    val badges = GoalStore.loadBadges(this).sortedByDescending { it.ts }
    content.addView(text("Lencana 🏅 (${badges.size})", 18f, true).apply { setPadding(dp(4), dp(14), dp(4), dp(4)) })
    if (badges.isEmpty()) content.addView(hint("Capai targetmu untuk mendapat lencana pertama."))
    else {
        val bc = listCard()
        val df = SimpleDateFormat("d MMM yyyy", Locale("id", "ID"))
        badges.forEach { b -> bc.addView(text("🏅 ${b.title}", 14f, true).apply { setPadding(dp(8), dp(8), dp(8), 0) }); bc.addView(text("${if (b.period == "week") "Mingguan" else "Bulanan"} · ${df.format(java.util.Date(b.ts))}", 11f, false, subtle).apply { setPadding(dp(8), 0, dp(8), dp(8)) }) }
        content.addView(bc)
    }
}

internal fun MainActivity.editGoal(existing: Goal?) {
    val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(4), dp(20), dp(4)) }
    var kind = existing?.kind ?: "keyword"
    var period = existing?.period ?: "month"
    val title = EditText(this).apply { hint = "Nama target (mis. Jogging 20×)"; setText(existing?.title ?: "") }
    val keyword = EditText(this).apply { hint = "Kata kunci kegiatan atau kategori (mis. jogging)"; setText(existing?.keyword ?: "") }
    val target = EditText(this).apply { hint = "Jumlah target"; inputType = InputType.TYPE_CLASS_NUMBER; setText((existing?.target ?: 20).toString()) }
    val kindRow = choiceRow(listOf("keyword" to "Kegiatan", "workout" to "Workout", "perfect" to "Hari sempurna", "runkm" to "Jarak lari"), kind) { kind = it; keyword.visibility = if (it == "keyword") android.view.View.VISIBLE else android.view.View.GONE }
    keyword.visibility = if (kind == "keyword") android.view.View.VISIBLE else android.view.View.GONE
    val periodRow = choiceRow(listOf("week" to "Minggu ini", "month" to "Bulan ini"), period) { period = it }
    box.addView(title)
    box.addView(text("Yang dihitung", 13f, true, subtle).apply { setPadding(dp(2), dp(10), dp(2), dp(2)) })
    box.addView(kindRow); box.addView(keyword); box.addView(target)
    box.addView(text("Periode", 13f, true, subtle).apply { setPadding(dp(2), dp(10), dp(2), dp(2)) })
    box.addView(periodRow)
    AlertDialog.Builder(this, R.style.RillDialog).setTitle(if (existing == null) "Target baru" else "Edit target")
        .setView(android.widget.ScrollView(this).apply { addView(box) })
        .setPositiveButton("Simpan") { _, _ ->
            val tg = target.text.toString().toIntOrNull() ?: 0
            val kw = keyword.text.toString().trim()
            if (tg <= 0 || (kind == "keyword" && kw.isEmpty())) { Toast.makeText(this, "Isi jumlah target${if (kind == "keyword") " dan kata kuncinya" else ""}.", Toast.LENGTH_LONG).show(); return@setPositiveButton }
            val name = title.text.toString().trim().ifBlank { when (kind) { "workout" -> "Workout $tg×"; "perfect" -> "$tg hari sempurna"; "runkm" -> "Lari $tg km"; else -> "${kw.replaceFirstChar { it.uppercase() }} $tg×" } }
            val list = GoalStore.load(this)
            if (existing == null) list.add(Goal(System.currentTimeMillis(), name, kind, kw, tg.coerceAtMost(999), period))
            else list.find { it.id == existing.id }?.let { it.title = name; it.kind = kind; it.keyword = kw; it.target = tg.coerceAtMost(999); it.period = period }
            GoalStore.save(this, list)
            if (screen == "goals") showGoals() else render(false)
        }
        .setNeutralButton(if (existing != null) "Hapus" else "Batal") { _, _ ->
            if (existing != null) {
                GoalStore.save(this, GoalStore.load(this).filter { it.id != existing.id })
                if (screen == "goals") showGoals() else render(false)
            }
        }.setNegativeButton("Tutup", null).show()
}

/** Called after rendering Home: shows a dialog for newly earned badges. */
internal fun MainActivity.checkGoalBadges() {
    val fresh = GoalStore.checkAwards(this, tasks, stats)
    if (fresh.isEmpty()) return
    val msg = fresh.joinToString("\n") { "🏅 ${it.title}" }
    AlertDialog.Builder(this, R.style.RillDialog).setTitle("Target tercapai! 🎉").setMessage(msg + "\n\nLencana tersimpan di menu Target.")
        .setPositiveButton("Mantap") { _, _ -> }.setNeutralButton("Lihat") { _, _ -> showGoals() }.show()
}
