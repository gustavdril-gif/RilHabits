package com.airil.rillrebirth

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import java.io.File

/**
 * Plays the user's own background tracks (e.g. binaural beats) as a foreground service so it keeps going
 * when the screen is off. The notification text is neutral on purpose.
 */
class MusicService : Service() {
    companion object {
        const val ACTION_PLAY = "rill.music.play"
        const val ACTION_TOGGLE = "rill.music.toggle"
        const val ACTION_NEXT = "rill.music.next"
        const val ACTION_STOP = "rill.music.stop"
        const val ACTION_VOLUME = "rill.music.volume"
        const val ACTION_SLEEP = "rill.music.sleep"
        private const val CHANNEL = "rill_music"
        private const val NOTIF_ID = 4401

        @Volatile var playing = false
        @Volatile var currentFile = ""
        @Volatile var sleepMinutes = 0

        fun send(c: Context, action: String, extras: Intent.() -> Unit = {}) {
            val i = Intent(c, MusicService::class.java).setAction(action).apply(extras)
            try {
                if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i) else c.startService(i)
            } catch (_: Exception) { }
        }
    }

    private var mp: MediaPlayer? = null
    private val handler = Handler(Looper.getMainLooper())
    private var sleepRunnable: Runnable? = null

    override fun onBind(intent: Intent?): IBinder? = null

    private fun notification(): Notification {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "Musik fokus", NotificationManager.IMPORTANCE_LOW))
        }
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), flags)
        val stop = PendingIntent.getService(this, 1, Intent(this, MusicService::class.java).setAction(ACTION_STOP), flags)
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL) else Notification.Builder(this)
        return b.setContentTitle("Musik fokus").setContentText("Sedang memutar").setSmallIcon(R.drawable.ic_checklist)
            .setContentIntent(open).setOngoing(true).addAction(0, "Berhenti", stop).build()
    }

    private fun goForeground() {
        val n = notification()
        try {
            if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK) else startForeground(NOTIF_ID, n)
        } catch (_: Exception) { }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        goForeground()
        when (intent?.action) {
            ACTION_PLAY -> play(intent.getStringExtra("file") ?: "")
            ACTION_TOGGLE -> toggle()
            ACTION_NEXT -> playNext()
            ACTION_VOLUME -> { val v = intent.getFloatExtra("vol", 0.6f); mp?.setVolume(v, v) }
            ACTION_SLEEP -> scheduleSleep(intent.getIntExtra("min", 0))
            else -> shutDown()
        }
        if (mp == null && intent?.action != ACTION_PLAY) shutDown()
        return START_NOT_STICKY
    }

    private fun play(file: String) {
        val tracks = SecretStore.tracks(this)
        val track = tracks.find { it.file == file } ?: tracks.firstOrNull() ?: return shutDown()
        releasePlayer()
        try {
            val player = MediaPlayer()
            player.setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
            player.setDataSource(File(SecretStore.audioDir(this), track.file).absolutePath)
            player.setWakeMode(applicationContext, PowerManager.PARTIAL_WAKE_LOCK)
            val v = SecretStore.volume(this)
            player.setVolume(v, v)
            player.isLooping = tracks.size == 1
            player.setOnCompletionListener { playNext() }
            player.setOnErrorListener { _, _, _ -> shutDown(); true }
            player.prepare()
            player.start()
            mp = player
            playing = true; currentFile = track.file
        } catch (_: Exception) { shutDown() }
    }

    private fun toggle() {
        val player = mp ?: return
        if (player.isPlaying) { player.pause(); playing = false } else { player.start(); playing = true }
    }

    private fun playNext() {
        val tracks = SecretStore.tracks(this)
        if (tracks.isEmpty()) return shutDown()
        val i = tracks.indexOfFirst { it.file == currentFile }
        play(tracks[(i + 1) % tracks.size].file)
    }

    private fun scheduleSleep(min: Int) {
        sleepRunnable?.let { handler.removeCallbacks(it) }
        sleepMinutes = min
        if (min > 0) {
            val r = Runnable { shutDown() }
            sleepRunnable = r
            handler.postDelayed(r, min * 60_000L)
        }
    }

    private fun releasePlayer() {
        try { mp?.stop() } catch (_: Exception) { }
        try { mp?.release() } catch (_: Exception) { }
        mp = null
    }

    private fun shutDown() {
        releasePlayer()
        playing = false; currentFile = ""; sleepMinutes = 0
        sleepRunnable?.let { handler.removeCallbacks(it) }
        stopForeground(true)
        stopSelf()
    }

    override fun onDestroy() {
        releasePlayer()
        playing = false
        super.onDestroy()
    }
}
