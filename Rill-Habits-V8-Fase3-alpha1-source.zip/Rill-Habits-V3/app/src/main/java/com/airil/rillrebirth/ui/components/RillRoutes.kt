package com.airil.rillrebirth.ui.components

/** Central route registry for the Compose application. */
object RillRoutes {
    const val HOME = "home"
    const val CHECKLIST = "checklist"
    const val WORKOUT = "workout"
    const val STATS = "stats"

    fun routeFor(index: Int): String = when (index) {
        1 -> CHECKLIST
        2 -> WORKOUT
        3 -> STATS
        else -> HOME
    }

    fun tabIndex(route: String?): Int = when (route) {
        CHECKLIST -> 1
        WORKOUT -> 2
        STATS -> 3
        else -> 0
    }
}
