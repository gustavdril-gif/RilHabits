package com.airil.rillrebirth

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.toArgb
import dev.chrisbanes.haze.hazeSource
import dev.chrisbanes.haze.rememberHazeState
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.airil.rillrebirth.ui.components.IOSBottomBar
import com.airil.rillrebirth.ui.components.RillRoutes
import com.airil.rillrebirth.ui.screens.BerandaScreen
import com.airil.rillrebirth.ui.screens.ChecklistScreen
import com.airil.rillrebirth.ui.screens.StatistikScreen
import com.airil.rillrebirth.ui.screens.WorkoutScreen
import com.airil.rillrebirth.ui.theme.IOS
import com.airil.rillrebirth.ui.theme.RillTheme

/** Single Compose host. Legacy screens remain reachable only through the explicit migration bridge. */
class ComposeActivity : ComponentActivity() {
    private val resumeTick = androidx.compose.runtime.mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ReminderScheduler.scheduleAll(this)
        setContent {
            RillTheme {
                RillApp(resumeTick.intValue) { key ->
                    // Temporary bridge for secondary flows not yet migrated in Phase 3.
                    // Main tab navigation itself never launches MainActivity.
                    val parts = key.split("|")
                    val intent = Intent(this, MainActivity::class.java).putExtra("tab", parts[0])
                    if (parts.size > 1) intent.putExtra("open", parts[1])
                    startActivity(intent)
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        resumeTick.intValue = resumeTick.intValue + 1
    }

    override fun onPause() {
        super.onPause()
        RillWidget.updateAll(this)
    }
}

@Composable
private fun RillApp(refresh: Int, openLegacy: (String) -> Unit) {
    val colors = IOS.colors
    val navController = rememberNavController()
    val hazeState = rememberHazeState(blurEnabled = true)
    val backStackEntry = navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry.value?.destination?.route ?: RillRoutes.HOME
    val selectedTab = RillRoutes.tabIndex(currentRoute)
    val view = LocalView.current
    val context = LocalContext.current

    SideEffect {
        val window = (context as Activity).window
        window.statusBarColor = colors.background.toArgb()
        window.navigationBarColor = colors.background.toArgb()
        val controller = WindowCompat.getInsetsController(window, view)
        controller.isAppearanceLightStatusBars = !colors.dark
        controller.isAppearanceLightNavigationBars = !colors.dark
    }

    Box(Modifier.fillMaxSize().background(colors.background)) {
        NavHost(
            navController = navController,
            startDestination = RillRoutes.HOME,
            modifier = Modifier.fillMaxSize().hazeSource(state = hazeState)
        ) {
            composable(RillRoutes.HOME) { BerandaScreen(refresh, openLegacy) }
            composable(RillRoutes.CHECKLIST) { ChecklistScreen(refresh, openLegacy) }
            composable(RillRoutes.WORKOUT) { WorkoutScreen(refresh, openLegacy) }
            composable(RillRoutes.STATS) { StatistikScreen(refresh) }
        }

        IOSBottomBar(
            selected = selectedTab,
            hazeState = hazeState,
            onSelect = { index ->
                val route = RillRoutes.routeFor(index)
                if (route != currentRoute) {
                    navController.navigate(route) {
                        popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                        launchSingleTop = true
                        restoreState = true
                    }
                }
            },
            modifier = Modifier.align(Alignment.BottomCenter)
        )
    }
}
