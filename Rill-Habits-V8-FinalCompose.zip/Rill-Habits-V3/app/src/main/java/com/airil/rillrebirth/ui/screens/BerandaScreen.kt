package com.airil.rillrebirth.ui.screens

import android.content.Context
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import com.airil.rillrebirth.Badge
import com.airil.rillrebirth.GoalStore
import com.airil.rillrebirth.NoteStore
import com.airil.rillrebirth.R
import com.airil.rillrebirth.RillTask
import com.airil.rillrebirth.Smart
import com.airil.rillrebirth.ui.components.CircleCheck
import com.airil.rillrebirth.ui.components.EmojiBadge
import com.airil.rillrebirth.ui.components.EmptyState
import com.airil.rillrebirth.ui.components.IOSCard
import com.airil.rillrebirth.ui.components.IOSField
import com.airil.rillrebirth.ui.components.IOSSheet
import com.airil.rillrebirth.ui.components.MistyHeader
import com.airil.rillrebirth.ui.components.OutlineButton
import com.airil.rillrebirth.ui.components.Pill
import com.airil.rillrebirth.ui.components.PrimaryButton
import com.airil.rillrebirth.ui.components.RillNav
import com.airil.rillrebirth.ui.components.RillRoutes
import com.airil.rillrebirth.ui.components.SectionTitle
import com.airil.rillrebirth.ui.components.SegmentRing
import com.airil.rillrebirth.ui.components.ThinBar
import com.airil.rillrebirth.ui.components.iosPress
import com.airil.rillrebirth.ui.data.TodayData
import com.airil.rillrebirth.ui.theme.IOS
import com.airil.rillrebirth.ui.theme.IOSType
import java.util.Calendar

@Composable
fun BerandaScreen(refresh: Int, nav: RillNav) {
    val ctx = LocalContext.current
    val c = IOS.colors
    val haptic = LocalHapticFeedback.current
    val prefs = remember { ctx.getSharedPreferences("rill_data", Context.MODE_PRIVATE) }
    var tick by remember { mutableIntStateOf(0) }
    val snap = remember(refresh, tick) { TodayData.snapshot(ctx) }
    var name by remember { mutableStateOf(prefs.getString("profile_name", "") ?: "") }
    var nameSheet by remember { mutableStateOf(false) }
    var moodSheet by remember { mutableStateOf(false) }
    var reviewSheet by remember { mutableStateOf(false) }
    var levelUp by remember { mutableIntStateOf(0) }
    var freshBadges by remember { mutableStateOf<List<Badge>>(emptyList()) }

    val phase = Smart.phaseOf(Calendar.getInstance().get(Calendar.HOUR_OF_DAY))
    val greeting = when (phase) { 0 -> "Selamat pagi."; 1 -> "Selamat siang."; 2 -> "Selamat sore."; else -> "Selamat malam." }

    val prayerDone = snap.prayer.count { snap.done.contains(it.id) }
    val otherDone = snap.other.count { snap.done.contains(it.id) }
    val total = snap.totalCount.coerceAtLeast(1)
    val segments = listOf(prayerDone.toFloat() / total to c.primary, snap.workoutDone.toFloat() / total to c.orange, otherDone.toFloat() / total to c.blue)
    val level = snap.totalXp / 100 + 1
    val xpIn = snap.totalXp % 100
    val allDone = snap.totalCount > 0 && snap.doneCount >= snap.totalCount

    val now = TodayData.nowMinutes()
    val pending = snap.live.filter { !snap.done.contains(it.id) }.sortedBy { TodayData.minutes(ctx, it) }
    val ordered = pending.filter { TodayData.minutes(ctx, it) >= now } + pending.filter { TodayData.minutes(ctx, it) < now }
    val goal = ordered.firstOrNull()
    val nextUp = ordered.drop(1).take(2)
    val ritual = remember(refresh, tick) { TodayData.ritualOffer(ctx) }
    val notesCount = remember(refresh, tick) { NoteStore.load(ctx).count { !it.done } }
    val goalsCount = remember(refresh, tick) { GoalStore.load(ctx).size }

    LaunchedEffect(refresh, tick) {
        val stored = prefs.getInt("max_level", -1)
        if (stored < 0) prefs.edit().putInt("max_level", level).apply()
        else if (level > stored) { prefs.edit().putInt("max_level", level).apply(); levelUp = level }
        val fresh = GoalStore.checkAwards(ctx, snap.allTasks, Smart.dayStats(ctx, snap.allTasks, 365))
        if (fresh.isNotEmpty()) freshBadges = fresh
    }

    fun complete(t: RillTask) {
        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
        TodayData.setDone(ctx, t.id, true)
        tick++
    }

    LazyColumn(
        contentPadding = PaddingValues(start = 0.dp, end = 0.dp, top = 0.dp, bottom = 120.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            MistyHeader(phase, greeting, name.ifBlank { "Sahabat" }, "Pelan-pelan, konsisten.", { nameSheet = true }) {
                GoalCard(ctx, goal, snap.totalCount, ::complete)
            }
        }
        item {
            Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                IOSCard {
                    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                        SegmentRing(segments, Modifier.size(190.dp)) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("Hari ini", style = IOSType.caption, color = c.textSecondary)
                                Text("${snap.doneCount}/${snap.totalCount}", style = IOSType.number, color = c.textPrimary)
                                Text("kebiasaan", style = IOSType.caption, color = c.textSecondary)
                            }
                        }
                        Row(Modifier.padding(top = 14.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Pill("Ibadah $prayerDone/${snap.prayer.size}", c.primary)
                            Pill("Workout ${snap.workoutDone}/${snap.workoutTotal}", c.orange)
                            Pill("Lainnya $otherDone/${snap.other.size}", c.blue)
                        }
                    }
                }
                IOSCard {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text("Level $level · ${Smart.levelTitle(level)}", style = IOSType.headline, color = c.textPrimary, modifier = Modifier.weight(1f))
                        Text("$xpIn/100 XP", style = IOSType.caption, color = c.textSecondary)
                    }
                    Box(Modifier.padding(top = 10.dp)) { ThinBar(xpIn / 100f, c.primary) }
                }
                if (ritual.isNotEmpty()) {
                    val rl = remember(ritual, tick) { TodayData.ritualTasks(ctx, ritual) }
                    IOSCard {
                        Text(if (ritual == "pagi") "🌅 Ritual Pagi" else "🌙 Ritual Malam", style = IOSType.headline, color = c.textPrimary)
                        Text("${rl.size} tugas berurutan · ${rl.take(3).joinToString(", ") { it.name }}${if (rl.size > 3) "…" else ""}", style = IOSType.caption, color = c.textSecondary, modifier = Modifier.padding(top = 2.dp, bottom = 10.dp))
                        PrimaryButton(if (ritual == "pagi") "Mulai Ritual Pagi" else "Mulai Ritual Malam") { nav.go(RillRoutes.ritual(ritual)) }
                    }
                }
                if (allDone) {
                    IOSCard {
                        Text("🎉 Semua kegiatan hari ini selesai", style = IOSType.headline, color = c.textPrimary)
                        Text("Catat perasaanmu dan tutup hari dengan evaluasi singkat.", style = IOSType.body, color = c.textSecondary, modifier = Modifier.padding(top = 2.dp, bottom = 10.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            PrimaryButton("Catat mood", Modifier.weight(1f)) { moodSheet = true }
                            OutlineButton("Evaluasi malam", Modifier.weight(1f)) { reviewSheet = true }
                        }
                    }
                }
                if (nextUp.isNotEmpty()) SectionTitle("Berikutnya")
                nextUp.forEach { t -> FocusRow(ctx, t) { complete(t) } }
                if (goal == null && snap.totalCount == 0) EmptyState("🌱", "Belum ada kegiatan", "Tambahkan kebiasaan di menu Jadwal untuk mulai.", "Buka Jadwal") { nav.go(RillRoutes.JADWAL) }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    StreakCard("🔥", "${snap.streak} hari", "Streak", Modifier.weight(1f), pulse = snap.streak > 0)
                    StreakCard("🏆", "${snap.bestStreak} hari", "Streak terbaik", Modifier.weight(1f), pulse = false)
                }
                SectionTitle("Lainnya")
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    MoreCard("📝", "Catatan & Target", "$notesCount catatan · $goalsCount target", Modifier.weight(1f)) { nav.go(RillRoutes.NOTES) }
                    MoreCard("🏃", "Jogging", "Jejak, pace, langkah", Modifier.weight(1f)) { nav.go(RillRoutes.JOGGING) }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    MoreCard("⏱️", "Timer", "Istirahat & bebas", Modifier.weight(1f)) { nav.go(RillRoutes.timer(-1L)) }
                    MoreCard("🗓️", "Jadwal", "Kegiatan, shalat, cadangan", Modifier.weight(1f)) { nav.go(RillRoutes.JADWAL) }
                }
            }
        }
    }

    if (nameSheet) {
        var draft by remember { mutableStateOf(name) }
        IOSSheet({ nameSheet = false }) {
            Text("Siapa namamu?", style = IOSType.title, color = c.textPrimary)
            Text("Nama ini tampil di sapaan Beranda.", style = IOSType.body, color = c.textSecondary, modifier = Modifier.padding(top = 4.dp, bottom = 10.dp))
            IOSField(draft, { draft = it.take(20) }, "mis. Ril", singleLine = true)
            Spacer(Modifier.height(16.dp))
            PrimaryButton("Simpan") { name = draft.trim(); prefs.edit().putString("profile_name", name).apply(); nameSheet = false }
        }
    }
    if (moodSheet) MoodSheet { moodSheet = false; tick++ }
    if (reviewSheet) ReviewSheet { reviewSheet = false }
    if (levelUp > 0) AlertDialog(
        onDismissRequest = { levelUp = 0 },
        title = { Text("Level naik! 🎉") },
        text = { Text("Kamu sekarang Level $levelUp · ${Smart.levelTitle(levelUp)}. Konsistensimu terbayar.") },
        confirmButton = { TextButton(onClick = { levelUp = 0 }) { Text("Mantap") } }
    )
    if (freshBadges.isNotEmpty()) AlertDialog(
        onDismissRequest = { freshBadges = emptyList() },
        title = { Text("Target tercapai! 🎉") },
        text = { Text(freshBadges.joinToString("\n") { "🏅 ${it.title}" } + "\n\nLencana tersimpan di menu Catatan & Target.") },
        confirmButton = { TextButton(onClick = { freshBadges = emptyList(); nav.go(RillRoutes.NOTES) }) { Text("Lihat") } },
        dismissButton = { TextButton(onClick = { freshBadges = emptyList() }) { Text("Mantap") } }
    )
}

/** Dark green "focus" card that sits on top of the illustration. */
@Composable
private fun GoalCard(ctx: Context, goal: RillTask?, totalCount: Int, onDone: (RillTask) -> Unit) {
    val green = Color(0xFF2E5B4A)
    val title = when {
        goal != null -> goal.name
        totalCount > 0 -> "Semua beres 🎉"
        else -> "Belum ada kegiatan"
    }
    val sub = when {
        goal != null -> "${TodayData.timeLabel(ctx, goal)} • ${if (Smart.isPrayer(goal)) "Prioritas" else goal.category} • ${goal.xp} XP"
        totalCount > 0 -> "Kamu sudah menyelesaikan semuanya hari ini."
        else -> "Tambahkan kebiasaan lewat menu Jadwal."
    }
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(green).padding(16.dp)
            .semantics { contentDescription = "Fokus hari ini: $title, $sub" },
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(44.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.16f)), contentAlignment = Alignment.Center) { Text("🎯", style = IOSType.headline) }
        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
            Text("Fokus hari ini", style = IOSType.caption, color = Color.White.copy(alpha = 0.78f))
            Text(title, style = IOSType.headline, color = Color.White)
            Text(sub, style = IOSType.caption, color = Color.White.copy(alpha = 0.78f))
        }
        if (goal != null) {
            Box(
                Modifier.size(44.dp).clip(CircleShape).background(Color.White)
                    .semantics { contentDescription = "Selesaikan ${goal.name}" }
                    .iosPress(Role.Button) { onDone(goal) },
                contentAlignment = Alignment.Center
            ) { Icon(painterResource(R.drawable.ic_chevron), contentDescription = null, tint = green, modifier = Modifier.size(22.dp)) }
        }
    }
}

@Composable
private fun FocusRow(ctx: Context, t: RillTask, onDone: () -> Unit) {
    val c = IOS.colors
    val sub = "${TodayData.timeLabel(ctx, t)} • ${if (Smart.isPrayer(t)) "Prioritas" else t.category} • ${t.xp} XP"
    IOSCard(Modifier.semantics { contentDescription = "${t.name}, $sub" }) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            EmojiBadge(TodayData.emojiFor(t), if (Smart.isPrayer(t)) c.primary else c.blue)
            Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                Text(t.name, style = IOSType.headline, color = c.textPrimary)
                Text(sub, style = IOSType.caption, color = c.textSecondary)
            }
            CircleCheck(checked = false, label = "Selesaikan ${t.name}") { if (it) onDone() }
        }
    }
}

@Composable
private fun StreakCard(emoji: String, value: String, label: String, modifier: Modifier, pulse: Boolean) {
    val c = IOS.colors
    val t = rememberInfiniteTransition(label = "fire")
    val s by t.animateFloat(1f, if (pulse) 1.18f else 1f, infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "scale")
    IOSCard(modifier.semantics { contentDescription = "$label $value" }) {
        Text(emoji, style = IOSType.title, modifier = Modifier.graphicsLayer { scaleX = s; scaleY = s })
        Text(value, style = IOSType.title, color = c.textPrimary, modifier = Modifier.padding(top = 4.dp))
        Text(label, style = IOSType.caption, color = c.textSecondary)
    }
}

@Composable
private fun MoreCard(emoji: String, title: String, sub: String, modifier: Modifier, onClick: () -> Unit) {
    val c = IOS.colors
    IOSCard(modifier.iosPress(Role.Button, onClick)) {
        Text(emoji, style = IOSType.title)
        Text(title, style = IOSType.headline, color = c.textPrimary, modifier = Modifier.padding(top = 4.dp))
        Text(sub, style = IOSType.caption, color = c.textSecondary)
    }
}
