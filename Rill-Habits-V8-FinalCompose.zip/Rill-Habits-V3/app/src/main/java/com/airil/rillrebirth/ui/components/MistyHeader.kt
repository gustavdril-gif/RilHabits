package com.airil.rillrebirth.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.airil.rillrebirth.ui.theme.IOS
import com.airil.rillrebirth.ui.theme.IOSType

private class Mist(
    val skyTop: Color, val skyBottom: Color, val sun: Color,
    val far: Color, val mid: Color, val near: Color,
    val lakeTop: Color, val lakeBottom: Color, val ink: Color, val night: Boolean
)

private fun mist(phase: Int): Mist = when (phase) {
    0 -> Mist(Color(0xFFDDEDE6), Color(0xFFF3F0E2), Color(0xFFF4E2A6), Color(0xFFCFE1D9), Color(0xFFA9C9BD), Color(0xFF7FA899), Color(0xFFC3DBD4), Color(0xFFE7EFEA), Color(0xFF21433B), false)
    1 -> Mist(Color(0xFFD3EBF0), Color(0xFFEFF7F4), Color(0xFFFFF0B3), Color(0xFFC6DFDA), Color(0xFF9CC7BD), Color(0xFF6EA597), Color(0xFFBBDCD9), Color(0xFFE6F1EE), Color(0xFF173F42), false)
    2 -> Mist(Color(0xFFF4DCCB), Color(0xFFF8EEE6), Color(0xFFF7C79A), Color(0xFFDDC7C4), Color(0xFFBDA3A6), Color(0xFF8E7F8C), Color(0xFFE9CFC4), Color(0xFFF3E4DC), Color(0xFF4A2F3B), false)
    else -> Mist(Color(0xFF1B2735), Color(0xFF2D4152), Color(0xFFECE9D0), Color(0xFF34495A), Color(0xFF2B3E4D), Color(0xFF223341), Color(0xFF2A3A48), Color(0xFF1D2A36), Color(0xFFF2F2F7), true)
}

/** Soft layered mountains, sun (or moon) and a quiet lake. Colours follow the time of day (0 pagi .. 3 malam). */
@Composable
fun MistyLandscape(phase: Int, modifier: Modifier = Modifier) {
    val m = mist(phase)
    Canvas(modifier) {
        val w = size.width; val h = size.height
        drawRect(Brush.verticalGradient(listOf(m.skyTop, m.skyBottom), 0f, h * 0.74f), size = androidx.compose.ui.geometry.Size(w, h * 0.74f))
        if (m.night) {
            for (i in 0 until 26) {
                val x = ((i * 37) % 100) / 100f * w
                val y = ((i * 53) % 62) / 100f * h * 0.7f
                drawCircle(Color.White.copy(alpha = 0.55f), radius = 1.3.dp.toPx(), center = Offset(x, y))
            }
        }
        val sc = Offset(w * 0.64f, h * 0.30f)
        drawCircle(Brush.radialGradient(listOf(m.sun.copy(alpha = 0.55f), Color.Transparent), sc, h * 0.22f), radius = h * 0.22f, center = sc)
        drawCircle(m.sun.copy(alpha = 0.95f), radius = h * 0.075f, center = sc)

        val far = Path().apply {
            moveTo(w * 0.20f, h * 0.74f); quadraticBezierTo(w * 0.42f, h * 0.26f, w * 0.62f, h * 0.50f)
            quadraticBezierTo(w * 0.74f, h * 0.32f, w * 0.90f, h * 0.46f); quadraticBezierTo(w * 0.96f, h * 0.50f, w, h * 0.52f)
            lineTo(w, h * 0.74f); close()
        }
        drawPath(far, m.far)
        val mid = Path().apply {
            moveTo(w * 0.34f, h * 0.74f); quadraticBezierTo(w * 0.55f, h * 0.34f, w * 0.78f, h * 0.58f)
            quadraticBezierTo(w * 0.90f, h * 0.46f, w, h * 0.56f); lineTo(w, h * 0.74f); close()
        }
        drawPath(mid, m.mid)
        val near = Path().apply {
            moveTo(w * 0.50f, h * 0.74f); quadraticBezierTo(w * 0.76f, h * 0.50f, w, h * 0.63f); lineTo(w, h * 0.74f); close()
        }
        drawPath(near, m.near)
        drawRect(Brush.verticalGradient(listOf(m.lakeTop, m.lakeBottom), h * 0.74f, h), topLeft = Offset(0f, h * 0.74f), size = androidx.compose.ui.geometry.Size(w, h * 0.26f))
        for (k in 0 until 3) {
            val y = h * (0.80f + k * 0.06f)
            drawLine(Color.White.copy(alpha = 0.28f), Offset(w * (0.42f + k * 0.07f), y), Offset(w * (0.88f - k * 0.05f), y), strokeWidth = 1.5.dp.toPx())
        }
    }
}

/** Home header: misty illustration, greeting with name, profile circle, and a floating card at the bottom. */
@Composable
fun MistyHeader(
    phase: Int, greeting: String, name: String, tagline: String,
    onProfile: () -> Unit, bottomCard: @Composable BoxScope.() -> Unit
) {
    val c = IOS.colors
    val m = mist(phase)
    Box(Modifier.fillMaxWidth().height(330.dp)) {
        Box(Modifier.fillMaxWidth().height(262.dp).background(Brush.verticalGradient(listOf(m.skyTop, m.skyBottom, c.background)))) {
            MistyLandscape(phase, Modifier.fillMaxSize())
        }
        Column(Modifier.padding(start = 20.dp, top = 22.dp, end = 76.dp)) {
            Text(greeting, style = IOSType.body.copy(fontSize = 16.sp), color = m.ink.copy(alpha = 0.75f))
            Text(name, style = IOSType.largeTitle, color = m.ink)
            Text(tagline, style = IOSType.caption.copy(fontSize = 13.sp), color = m.ink.copy(alpha = 0.7f), modifier = Modifier.padding(top = 2.dp))
        }
        Box(
            Modifier.align(Alignment.TopEnd).padding(top = 18.dp, end = 18.dp).size(44.dp).clip(CircleShape)
                .background(if (m.night) Color(0xFF4A6A5E) else Color(0xFF2E5B4A))
                .semantics { contentDescription = "Profil, ketuk untuk mengubah nama" }
                .iosPress(Role.Button, onProfile),
            contentAlignment = Alignment.Center
        ) { Text(name.take(1).uppercase(), style = IOSType.headline, color = Color.White) }
        Box(Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(horizontal = 16.dp), content = bottomCard)
    }
}
